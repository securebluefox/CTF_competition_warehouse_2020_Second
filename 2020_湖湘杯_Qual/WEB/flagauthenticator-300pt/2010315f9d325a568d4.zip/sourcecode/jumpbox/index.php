<?php
error_reporting(0);
session_start();

function alertMes($mes,$url){
    echo "<script>alert('{$mes}');location.href='{$url}';</script>";
    die;
}

function redirectTo($url) {
    echo "<script>location.href='{$url}';</script>";
    die;
}

function generate_code($length = 6) {
    $salt = "DASCTF";
    $min = pow(10 , ($length - 1));
    $max = pow(10, $length) - 1;
    return strval(rand($min, $max)) . $salt;
}

function init($a) {
    if ( !isset($_SESSION['captcha']) || isset($_POST['reset']) || $a == 1  ) {
        $secret = md5(generate_code());
        $_SESSION['captcha'] = substr($secret,0,6);
        redirectTo("./index.php");
    }
}


init(0);

if ( isset($_POST['url']) && isset($_POST['captcha']) && isset($_POST['name']) ) {
    $url = $_POST['url'];
    $captcha = $_POST['captcha'];
    $name = $_POST['name'];

    if ( !preg_match('/^\w{4,10}$/s', $name) )
        alertMes('Invalid ID', './index.php');

    if ( filter_var($url, FILTER_VALIDATE_URL) === false )
        alertMes('Invalid URL', './index.php');

    if ( preg_match("/[;^[\]#<>'\"|$&()%]/", $url) )  //do not code injection
        alertMes('please urlencode your symbols', './index.php');

    if ( parse_url($url)['host'] !== 'flag.authenticator.das.ctf' || parse_url($url)['port'] != 80 ) // dont forget the port
        alertMes('I only visit http://flag.authenticator.das.ctf:80', './index.php');   

    if ( substr(md5($captcha), 0 , 6) !== $_SESSION['captcha'] )
        alertMes('wrong captcha, pls try again', './index.php');

    //bot check
    //这里没有必要命令注入，考点不在这里，bot只用作访问链接，请不要攻击bot
    //退一步讲，即使命令注入了，靶机也不能出外网，不能用curl等工具
    //另外，bot调用的是remote webdriver，bot和flagauthenticator都不在本机上，本机权限已做的很好，即使命令注入了对于你获取flag没有任何帮助
    //所以 这个url的提交和exec($cmd)只是为了让bot访问你提交的url 这里没有漏洞 请不要在这里白费力气；就算搅屎我们重启docker便是了 只能浪费你自己时间
    putenv('PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin');
    $cmd = "python3 /bot.py ".str_replace('\\', '\\\\', $url);
    exec($cmd);

    init(1);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>jumpbox</title>
    <link rel="stylesheet" href="./css/bulma.min.css" type="text/css" media="all">
</head>
<body>

<div class="hero-body">
    <div class="container has-text-centered">
        <div class="column is-4 is-offset-4">
            <h3 class="title has-text-black">Chrome-Visit JumpBox</h3>
            <hr class="login-hr"><br><br>
            <div class="box">

                <form method="post" action="">
                    <div class="field">
                        <div class="control">
                            <input class="input" type="text" name="name" placeholder="Your ID: /^\w{4,10}$/s" autofocus="">
                        </div>
                    </div>
                    <div class="field">
                        <div class="control">
                            <input class="input" type="text" name="url" placeholder="URL: http://flag.authenticator.das.ctf:80/" autofocus="">
                        </div>
                    </div>
                    <div class="field">
                        <div class="control">
                            <input class="input" type="text" name="captcha" placeholder="验证码: md5(code)[:6] == '<?php echo $_SESSION['captcha']; ?>'">
                        </div>
                    </div>
                    <button class="button is-block is-info is-medium is-fullwidth">Submit <i class="fa fa-sign-in" aria-hidden="true"></i></button>
                </form>
            </div>
            <p class="has-text-grey">
                <br><br><br><br>向本页面提交<code>$_POST['reset']</code>可生成新的验证🐎
            </p>
        </div>
    </div>
</div>
<footer class="footer">
    <div class="content has-text-centered">
        <p>
            <br><br> By <strong>DASCTF</strong>
        </p>
    </div>
</footer>
</body>
</html>
