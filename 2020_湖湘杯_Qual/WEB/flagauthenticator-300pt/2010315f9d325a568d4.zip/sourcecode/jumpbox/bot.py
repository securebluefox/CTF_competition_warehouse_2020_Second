#!/usr/bin/env python3
#-*- coding:utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import time
import sys

url = sys.argv[1]

driver = webdriver.Remote(
	command_executor="http://172.26.1.22:4444/wd/hub",
	desired_capabilities=DesiredCapabilities.CHROME
)
#如果你提交后没有sleep, 说明php里exec($cmd)里出错了，大概率是一些特殊符号导致bash语句出错了
#所以，提交url前先对其url编码一次，bot也是浏览器，它访问时候会自动解一次url编码的
time.sleep(1)


driver.set_page_load_timeout(10) 

try:
	driver.get(url)
except Exception as ee:
	print(ee)
	print("time out!")
finally:
	driver.close()
	driver.quit()
sys.exit()