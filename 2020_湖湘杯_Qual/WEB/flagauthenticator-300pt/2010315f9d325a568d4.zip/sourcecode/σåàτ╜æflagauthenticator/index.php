<?php
//这台内网主机就是http://flag.authenticator.das.ctf:80，该域名使用内网中DNS进行解析
header("Content-Security-Policy: default-src 'none'; script-src 'self'; img-src 'self'; object-src 'none'; ");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Max-Age: 86400");
header("X-Frame-Options: X-Frame-Options");
header("Referrer-Policy: same-origin");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1");
header("Content-Type: text/html; charset=UTF-8");
error_reporting(0);

$flag = "DASCTF{" . md5(getenv("FLAG")) ."}";

function send_http_status($code) {
    static $_status = array( 200 => 'OK', 401 => 'Unauthorized' );
    if(array_key_exists($code,$_status)) {
        header('HTTP/1.1 '.$code.' '.$_status[$code]);
    }
}

if ($_SERVER['REMOTE_ADDR'] != getenv('JUMPBOX_IP_ADDRESS') && $_SERVER['REMOTE_ADDR'] != '127.0.0.1') { 
   die("Forbidden");
}

ob_start();
if (isset($_GET['flag']) && is_string($_GET['flag']) ) {
    if ( preg_match('/^'.$_GET['flag'].'$/', $flag) ) {
        echo "Congratulations! You have the real flag, " . $flag . " ,now you have been authorized!";
        setcookie("Auth", md5(sha1(getenv("FLAG"))), 3600);
    } else {
        send_http_status(401);
        echo "Error: Unauthorized";
    }
    echo "<br>Here is the credential you provided:<br>" . $_GET['flag'];
} else echo "<html lang='en'><head><title>flag authenticator</title></head></html>";
ob_end_flush();
?>
