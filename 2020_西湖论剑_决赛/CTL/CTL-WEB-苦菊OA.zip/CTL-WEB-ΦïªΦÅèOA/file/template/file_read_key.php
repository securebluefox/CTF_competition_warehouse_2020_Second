<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->
 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=10,chrome=1" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2014.css">
<script type="text/javascript" src="template/default/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="template/default/content/js/lockTableTitle.js"></script>
<script language="javascript" type="text/javascript" src="template/default/content/js/common.js"></script>
<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
<script type="text/javascript">
    
    var locktb;
    $(function(){
        locktb=new Kkctf.table.lockTableSingle({
            tMain:$('#lockTable'),            //table的层
            padWidth:15,                        //单元格左右的padding的值总和数值
            borWidth:2,                        //表格左右边框宽度总和值
            subtHeig:150,                    //表格高度减去多少
            dinamicDiv:$('#dynamicDiv'),      //动态层的高度.表格会根据动态层的显示或隐藏进行表格大小的动态调整(可选)
            autoHeight:true                 //表格窗口是否随着窗口的高度改变自动调整高度(可选)
        });
    });

    function formview(){
    
        if($('#dynamicDiv').is(':visible')){
            $('#dynamicDiv').hide();
        }else{
            $('#dynamicDiv').show();
        }
        
        locktb.autoHeightFn();
    }
    function sendForm(){
	   document.save.submit();
	}
	function updateform(type){
		if(type==1){
			document.getElementById("uptype").value='1';
		}
		document.update.submit();
	}
</script>
</head>
<body class="body-wrap">
<div class="tabbable work-nav"> <!-- Only required for left/right tabs -->
				<ul id="myTab" class="nav nav-tabs">
					<li <?php if($_GET[type]=='1'){?>class="active"<?php }?>><a href="admin.php?ac=file_read_key&fileurl=file&type=1" data-toggle="tab">等待审批</a></li>
					<li <?php if($_GET[type]=='3' && $_GET[types]!='1'){?>class="active"<?php }?>><a href="admin.php?ac=file_read_key&fileurl=file&type=3" data-toggle="tab">已审批</a></li>
					<li <?php if($_GET[types]=='1'){?>class="active"<?php }?>><a href="admin.php?ac=file_read_key&fileurl=file&type=3&types=1" data-toggle="tab">已借出</a></li>
					<li <?php if($_GET[type]==''){?>class="active"<?php }?>><a href="admin.php?ac=file_read_key&fileurl=file" data-toggle="tab">档案一览</a></li>
					
				</ul>
			</div>
<div class="search_area">
    <form method="get" action="admin.php" name="save">
	<input type="hidden" name="ac" value="<?php echo $ac?>" />
		<input type="hidden" name="do" value="list" />
		<input type="hidden" name="fileurl" value="<?php echo $fileurl?>" />
		<input type="hidden" name="type" value="<?php echo $type?>" />
        <div class="form-search form-search-top" style="text-align:left;padding-left:10px;">
                        <?php echo get_keyuser($ui,$un);?>    
			            
	        <div class="adv-select-label">编号：</div>
       		<input type="text"  name="number" size="20" class="span1" value="<?php echo urldecode($number)?>">  
			<div class="adv-select-label">名称：</div>
       		<input type="text"  name="title" size="20" class="span2" value="<?php echo urldecode($title)?>">  
            <div class="adv-select-label">申请周期：</div>
            <input type="text" class="span1" value="<?php echo $vstartdate?>"  style="width:80px;" readonly="readonly"  onClick="WdatePicker();" name='vstartdate'> 至 <input type="text" class="span1" value="<?php echo $venddate?>"  style="width:80px;" readonly="readonly"  onClick="WdatePicker();" name='venddate'>
			
           
            <button id="do_search" type="button" onClick="sendForm();" class="btn btn-primary">查 询</button>
           <!-- <button  onClick="formview()" type="button" class="btn">切换更多查询</button> -->
        </div>
       
    </form>
</div>


<div class="data-wrap">
	<div class="data-operation">
		<div class="button-operation">
		<button type="button" action="new_work" class="btn btn-success" onClick="javascript:window.location='admin.php?ac=add&fileurl=file'">新建档案</button>				

				<?php echo get_exceldown('excel_36',1);?>
				
		</div>

<div class="pager_operation">
	<?php echo newshowpage($num,$pagesize,$page,$url);?>
	
	
</div>
</div>		
</div>
<form name="update" method="post" action="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>">
		<input type="hidden" name="do" value="update" />
		<input type="hidden" name="uptype" id="uptype" value="2" />
		<input type="hidden" name="type" value="<?php echo $_GET['type']?>" />

<div class="data-list" >
<div  id="lockTable">
<table  class="table table-bordered table-hover" width="100%">
      <tr class="editThead" align="center">
      <td width="40"><input type="checkbox" value="1" name="chkall" onClick="check_all(this)" /></td>
	  <td width="100">档案编号</td>
      <td>档案名称</td>
	  <td width="100">申请人</td>
	  <td width="100">申请日期</td>
      <td width="100">审批人</td>
      <td width="140">审批日期</td>
	  <td width="100">当前状态</td>
      <td width="120">操作</td>
   </tr>
<?php
foreach ($result as $row) {
?>
    <tr >
      <td width="40"><?php
get_boxlistkey("id[]",$row['id'],$row['uid'],$_USER->id)
?></td>
<td><?php echo $row['filenumber']?></td>
<td>
<a href="admin.php?ac=views&do=edit&fileurl=file&id=<?php echo $row['fileid']?><?php if($row['type']=='3'){?>&adome=1<?php }?>"><?php echo $row['filename']?></a>
</td>
<td><?php echo get_realname($row['appperson'])?></td>
<td><?php echo $row['appdate']?></td>
<td><?php echo get_realname($row['examperson'])?></td>
<td><?php echo $row['examdate']?></td>
<td><?php
							if($row['type']=='1'){
							echo "待审";
							}elseif($row['type']=='2'){
							echo "未通过";
							}elseif($row['type']=='3'){
							echo "借阅中";
							}elseif($row['type']=='4'){
							echo "己归还";
							}
							
							
							?></td>	
<td>							
<?php
							global $db;
							$r = $db->fetch_one_array("SELECT b.* FROM ".DB_TABLEPRE."file a,".DB_TABLEPRE."file_type b where a.id='".$row['fileid']."' and a.filetype=b.id and b.keyuser like '%".get_realname($_USER->id)."%'   ORDER BY a.id desc limit 0,1");
							if ($r[keyuser]!=''){
							?>
							<?php if($row[type]=='1'){?>
							<a href="admin.php?ac=file_read_key&tid=<?php echo $row['id']?>&ltype=3&do=save&fileurl=file">审批</a> | <a href="admin.php?ac=file_read_key&do=save&fileurl=file&tid=<?php echo $row['id']?>&ltype=2">拒绝</a>
							<?php }elseif($row[type]=='3'){?>
							<a href="admin.php?ac=file_read_key&tid=<?php echo $row['id']?>&ltype=4&do=save&fileurl=file">归还档案</a>
							<?php }else{?>&nbsp;
							<?php echo "正常";}
							}else{
							echo "无权限";
							}
							
							?>	
</td>					
    </tr>
<?php } ?>	       
    </table>
</div>
</div>
</form>
<form name="excel" method="post" action="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>">
		<input type="hidden" name="do" value="excel" />
		<input type="hidden" name="title" value="<?php echo $title?>" />
		<input type="hidden" name="number" value="<?php echo $number?>" />
		<input type="hidden" name="type" value="<?php echo $type?>" />
		<input type="hidden" name="vstartdate" value="<?php echo $vstartdate?>" />
		<input type="hidden" name="venddate" value="<?php echo $venddate?>" />
		<input type="hidden" name="un" value="<?php echo urldecode($un)?>" />
		<input type="hidden" name="ui" value="<?php echo urldecode($ui)?>" />
	</form>
</body>
</html>