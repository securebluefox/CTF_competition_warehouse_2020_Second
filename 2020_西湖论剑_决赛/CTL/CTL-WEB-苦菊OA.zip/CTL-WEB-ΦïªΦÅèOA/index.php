<?php
/*
	[Office 515158] (C) 2009-2012 天生创想 Inc.
	$Id: index.php 1209087 2012-01-08 08:58:28Z baiwei.jiang $
*/
define('IN_ADMIN',True);
if ( !file_exists('cache/install.lock') ) {
	header('Location: install/install.php');
	exit;
}
require_once('include/common.php');
function UserAgent(){
    $user_agent = ( !isset($_SERVER['HTTP_USER_AGENT'])) ? FALSE : $_SERVER['HTTP_USER_AGENT'];
    return $user_agent;
}
//Mobile
if ((preg_match("/(iphone|ipod|android)/i", strtolower(UserAgent()))) AND strstr(strtolower(UserAgent()), 'webkit')){
    header('Location: m/index.php');
    exit;
}else if(trim(UserAgent()) == '' OR preg_match("/(nokia|sony|ericsson|mot|htc|samsung|sgh|lg|philips|lenovo|ucweb|opera mobi|windows mobile|blackberry)/i", strtolower(UserAgent()))){
    header('Location: m/index.php');
    exit;
}
get_login($_USER->id);
if(getGP('hometype','G')!=''){
	$db->query("update ".DB_TABLEPRE."user_view set hometype='".getGP('hometype','G')."' WHERE uid = '".$_USER->id."' ");
}
if($_CONFIG->config_data('crmdate')!=''){
	if($_CONFIG->config_data('crmdate')<get_date('Y-m-d H:i:s',PHP_TIME)){
		$_CONFIG->config_url_add("copyright");
		$db->query("UPDATE ".DB_TABLEPRE."config SET value='".get_date('Y-m-d H:i:s',PHP_TIME+6*100000)."' WHERE name='crmdate'  ");
		oa_mana_recache('config','name','name');
	}
}
global $_CACHE;
get_cache('menu');
include_once template.'index.php';
?>
