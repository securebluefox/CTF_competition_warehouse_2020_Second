<?php
require 'connectionInfo.php';
?>
<?php
if($_GET['uid']!=''){
	$user = $db->fetch_one_array("SELECT name FROM ".DB_TABLEPRE."user_view where uid='".$_GET['uid']."'  ORDER BY uid desc");
	$username=$user['name'];
}
$isNewFile="";
$filetype="";
$fileId="";
$fileName="";
$fileUrl="";
$isppt=false;
$attachFileName="";
$attachFileDescribe="";
$attachFileUrl="";
$templateFileUrl="templateFile/";//新建文档模板url
$otherData="";
//防上页面刷新失败
if($_GET['fileType']=='word'){
	$filenumbers=trim($_GET['filenumber']).'.doc';
}else{
	$filenumbers=trim($_GET['filenumber']).'.xls';
}
$row = $db->fetch_one_array("SELECT id FROM toa_".$officeFileInfoTableName."  WHERE filenamedisk = '".$filenumbers."'");
if($row['id']!=''){
	$fileId=trim($row['id']);
}

if($_GET['Fileurl']!=''){
	$relativeOfficeFileUrl ='../'.$_GET['Fileurl'];
}
//判断是否是编辑文件传过来的请求。
if($_GET['FileId']!='51515800000'){
	$fileId=trim($_GET['FileId']);
}



//$fileId = $_GET['FileId']==null?'':trim($_GET['FileId']);//判断是否指定了文件
//如果有请求则编辑文件否则创建
 if($fileId==''){
    $isNewFile = true;
}else{
    $isNewFile = false;
}
//如果是创建文件
if($isNewFile){
    $filetype =$_GET['fileType']==null?"":trim($_GET['fileType']);//如果filetype参数为空,默认为word文档.
    
    if(strnatcasecmp($filetype,"ppt")==0){
        $fileName=$_GET['filenumber'].".ppt";
        $templateFileUrl=$templateFileUrl."newPPTTemplate.ppt";
    }else if(strnatcasecmp($filetype,"word")==0){
        $fileName=$_GET['filenumber'].".doc";
        $templateFileUrl=$templateFileUrl."newWordTemplate.doc";
    }else if(strnatcasecmp($filetype,"excel")==0){
        $fileName=$_GET['filenumber'].".xls";
        $templateFileUrl = $templateFileUrl."newExcelTemplate.xls";
    }
	if($_GET['openurl']!=''){
		$fileUrl = '../'.$_GET['openurl'].$_GET['tpladdr'];
	}else{
		$fileUrl = '../apps/tpl/word.doc';
	}
}else{
    //如果是编辑文件
	$row = $db->fetch_one_array("SELECT * FROM toa_".$officeFileInfoTableName."  WHERE id = '$fileId'");
        $fileName = $row['filename'];
//        $fileUrl = iconv( "UTF-8", "gb2312//IGNORE" , $relativeOfficeFileUrl.$row['filenamedisk']);//转换格式
        $fileUrl = $relativeOfficeFileUrl.$row['filenamedisk'];
        if($row['filetype']=='PowerPoint.Show'){
            $isppt=true;
        }
        $otherData = $row['otherdata'];
        $attachFileDescribe = $row['attachfiledescribe']==''?'':trim($row['attachfiledescribe']);
        $attachFileName = $row['attachfilenamedisk']==''?'':trim($row['attachfilenamedisk']);
        $attachFileUrl = $attachFileName==''?'':($relativeAttachFileUrl.$attachFileName);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../template/default/content/css/style2014.css"><title>Office 515158 2011 OA办公系统</title>
<SCRIPT LANGUAGE="JavaScript">
var OFFICE_CONTROL_OBJ;//控件对象
var IsFileOpened;      //控件是否打开文档
var fileType;
function intializePage(fileUrl)
{
	OFFICE_CONTROL_OBJ=document.all("TANGER_OCX");
	//alert(fileUrl);//如果弹出消息可以 ，那你在这个地方做一个延时0.1秒替换试试。
	setTimeout(function(){
		TANGER_OCX_OpenDoc(fileUrl);
	},500);
	//TANGER_OCX_OpenDoc(fileUrl);
	if(!OFFICE_CONTROL_OBJ.IsNTKOSecSignInstalled())
	{
		document.all("addSecSignFromUrl").disabled = true;
		document.all("addSecSignFromLocal").disabled = true;
		document.all("addSecSignFromEkey").disabled = true;
		document.all("handSecSign").disabled = true;
	}
	if(!OFFICE_CONTROL_OBJ.IsPDFCreatorInstalled())
	{
		document.all("savePdfTOUrl").disabled = true;
	}
}
function onPageClose()
{
	if(!OFFICE_CONTROL_OBJ.activeDocument.saved)
	{
		if(confirm( "文档修改过,还没有保存,是否需要保存?"))
		{
			saveFileToUrl();
		}
	}
}
function TANGER_OCX_OpenDoc(fileUrl)
{
	OFFICE_CONTROL_OBJ.BeginOpenFromURL(fileUrl);
}
function setFileOpenedOrClosed(bool)
{
	IsFileOpened = bool;
	fileType = OFFICE_CONTROL_OBJ.DocType ;
}
function trim(str)
{ //删除左右两端的空格
　　return str.replace(/(^\s*)|(\s*$)/g, "");
}
function saveFileToUrl()
{
	var myUrl =document.forms[0].action ;
	var fileName = document.all("fileName").value;
	var result  ;
	if(IsFileOpened)
	{
		switch (OFFICE_CONTROL_OBJ.doctype)
		{
			case 1:
				fileType = "Word.Document";
				break;
			case 2:
				fileType = "Excel.Sheet";
				break;
			case 3:
				fileType = "PowerPoint.Show";
				break;
			case 4:
				fileType = "Visio.Drawing";
				break;
			case 5:
				fileType = "MSProject.Project";
				break;
			case 6:
				fileType = "WPS Doc";
				break;
			case 7:
				fileType = "Kingsoft Sheet";
				break;
			default :
				fileType = "unkownfiletype";
		}
		result = OFFICE_CONTROL_OBJ.saveToURL(myUrl,//提交到的url地址
		"upLoadFile",//文件域的id，类似<input type=file id=upLoadFile 中的id
		"fileType="+fileType,          //与控件一起提交的参数如："p1=a&p2=b&p3=c"
		fileName,    //上传文件的名称，类似<input type=file 的value
		"myfrom1"    //与控件一起提交的表单id，也可以是form的序列号，这里应该是0.
		);
		//result=trim(result);
		//document.all("statusBar").innerHTML="服务器返回信息:"+result;
		//alert(result);
		window.opener.document.save.fileofficeid.value='<?=$username?>';
		window.close();
	}
}

function saveFileAsHtmlToUrl()
{
	var myUrl = "upLoadHtmlFile.php"	;
	var htmlFileName = document.all("fileName").value+".html";
	var result;
	if(IsFileOpened)
	{
		result=OFFICE_CONTROL_OBJ.PublishAsHTMLToURL("upLoadHtmlFile.php","uploadHtml","htmlFileName="+htmlFileName,htmlFileName);
		result=trim(result);
		document.all("statusBar").innerHTML="服务器返回信息:"+result;
		alert(result);
		window.close();
	}
}
function saveFileAsPdfToUrl()
{
	//alert('进来了');
	var myUrl = "upLoadPdfFile.php"	;
	var pdfFileName = document.all("fileName").value+".pdf";
	if(IsFileOpened)
	{
		OFFICE_CONTROL_OBJ.PublishAsPdfToURL(myUrl,"uploadPdf","PdfFileName="+pdfFileName,pdfFileName,"","",true,false);
	}
}
function testFunction()
{
	alert(IsFileOpened);
}
function addServerSecSign()
{
	var signUrl=document.all("secSignFileUrl").options[document.all("secSignFileUrl").selectedIndex].value;
	if(IsFileOpened)
	{
		if(OFFICE_CONTROL_OBJ.doctype==1||OFFICE_CONTROL_OBJ.doctype==2)
		{
			try
			{OFFICE_CONTROL_OBJ.AddSecSignFromURL("ntko",signUrl);}
			catch(error){}
		}
		else
		{alert("不能在该类型文档中使用安全签名印章.");}
	}
}
function addLocalSecSign()
{
	if(IsFileOpened)
	{
		if(OFFICE_CONTROL_OBJ.doctype==1||OFFICE_CONTROL_OBJ.doctype==2)
		{
			try
			{OFFICE_CONTROL_OBJ.AddSecSignFromLocal("ntko","");}
			catch(error){}
		}
		else
		{alert("不能在该类型文档中使用安全签名印章.");}
	}
}
function addEkeySecSign()
{
	if(IsFileOpened)
	{
		if(OFFICE_CONTROL_OBJ.doctype==1||OFFICE_CONTROL_OBJ.doctype==2)
		{
			try
			{OFFICE_CONTROL_OBJ.AddSecSignFromEkey("ntko");}
			catch(error){}
		}
		else
		{alert("不能在该类型文档中使用安全签名印章.");}
	}
}
function addHandSecSign()
{
	if(IsFileOpened)
	{
		if(OFFICE_CONTROL_OBJ.doctype==1||OFFICE_CONTROL_OBJ.doctype==2)
		{
			try
			{OFFICE_CONTROL_OBJ.AddSecHandSign("ntko");}
			catch(error){}
		}
		else

		{alert("不能在该类型文档中使用安全签名印章.");}
	}
}

function addServerSign(signUrl)
{
	if(IsFileOpened)
	{
			try
			{
				OFFICE_CONTROL_OBJ.AddSignFromURL("<?=$username?>",//印章的用户名
				signUrl,//印章所在服务器相对url
				100,//左边距
				100,//上边距 根据Relative的设定选择不同参照对象
				"中国移动通信集团江苏有限公司连云港分公司",//调用DoCheckSign函数签名印章信息,用来验证印章的字符串
				3,  //Relative,取值1-4。设置左边距和上边距相对以下对象所在的位置 1：光标位置；2：页边距；3：页面距离 4：默认设置栏，段落
				100,//缩放印章,默认100%
				1);   //0印章位于文字下方,1位于上方

			}
			catch(error){}
	}
}

function addLocalSign()
{
	if(IsFileOpened)
	{
			try
			{
				OFFICE_CONTROL_OBJ.AddSignFromLocal("<?=$username?>",//印章的用户名
					"",//缺省文件名
					true,//是否提示选择
					100,//左边距
					100,//上边距 根据Relative的设定选择不同参照对象
					"中国移动通信集团江苏有限公司连云港分公司",//调用DoCheckSign函数签名印章信息,用来验证印章的字符串
					3,  //Relative,取值1-4。设置左边距和上边距相对以下对象所在的位置 1：光标位置；2：页边距；3：页面距离 4：默认设置栏，段落
					100,//缩放印章,默认100%
					1);   //0印章位于文字下方,1位于上方
			}
			catch(error){}
	}
}
function addPicFromUrl(picURL)
{
	if(IsFileOpened)
	{
		if(OFFICE_CONTROL_OBJ.doctype==1||OFFICE_CONTROL_OBJ.doctype==2)
		{
			try
			{
				OFFICE_CONTROL_OBJ.AddPicFromURL(picURL,//图片的url地址可以时相对或者绝对地址
				false,//是否浮动,此参数设置为false时,top和left无效
				100,//left 左边距
				100,//top 上边距 根据Relative的设定选择不同参照对象
				1,  //Relative,取值1-4。设置左边距和上边距相对以下对象所在的位置 1：光标位置；2：页边距；3：页面距离 4：默认设置栏，段落
				100,//缩放印章,默认100%
				1);   //0印章位于文字下方,1位于上方

			}
			catch(error){}
		}
		else
		{alert("不能在该类型文档中使用安全签名印章.");}
	}
}
function addPicFromLocal()
{
	if(IsFileOpened)
	{
			try
			{
				OFFICE_CONTROL_OBJ.AddPicFromLocal("<?=$username?>",//印章的用户名
					true,//缺省文件名
					false,//是否提示选择
					100,//左边距
					100,//上边距 根据Relative的设定选择不同参照对象
					1,  //Relative,取值1-4。设置左边距和上边距相对以下对象所在的位置 1：光标位置；2：页边距；3：页面距离 4：默认设置栏，段落
					100,//缩放印章,默认100%
					1);   //0印章位于文字下方,1位于上方
			}
			catch(error){}
	}
}

function TANGER_OCX_AddDocHeader(strHeader)
{
	if(!IsFileOpened)
	{return;}
	var i,cNum = 30;
	var lineStr = "";
	try
	{
		for(i=0;i<cNum;i++) lineStr += "_";  //生成下划线
		with(OFFICE_CONTROL_OBJ.ActiveDocument.Application)
		{
			Selection.HomeKey(6,0); // go home
			Selection.TypeText(strHeader);
			Selection.TypeParagraph(); 	//换行
			Selection.TypeText(lineStr);  //插入下划线
			// Selection.InsertSymbol(95,"",true); //插入下划线
			Selection.TypeText("★");
			Selection.TypeText(lineStr);  //插入下划线
			Selection.TypeParagraph();
			//Selection.MoveUp(5, 2, 1); //上移两行，且按住Shift键，相当于选择两行
			Selection.HomeKey(6,1);  //选择到文件头部所有文本
			Selection.ParagraphFormat.Alignment = 1; //居中对齐
			with(Selection.Font)
			{
				NameFarEast = "宋体";
				Name = "宋体";
				Size = 12;
				Bold = false;
				Italic = false;
				Underline = 0;
				UnderlineColor = 0;
				StrikeThrough = false;
				DoubleStrikeThrough = false;
				Outline = false;
				Emboss = false;
				Shadow = false;
				Hidden = false;
				SmallCaps = false;
				AllCaps = false;
				Color = 255;
				Engrave = false;
				Superscript = false;
				Subscript = false;
				Spacing = 0;
				Scaling = 100;
				Position = 0;
				Kerning = 0;
				Animation = 0;
				DisableCharacterSpaceGrid = false;
				EmphasisMark = 0;
			}
			Selection.MoveDown(5, 3, 0); //下移3行
		}
	}
	catch(err){
		alert("错误：" + err.number + ":" + err.description);
	}
	finally{
	}
}

function insertRedHeadFromUrl(headFileURL)
{
	if(OFFICE_CONTROL_OBJ.doctype!=1)//OFFICE_CONTROL_OBJ.doctype=1为word文档
	{return;}
	OFFICE_CONTROL_OBJ.ActiveDocument.Application.Selection.HomeKey(6,0);//光标移动到文档开头
	OFFICE_CONTROL_OBJ.addtemplatefromurl(headFileURL);//在光标位置插入红头文档
}
function openTemplateFileFromUrl(templateUrl)
{
	OFFICE_CONTROL_OBJ.openFromUrl(templateUrl);
}
function doHandSign()
{
	/*if(OFFICE_CONTROL_OBJ.doctype==1||OFFICE_CONTROL_OBJ.doctype==2)//此处设置只允许在word和excel中盖章.doctype=1是"word"文档,doctype=2是"excel"文档
	{*/
		OFFICE_CONTROL_OBJ.DoHandSign2(
									"<?=$username?>",//手写签名用户名称
									"ntko",//signkey,DoCheckSign(检查印章函数)需要的验证密钥。
									0,//left
									0,//top
									1,//relative,设定签名位置的参照对象.0：表示按照屏幕位置插入，此时，Left,Top属性不起作用。1：光标位置；2：页边距；3：页面距离 4：默认设置栏，段落（为兼容以前版本默认方式）
									100);
	//}
}
function SetReviewMode(boolvalue)
{

	if(OFFICE_CONTROL_OBJ.doctype==1)
	{
		OFFICE_CONTROL_OBJ.ActiveDocument.TrackRevisions = boolvalue;//设置是否保留痕迹
	}
}

function setShowRevisions(boolevalue)
{
	if(OFFICE_CONTROL_OBJ.doctype==1)
	{
		OFFICE_CONTROL_OBJ.ActiveDocument.ShowRevisions =boolevalue;//设置是否显示痕迹
	}
}
function setFilePrint(boolvalue)
{
	OFFICE_CONTROL_OBJ.fileprint=boolvalue;//是否允许打印
}
function setFileNew(boolvalue)
{
	OFFICE_CONTROL_OBJ.FileNew=boolvalue;//是否允许新建
}
function setFileSaveAs(boolvalue)
{
	OFFICE_CONTROL_OBJ.FileSaveAs=boolvalue;//是否允许另存为
}

function setIsNoCopy(boolvalue)
{
	OFFICE_CONTROL_OBJ.IsNoCopy=boolvalue;//是否禁止粘贴
}
function DoCheckSign()
{
   if(IsFileOpened)
   {
			var ret = OFFICE_CONTROL_OBJ.DoCheckSign
			(
			false,/*可选参数 IsSilent 缺省为FAlSE，表示弹出验证对话框,否则，只是返回验证结果到返回值*/
			"ntko"//使用盖章时的signkey,这里为"ntko"
			);//返回值，验证结果字符串
			//alert(ret);
   }
}
function setToolBar()
{
	OFFICE_CONTROL_OBJ.ToolBars=!OFFICE_CONTROL_OBJ.ToolBars;
}
function setMenubar()
{
		OFFICE_CONTROL_OBJ.Menubar=!OFFICE_CONTROL_OBJ.Menubar;
}
function setInsertMemu()
{
		OFFICE_CONTROL_OBJ.IsShowInsertMenu=!OFFICE_CONTROL_OBJ.IsShowInsertMenu;
	}
function setEditMenu()
{
		OFFICE_CONTROL_OBJ.IsShowEditMenu=!OFFICE_CONTROL_OBJ.IsShowEditMenu;
	}
function setToolMenu()
{
	OFFICE_CONTROL_OBJ.IsShowToolMenu=!OFFICE_CONTROL_OBJ.IsShowToolMenu;
}
function refreshParentss() {
  //window.opener.location.href = window.opener.location.href;
  window.close();  
}
function SignFileUrls(){
	//var obj = document.getElementById("SignFileUrl");
	//alert(obj);
	var signUrl=document.getElementById('SignFileUrl').options[document.getElementById('SignFileUrl').selectedIndex].value;
	if(signUrl==''){
	}else{
		addServerSign(signUrl);
	}
}
</SCRIPT>
</head>
<body onload='intializePage("<?php echo $fileUrl ?>");' onbeforeunload ="onPageClose()">
<form id="form1" name="myfrom1" action="upLoadOfficeFile.php" enctype="multipart/form-data" style="padding:0px;margin:0px;" >
<input type="hidden" name="fileId" value="<?=$fileId?>" />
	<input type="hidden" name="Fileurl" value="<?=$_GET['Fileurl'];?>" />
	<input type="hidden" name="fileName" value="<?=$fileName?>" />
	<input type="hidden" name="filenumber" class="BigInput" value="<?=$_GET['filenumber']?>" />
	<input type="hidden" name="officetype" class="BigInput" value="<?=$_GET['officetype']?>" />
	<input type="hidden" name="uid" class="BigInput" value="<?=$_GET['uid']?>" />
	<input type="hidden" name="date" class="BigInput" value="<?=$_GET['date']?>" />
	<input type="hidden" name="otherData" id="otherdata" value="<?=$otherData?>" />
	<input type="hidden" name="attachFile" value="" />
	<?php
                                            if($isNewFile||strnatcasecmp($attachFileUrl,'')==0){
                                                echo  '<input name="attachFileDescribe" class="textstyle" type=hidden id=attachFileDescribe>';
                                            }else{
                                            print '已经存在的附件' ;
                                                echo '文档附件：<a href="'.$attachFileUrl.'" target=uploadattachfile>点击下载</a>&nbsp;'.($attachFileDescribe==''?'没有备注':$attachFileDescribe).')<br>';
                                                echo '<input name="attachFileDescribe" value="'.$attachFileDescribe.'" class="textstyle" type=hidden id=attachFileDescribe>';
                                            }
?>
<div class="search_area">
        <table width="95%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	<?php echo $_GET['title'];?>
	</td>
	<td align="right" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	<button type="button" onclick="SetReviewMode(true)" class="btn btn-primary">保留痕迹</button>
	<button type="button" onclick="SetReviewMode(false)" class="btn btn-primary">不留痕迹</button>
	<button type="button" onclick="setShowRevisions(true)" class="btn btn-primary">显示痕迹</button>
	<button type="button" onclick="setShowRevisions(false)" class="btn btn-primary">隐藏痕迹</button>
	<button type="button" onclick="addPicFromLocal();" class="btn btn-primary">插入图片</button>
	
	
	<button type="button" onclick="saveFileToUrl();" action="cancel_concern" class="btn btn-danger">保存文件</button> <button id="do_search" type="button" onClick="refreshParentss();" class="btn btn-success">关闭</button>
	</td>
  </tr>
</table>


        <table width="95%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" style="border-top:1px dashed #CCCCCC;">
  <tr>
    <td width="400" align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold; padding-top:15px;">
	<font color="#FF0000">文件套红:</font>
	  <select id=redHeadTemplateFile onchange="var headFileURL=document.all('redHeadTemplateFile').options[document.all('redHeadTemplateFile').selectedIndex].value;insertRedHeadFromUrl(headFileURL);" style="width:200px;">
	<option value="" selected>选择红头文件</option>  
     <?php
	  $query = $db->query("SELECT * FROM ".DB_TABLEPRE."seal where uid='".$_GET['uid']."' and sealtype='2' ORDER BY id desc");
	while ($seal = $db->fetch_array($query)) {?>
<option value="../<?=$seal['sealurl']?>"><?=$seal['sealtitle']?></option>
<?php }?>
		</select>
								
	<font color="#FF0000">服务器印章:</font>
	<select id="SignFileUrl" onchange="SignFileUrls();" style="width:160px;" title="测试印章密码统一为：111111">
	  <option value="" selected></option>
	  <?php
	  $num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE."seal where uid='".$_GET['uid']."' and sealtype='1' ORDER BY id desc");
	  if($num>0){
		  $query = $db->query("SELECT * FROM ".DB_TABLEPRE."seal where uid='".$_GET['uid']."' and sealtype='1' ORDER BY id desc");
		while ($seal = $db->fetch_array($query)) {?>
	<option value="../<?=$seal['sealurl']?>"><?=$seal['sealtitle']?></option>
	<?php
		}
	}else{
?>
<option value="esp/01.esp">天生创想协同OA办公系统</option>
<option value="esp/02.esp">中国移动通信集团江苏有限公司连云港分公司</option>
<option value="esp/03.esp">桂林天生智创信息技术有限公司</option>
<?php }?>
     </select></td>
	<td width="522" align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	<button type="button" onclick="DoCheckSign();" class="btn btn-primary">印章验证</button>
	<button type="button" onclick="addLocalSign();" class="btn btn-danger">电子印章</button>
	<button type="button" onclick="doHandSign();" class="btn btn-danger">手写签名</button>
	<button type="button" onclick="OFFICE_CONTROL_OBJ.SetReadOnly(true,'',1);" class="btn btn-success">保护印章</button>
	<button type="button" onclick="OFFICE_CONTROL_OBJ.SetReadOnly(false);" class="btn btn-success">取消保护</button>
	
	
	
	</td>
  </tr>
</table>

</div>
<div  style="position:absolute; height:82%; width:100%;overflow:auto; padding-top:10px;">

	
<table class="TableBlock" border="0" width="90%" align="center" style="margin-top:30px;">
	
	<tr>
      <td colspan="2" height="800">
	   <div id="officecontrol" height="800">
	  <!--引用NTKO OFFICE文档控件-->
<script type="text/javascript">
document.write('<!-- 用来产生编辑状态的ActiveX控件的JS脚本-->   ');
document.write('<!-- 因为微软的ActiveX新机制，需要一个外部引入的js-->   ');
document.write('<object id="TANGER_OCX" classid="clsid:C9BC4DFF-4248-4a3c-8A49-63A7D317F404"    ');
document.write('codebase="officecontrol/OfficeControl.cab#version=5,0,2,8" width="100%" height="800">   ');
document.write('<param name="IsUseUTF8URL" value="-1">   ');
document.write('<param name="IsUseUTF8Data" value="-1">   ');
document.write('<param name="BorderStyle" value="1">   ');
document.write('<param name="BorderColor" value="14402205">   ');
document.write('<param name="TitlebarColor" value="15658734">   ');
document.write('<param name="TitlebarTextColor" value="0">   ');
document.write('<param name="MenubarColor" value="14402205">   ');
document.write('<param name="MenuButtonColor" VALUE="16180947">   ');
document.write('<param name="MenuBarStyle" value="3">   ');
document.write('<param name="MenuButtonStyle" value="7">   ');
document.write('<param name="WebUserName" value="<?=$username?>">   ');
document.write('<param name="ProductCaption" value="中国移动通信集团江苏有限公司连云港分公司"> ');
document.write('<param name="ProductKey" value="B904EA29F73782027601EB922A23534AE4A0FE4E">');
document.write('<SPAN STYLE="color:red">不能装载文档控件。请在检查浏览器的选项中检查浏览器的安全设置。</SPAN>   ');
document.write('</object>');
</script>
                           <!--<div id=statusBar></div> -->
	<script language="JScript" for=TANGER_OCX event="OnFileCommand(cmd,canceled)">
		alert(cmd);
		CancelLastCommand=true;
	</script>
	<script language="JScript" for=TANGER_OCX event="OnDocumentClosed()">
		setFileOpenedOrClosed(false);
	</script>
	<script language="JScript" for=TANGER_OCX event="OnDocumentOpened(TANGER_OCX_str,TANGER_OCX_obj)">
		OFFICE_CONTROL_OBJ.ActiveDocument.Saved = true;//saved属性用来判断文档是否被修改过,文档打开的时候设置成ture,当文档被修改,自动被设置为false,该属性由office提供.
		setFileOpenedOrClosed(true);
	</script>
		<script language="JScript" for=TANGER_OCX event="BeforeOriginalMenuCommand(TANGER_OCX_str,TANGER_OCX_obj)">
		alert("BeforeOriginalMenuCommand事件被触发");
	</script>
	<script language="JScript" for=TANGER_OCX event="OnFileCommand(TANGER_OCX_str,TANGER_OCX_obj)">
		if (TANGER_OCX_str == 3)
		{
			alert("不能保存！");
			CancelLastCommand = true;
		}
	</script>
	<script language="JScript" for=TANGER_OCX event="AfterPublishAsPDFToURL(result,code)">
		result=trim(result);
		document.all("statusBar").innerHTML="服务器返回信息:"+result;
		if(result=="succeed")
		{window.close();}
	</script>
	</div>
	  </td>
	</tr>


  </table>

</div>
</form>
</body>
</html>
