<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
get_key("config_menu");
empty($do) && $do = 'list';
if($do == 'list') {
	 if(getGP('view','P')=='save'){
		 $idarr = getGP('id','P','array');
		 $number = getGP('number','P','array');
		 foreach ($idarr as $id) {
			 $mobile_model = array(
					 'number' =>$number[$id]
					 );
			update_db('mobile_model',$mobile_model, array('mid' => $id));
		 }
		 show_msg('手机应用操作成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&type='.$_GET['type']);
	}elseif(getGP('id','G')!=''){
		$db->query("DELETE FROM ".DB_TABLEPRE."mobile_model WHERE mid = '".getGP('id','G')."'  ");
		show_msg('手机应用删除成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&type='.$_GET['type']);
	}elseif(getGP('tid','G')!=''){
		$db->query("update ".DB_TABLEPRE."mobile_model set type1='".$_GET['type1']."' WHERE mid = '".getGP('tid','G')."'  ");
		show_msg('手机应用操作成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&type='.$_GET['type']);
	}else{
		if($_GET['type']==''){
			$type='menu';
		}else{
			$type=$_GET['type'];
		}
		$sql = "SELECT * FROM ".DB_TABLEPRE."mobile_model where type='".$type."' ORDER BY number asc";
		$result = $db->fetch_all($sql);
		include_once('template/mobile.php');
	}
}elseif ($do == 'add') {
	
	if($_POST['view']!=''){
		$id = getGP('id','P','int');
		if($id!=''){
			$title = getGP('title','P');
			$linkurl = getGP('linkurl','P');
			$ico = getGP('ico','P');
			if(getGP('modlist','P')=='全体人员'){
				$modlist='全体人员';
			}else{
				$modlist = getGP('modlist','P').',';
			}
			$type = getGP('type','P');
			
			$mobile_model = array(
				'title' => $title,
				'linkurl' => $linkurl,
				'ico' => $ico,
				'modlist' => $modlist
			);
			update_db('mobile_model',$mobile_model, array('mid' => $id));
		}else{
			$title = getGP('title','P');
			$linkurl = getGP('linkurl','P');
			$ico = getGP('ico','P');
			if(getGP('modlist','P')==''){
				$modlist='全体人员';
			}else{
				$modlist = getGP('modlist','P').',';
			}
			$type = getGP('type','P');
			$mobile_model = array(
				'title' => $title,
				'linkurl' => $linkurl,
				'ico' => $ico,
				'modlist' => $modlist,
				'type' => $type,
				'type1' => 1,
				'number' =>999
			);
			insert_db('mobile_model',$mobile_model);
		}
		show_msg('应用信息操作成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&type='.$type.'');
	}else{
		$id = getGP('id','G','int');
		if($id!=''){
			$user = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE."mobile_model WHERE mid = '$id' ");
			$_title['name']='编辑';
		}else{
			$_title['name']='发布';
		}
		include_once('template/mobileadd.php');
		
	}
	
}

?>