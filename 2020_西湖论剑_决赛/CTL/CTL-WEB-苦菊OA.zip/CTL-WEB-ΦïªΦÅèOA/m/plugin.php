<?php
/*
	[Office 515158] (C) 2009-2014 天生创想 Inc.
	$Id: index.php mobile $
*/
define('IN_ADMIN',True);
require_once('../include/common.php');
require_once('../include/function_weixin.php');
$mid = getGP('mid','G','int');
$row = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE."mobile_model WHERE mid = '".$mid."' ");
if ($row['linkurl']!=""){
	$fileurl=$row['linkurl'];
}else{
	$fileurl="http://www.phpoa.cn/";
}
if($row['title']!=''){
	$title=$row['title'];
}else{
	$title='PHPOA';
}
include_once 'template/plugin.php';
?>