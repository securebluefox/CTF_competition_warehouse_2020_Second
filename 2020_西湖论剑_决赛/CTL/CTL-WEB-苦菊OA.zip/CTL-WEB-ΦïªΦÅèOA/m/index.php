<?php
/*
	[Office 515158] (C) 2009-2014 天生创想 Inc.
	$Id: index.php mobile $
*/
define('IN_ADMIN',True);
require_once('../include/common.php');
require_once('function/common.class.php');
/*function UserAgent(){   
    $user_agent = ( !isset($_SERVER['HTTP_USER_AGENT'])) ? FALSE : $_SERVER['HTTP_USER_AGENT'];   
    return $user_agent;   
} 
//Mobile   
if ((preg_match("/(iphone|ipod|android)/i", strtolower(UserAgent()))) && strstr(strtolower(UserAgent()), 'webkit')){   
}elseif(trim(UserAgent()) == '' || preg_match("/(nokia|sony|ericsson|mot|htc|samsung|sgh|lg|philips|lenovo|ucweb|opera mobi|windows mobile|blackberry)/i", strtolower(UserAgent()))){     
}else{
	header('Location: ../login.php');   
    exit;
}*/
get_login($_USER->id);
if ($_GET[fileurl]!=""){
	$fileurl=$_GET[fileurl];
}else{
	$fileurl="home";
}
if($fileurl=="home"){
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE."mobile_model WHERE type1=1 and (modlist like '%".get_realname($_USER->id).",%' or modlist='全体人员') order by number asc");
	$sql = "SELECT * FROM ".DB_TABLEPRE."mobile_model WHERE type1=1 and (modlist like '%".get_realname($_USER->id).",%' or modlist='全体人员')  order by number asc";
	$result = $db->fetch_all($sql);
	include_once 'template/index.php';
}else{
	define('ADMIN_ROOT', TOA_ROOT.'m/'.$fileurl.'/');
	initGP(array('ac','do'));
	empty($ac) && $ac = 'index';
	if ( !eregi('[a-z_]', $ac) ) $ac = 'index';
	if ( file_exists(ADMIN_ROOT."mod_{$ac}.php") ) {
			require_once(ADMIN_ROOT.'/mod_'.$ac.'.php');
		} else {
			exit;
	}
}

?>