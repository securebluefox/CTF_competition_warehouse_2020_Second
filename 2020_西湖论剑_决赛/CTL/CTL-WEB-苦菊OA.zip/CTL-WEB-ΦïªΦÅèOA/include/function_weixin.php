<?php
!defined('IN_TOA') && exit('Access Denied!');
/*
	[Office 515158] (C) 2009-2015 天生创想 Inc.
	$Id: function_weixin.php 1209087 2015-01-08
*/

?>