<?php
/*
	[Office 515158] (C) 2009-2012 天生创想 Inc.
	$Id: function_work.php 1209087 2012-01-08 08:58:28Z baiwei.jiang $
*/
!defined('IN_TOA') && exit('Access Denied!');
//工作流类型下拉
function work_type_options($selid = 0) {
	global $_CACHE;
	$html = '';
	get_cache('workclass_type');
	foreach ( $_CACHE['workclass_type'] as $row) {
		$selstr = $row['tid'] == $selid ? 'selected="selected"' : '';
		$html .= '<option value="'.$row['tid'].'" '.$selstr.'>'.$row['typename'].'</option>';	
	}
	return $html;
}
//直接获取流程信息
function w_p_v($id=0,$wid=0,$value=''){
	global $db;
	$row = $db->fetch_one_array("SELECT ".$value.",perid,appkey FROM ".DB_TABLEPRE."workclass_personnel where flowid='".$id."' and workid='".$wid."' and pertype!=0 ORDER BY perid Asc");
	if($row['appkey']==2){
		return $row[$value];
	}else{
		$sql = "SELECT ".$value.",pertype FROM ".DB_TABLEPRE."workclass_personnel_log WHERE perid='".$row['perid']."' ORDER BY lid asc";
		$result = $db->query($sql);
		while ($log = $db->fetch_array($result)) {
			if($log['pertype']!=0){
				$html.=$log[$value].',';
			}
		}
		return substr($html, 0, -1);
	}
}

//获取工作流数据
function work_db($id=0,$name=''){
	global $db;
	$tpl = $db->fetch_one_array("SELECT tplid FROM ".DB_TABLEPRE."workclass where id='".$id."'");
	$row = $db->fetch_one_array("SELECT ".$name." FROM ".DB_TABLEPRE."workclass_db_".$tpl['tplid']." where workid='".$id."'  ORDER BY did Asc");
	return $row[$name];	
	//$row = $db->fetch_one_array("SELECT content,fromid FROM ".DB_TABLEPRE."workclass_db where workid='".$id."' and inputname='".$name."'  ORDER BY did Asc");
	//获取表单数据
	//$flow = $db->fetch_one_array("SELECT inputtype FROM ".DB_TABLEPRE."workclass_from where fromid='".$row['fromid']."' ORDER BY fromid Asc");
	//if($flow['inputtype']=='2'){
	//	if($row['content']!=''){
	//		return '<a href="down.php?urls='.$row['content'].'">下载附件</a>';
	//	}	
	//}else{
	//	return $row['content'];	
	//}
}
//单选
function get_work_radio($name='',$radiovalue='',$value=''){
		$inputvaluenum=explode('|',$radiovalue); 
		$html.='<!--{radio'.$name.'start}-->';
		for($i=0;$i<sizeof($inputvaluenum);$i++){
			$html.= '<input name="'.$name.'" type="radio" value="'.$inputvaluenum[$i].'" ';
			if($value==''){
				if($i==0){
					$html.= 'checked="checked"';
				}
			}else{
				if(trim($value)==trim($inputvaluenum[$i])){
					$html.= 'checked="checked"';
				}
			}
			$html.= '/>'.$inputvaluenum[$i].' ';
		}
		$html.='<!--{radio'.$name.'end}-->';
	return $html;
}
//多选
function get_work_checkbox($name='',$radiovalue='',$value=''){
		$inputvaluenum=explode('|',$radiovalue); 
		$html.='<!--{checkbox'.$name.'start}-->';
		for($i=0;$i<sizeof($inputvaluenum);$i++){
			$html.= '<input name="'.$name.'[]" type="checkbox" value="'.$inputvaluenum[$i].'" ';
			if($value==''){
				if($i=='0'){
					$html.= 'checked="checked"';
				}
			}else{
				if(sizeof(explode($inputvaluenum[$i],$value))>1){
					$html.= 'checked="checked"';
				}
			}
			$html.= '/>'.$inputvaluenum[$i].' ';
		}
		$html.='<!--{checkbox'.$name.'end}-->';
	return $html;
}
//日期
function get_work_date($name='',$w,$h,$value){
	if($w=='' || $w=='0') $w='180';
	if($h=='' || $h=='0') $h='20';
	return '<input class="BigInput" style="width:'.$w.'px;height:'.$h.'px;line-height:'.$h.'px;font-size:14px;margin-top:6px;" type="text" value="'.$value.'" name="'.$name.'" onClick="WdatePicker();" />';
}

//文本域
function get_work_input($name='',$w,$h,$value=''){
	if($w=='' || $w=='0') $w='260';
	if($h=='' || $h=='0') $h='20';
	return '<input type="text" class="span3" name="'.$name.'" style="width:'.$w.'px;height:'.$h.'px;line-height:'.$h.'px;font-size:14px;margin-top:6px;" value="'.$value.'" />';
}
//下拉框
function get_work_select($name='',$radiovalue='',$value='',$w,$h){
	if($w=='' || $w=='0') $w='260';
	if($h=='' || $h=='0') $h='30';
	$inputvaluenum=explode('|',$radiovalue); 
	$html.='<!--{option'.$name.'start}-->';
	$html.='<select class="span3" name="'.$name.'" id="'.$name.'" style="width:'.$w.'px;height:'.$h.'px;line-height:'.$h.'px;font-size:14px;margin-top:6px;">';
	$html.='<option value="" selected="selected">选择内容</option>';
	for($i=0;$i<sizeof($inputvaluenum);$i++){
		if($inputvaluenum[$i]==$value){
			$selected='  selected="selected"';
		}else{
			$selected='';
		}
		$html.='<option value="'.$inputvaluenum[$i].'" '.$selected.'>'.$inputvaluenum[$i].'</option>';	
	}
	$html.='</select> ';
	$html.='<!--{option'.$name.'end}-->';
	return $html;
}
//宏控件
function get_magnificent($name='',$radiovalue='',$value='',$magnificent){
	if($w=='' || $w=='0') $w='260';
	if($h=='' || $h=='0') $h='30';
	global $db;
	global $_CACHE;
	get_cache('magnificent');
	$html.='<!--{option'.$name.'start}-->';
	$html.='<select class="span3" name="'.$name.'" id="'.$name.'" style="width:'.$w.'px;height:'.$h.'px;line-height:'.$h.'px;font-size:14px;margin-top:6px;">';
	$html.='<option value="" selected="selected"></option>';
	$query = $db->query("SELECT ".$_CACHE['magnificent'][$magnificent]['name'].",".$_CACHE['magnificent'][$magnificent]['value']." FROM ".DB_TABLEPRE.$_CACHE['magnificent'][$magnificent]['table']."  ORDER BY ".$_CACHE['magnificent'][$magnificent]['order']." Asc");
	while ($row = $db->fetch_array($query)) {
		if($row[$_CACHE['magnificent'][$magnificent]['value']]==$value){
			$selected='  selected="selected"';
		}else{
			$selected='';
		}
		$html.='<option value="'.$row[$_CACHE['magnificent'][$magnificent]['value']].'" '.$selected.'>'.$row[$_CACHE['magnificent'][$magnificent]['name']].'</option>';	
	}
	$html.='</select> ';
	$html.='<!--{option'.$name.'end}-->';
	return $html;
}
//文本框
function get_work_textarea($name='',$w,$h,$value=''){
	if($w=='' || $w=='0') $w='600';
	if($h=='' || $h=='0') $h='200';
	$_CONFIG=new config();
	if($_CONFIG->config_data('configwork')=='1'){
		$html.= '<textarea name="'.$name.'" id="'.$name.'" style="width:'.$w.'px;height:'.$h.'px;margin-top:6px;margin-bottom:6px;" class="ckeditor">'.$value.'</textarea>';
	}else{
		$html.= '<textarea name="'.$name.'" style="width:'.$w.'px;height:'.$h.'px;margin-top:6px;margin-bottom:6px;" class="span3">'.$value.'</textarea>';
	}
	return $html;
}
//模板植入单框数据读取
function W_I_DB($typeid=0,$tplid=0,$inputname='',$w=0,$h=0,$value='',$type6=0){
	global $db;
	$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE."workclass_from where typeid='".$typeid."' and tplid='".$tplid."' and inputname='".$inputname."'  ORDER BY fromid Asc");
	if($tpl['inputtype']=='0'){
		if($tpl["inputtype1"]=='1'){
			return get_work_input($tpl["inputname"],$w,$h,$value);
		}elseif($tpl["inputtype1"]=='2'){
			return get_work_textarea($tpl["inputname"],$w,$h,$value);
		}elseif($tpl["inputtype1"]=='3'){
			return get_work_radio($tpl["inputname"],$tpl["inputvaluenum"],$value);
		}elseif($tpl["inputtype1"]=='4'){
			return get_work_checkbox($tpl["inputname"],$tpl["inputvaluenum"],$value);		
		}elseif($tpl["inputtype1"]=='5'){
			return get_work_select($tpl["inputname"],$tpl["inputvaluenum"],$value);	
		}
	}elseif($tpl["inputtype"]=='1'){
		//return public_upload($tpl["inputname"],'',$w,$h,'图片上传');
		$html= '<input type="text" name="'.$tpl["inputname"].'" class="span3" style="width:'.$w.'px;height:'.$h.'px;line-height:'.$h.'px;font-size:14px;margin-top:6px;" value="'.$value.'" />';
		$html.= '<a href="#" onClick="';
		$html.= "window.open ('admin.php?ac=uploadadd&fileurl=public&name=".$tpl["inputname"]."', ";
		$html.= "'".$tpl["inputname"]."', 'height=200, width=480, top=0, left=0, toolbar=no, ";
		$html.= "menubar=no, scrollbars=yes, resizable=no,location=no, status=no'";
		$html.= ')">+图片上传</a>';
		return $html;
	}elseif($tpl["inputtype"]=='2'){
		$html= '<input type="text" name="'.$tpl["inputname"].'" class="span3" style="width:'.$w.'px;height:'.$h.'px;line-height:'.$h.'px;font-size:14px;margin-top:6px;" value="'.$value.'" />';
		$html.= '<a href="#" onClick="';
		$html.= "window.open ('admin.php?ac=uploadadd&fileurl=public&name=".$tpl["inputname"]."', ";
		$html.= "'".$tpl["inputname"]."', 'height=200, width=480, top=0, left=0, toolbar=no, ";
		$html.= "menubar=no, scrollbars=yes, resizable=no,location=no, status=no'";
		$html.= ')">+附件上传</a>';
		return $html;
	}elseif($tpl["inputtype"]=='3'){
		return get_work_date($tpl["inputname"],$w,$h,$value);
	}elseif($tpl["inputtype"]=='4'){
		//$_USER = new User();
		//return get_depabox(1,$tpl["inputname"],get_depauseridname($_USER->id),"+选择部门",$w,$h);
		$dep= "<input type='text' name='".$tpl["inputname"]."' style='width:".$w."px;height:".$h."px;background-color:#F5F5F5;color:#006600;margin-top:6px;' value='".$value."' readonly />";
        $dep.= '<a href="#" onClick="window.open ';
		$dep.="('admin.php?ac=dep_radio&fileurl=public&inputname=".$tpl["inputname"]."', '".$tpl["inputname"]."', 'height=500, width=500, top=50, left=100, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no')";
		$dep.='">+选择部门</a>';
		return $dep;
	}elseif($tpl["inputtype"]=='5'){
		//return get_pubuser(1,$tpl["inputname"],"","+选择人员",$w,$h);
	   $user= "<input type='text' name='".$tpl["inputname"]."' style='width:".$w."px;height:".$h."px;background-color:#F5F5F5;color:#006600;margin-top:6px;' value='".$value."' readonly />";
       $user.='<a href="javascript:;" onClick="window.open (';
	   $user.="'admin.php?ac=user_radio&fileurl=public&inputname=".$tpl["inputname"]."', '".$tpl["inputname"]."', 'height=500, width=500, top=50, left=100, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no'";
	   $user.=')">+选择人员</a>';
	   return $user;
	}elseif($tpl["inputtype"]=='6'){
		if($type6!=0){
			return '<textarea name="'.$tpl["inputname"].'[]" style="width:'.$w.'px;font-size:14px;" rows="'.$h.'">'.$value.'</textarea>';
		}else{
			return '<input type="text" name="'.$tpl["inputname"].'[]" style="border:1px;line-height:'.$h.'px;width:'.$w.'px;height:'.$h.'px;font-size:14px;margin-top:6px;" class="BigInput" value="'.$value.'" />';
		}
	}elseif($tpl["inputtype"]=='7'){
		//return get_magnificent($tpl["inputname"],$tpl["inputvaluenum"],$value,$tpl["magnificent"]);	
		return '{宏控件'.$tpl["magnificent"].$tpl["inputname"].'}';
	}elseif($tpl["inputtype"]=='8'){
		return '<!--{流程控件'.$tpl["magnificent"].$tpl["inputname"].'}-->';
	}
}
function work_pertype($type){
	switch ($type)
	{
		case 0:
		  echo "未审批";
		  break;
		case 1:
		  echo "通过";
		  break;
		case 2:
		  echo "拒绝";
		  break;
		case 3:
		  echo "退回";
		  break;
		case 4:
		  echo "等待审批";
		  break;
		case 5:
		  echo "结束";
		  break;
		default:
		  echo "错误类型";
	}
	return ;
}
function work_pertype_log($type){
	switch ($type)
	{
		case 0:
		  echo "未审批";
		  break;
		case 1:
		  echo "通过";
		  break;
		case 2:
		  echo "拒绝";
		  break;
		case 3:
		  echo "退回";
		  break;
		default:
		  echo "错误类型";
	}
	return ;
}
//获取并过滤表单数据
function work_adddb($tplid,$typeid,$workid,$tpladdr,$flowid){
	global $db;
	global $_USER;
	$query = $db->query("SELECT inputname,inputtype,magnificent,inputtype1,inputvaluenum FROM ".DB_TABLEPRE."workclass_from where tplid='".$tplid."' and typeid='".$typeid."' and inputtype!='6' ORDER BY inputnumber Asc");
	while ($row = $db->fetch_array($query)) {
		$values=public_value($row['inputname'],'wd_'.$tplid,'workid='.$workid);
		if($flowid!=''){
			$formkey=public_value('formkey','workclass_flow','fid='.$flowid);
		}
		if($values!=''){
			if($row['inputtype1']==3){
			    $values=get_work_radio($row["inputname"],$row["inputvaluenum"],$values);
				$addr=get_subcontent($tpladdr,'<!--{radio'.$row['inputname'].'start}-->','<!--{radio'.$row['inputname'].'end}-->');
				$tpladdr=str_replace($addr,$values,$tpladdr);
			}elseif($row['inputtype1']==4){
				$values=get_work_checkbox($row["inputname"],$row["inputvaluenum"],$values);
				$addr=get_subcontent($tpladdr,'<!--{checkbox'.$row['inputname'].'start}-->','<!--{checkbox'.$row['inputname'].'end}-->');
				$tpladdr=str_replace($addr,$values,$tpladdr);
			}elseif($row['inputtype1']==5){
				$values=get_work_select($row["inputname"],$row["inputvaluenum"],$values);
				$addr=get_subcontent($tpladdr,'<!--{option'.$row['inputname'].'start}-->','<!--{option'.$row['inputname'].'end}-->');
				$tpladdr=str_replace($addr,$values,$tpladdr);
			}elseif($row['inputtype']==7){
				$tpladdr=str_replace("{宏控件".$row['magnificent'].$row['inputname']."}",get_magnificent($row["inputname"],'',$values,$row["magnificent"]),$tpladdr);
			}else{
				$tpladdr=str_replace("{".$row['inputname']."}",$values,$tpladdr);
			}
		}else{
			if($row['inputtype']==3){
				$tpladdr=str_replace("{".trim($row['inputname'])."}",get_date('Y-m-d',PHP_TIME),$tpladdr);
			}elseif($row['inputtype']==4){
				$tpladdr=str_replace("{".$row['inputname']."}",get_realdepaname(public_value('departmentid','user','id='.$_USER->id)),$tpladdr);
			}elseif($row['inputtype']==5){
				$tpladdr=str_replace("{".$row['inputname']."}",get_realname($_USER->id),$tpladdr);
			}elseif($row['inputtype']==7){
				$tpladdr=str_replace("{宏控件".$row['magnificent'].$row['inputname']."}",get_magnificent($row["inputname"],'',$value,$row["magnificent"]),$tpladdr);
			}else{
				$tpladdr=str_replace("{".$row['inputname']."}",'',$tpladdr);
			}
		}
		if(sizeof(explode('"'.$row['inputname'].'"',$formkey))>1){
			
		}else{
			$tpladdr=str_replace('name="'.$row['inputname'],'disabled="disabled" name="'.$row['inputname'],$tpladdr);
		}
		
	}
	return $tpladdr;
}

function work_adddb_view($tplid,$typeid,$workid,$tpladdr){
		global $db;
		global $_USER;
		$query = $db->query("SELECT fromid,fromname FROM ".DB_TABLEPRE."workclass_from where tplid='".$tplid."' and typeid='".$typeid."' and inputtype='6' ORDER BY inputnumber Asc");
			while ($from = $db->fetch_array($query)) {
				$addr='';
				$addrs='';
				$addr=get_subcontent($tpladdr,'<!--{'.$from['fromid'].$from['fromname'].'forstart}-->','<!--{'.$from['fromid'].$from['fromname'].'forend}-->');
				$nums = $db->result("SELECT COUNT(*) AS nums FROM ".DB_TABLEPRE."wd_".$tplid."_".$from['fromid']." where tplid='".$tplid."' and typeid='".$typeid."' and fromid='".$from['fromid']."' and workid='".$workid."' ORDER BY vid asc");
				$sqlv = "SELECT * FROM ".DB_TABLEPRE."wd_".$tplid."_".$from['fromid']." where tplid='".$tplid."' and typeid='".$typeid."' and fromid='".$from['fromid']."' and workid='".$workid."' ORDER BY vid asc";
				$results = $db->fetch_all($sqlv);
				$work_addforms='';
				$work_addforms= work_addform($tplid,$typeid,$from['fromid']);
				$form_view=explode(',',$work_addforms);
				$addrs=$addr;
				if($nums>0){
					$j=0;
					$addrs1='';
					$addrss='';
					foreach ($results as $row) {
					$addrs1=$addrs;
					$j++;
						for($i=0;$i<sizeof($form_view);$i++){
							if($row[$form_view[$i]]!=''){
								$addrs1=str_replace('{'.$form_view[$i].'}',$row[$form_view[$i]],$addrs1);
							}else{
								$addrs1=str_replace('{'.$form_view[$i].'}','',$addrs1);
							}
						}
						$addrss.=str_replace('{序号}',$j,$addrs1);
					}
					$addrs=$addrss;
				}else{
					$addrs1='';
					$addrss='';
					$addrs1=$addrs;
					for($i=0;$i<sizeof($form_view);$i++){
						$addrs1=str_replace('{'.$form_view[$i].'}','',$addrs1);
					}

					for($i=1;$i<=3;$i++){
						$addrss.=str_replace('{序号}',$i,$addrs1);
					}
					$addrs=$addrss;
				}
				$tpladdr=str_replace($addr,$addrs,$tpladdr);
			}
	return $tpladdr;
}

//获取表单
function work_addform($tplid,$typeid,$fromid){
	global $db;
	$html='';
	$query = $db->query("SELECT inputname FROM ".DB_TABLEPRE."workclass_from_view where tplid='".$tplid."' and typeid='".$typeid."' and fromid='".$fromid."'");
	while ($row = $db->fetch_array($query)) {
		$html.=$row['inputname'].',';
	}
	return substr($html, 0, -1);
}
//更新主表信息
function workflow_update(){
	global $db;
	global $_USER;
	$workclass = array();
	if(getGP('numberview','P')!=''){
		$workclass['numberview']=check_str(getGP('numberview','P'));
	}
	$workclass['number']=check_str(getGP('number','P'));
	$workclass['title']=check_str(getGP('title','P'));
	update_db('workclass',$workclass, array('id' =>getGP('workid','P','int'),'uid'=>$_USER->id));
}
//更新表单信息
function workform_update(){
	global $db;
	global $_USER;
	$workform = array();
	$workid=getGP('workid','P','int');
	$tplid=getGP('tplid','G','int');
	$typeid=getGP('typeid','G','int');
	$flowid=getGP('flowid','P','int');
	$formkey=public_value('formkey','workclass_flow','fid='.$flowid);
	if(sizeof(explode('toa',$formkey))>1){
	$query = $db->query("SELECT * FROM ".DB_TABLEPRE."workclass_from where tplid='".$tplid."' and typeid='".$typeid."' and inputtype!=6 ORDER BY fromid Asc");
	while ($row = $db->fetch_array($query)) {
		if(sizeof(explode('"'.$row['inputname'].'"',$formkey))>1){
			if($row['inputtype1']=='4'){
				$inputvalues='';
				$inputvalue=getGP(''.$row["inputname"].'','P','array');
				foreach ($inputvalue as $arrsave) {
					$inputvalues.=$arrsave.'|';
				}
				$workform[$row["inputname"]]=substr($inputvalues, 0, -1);
			}else{
				$workform[$row["inputname"]]=trim(getGP(''.$row["inputname"].'','P'));
			}
		}
	}
	update_db('wd_'.$tplid,$workform, array('workid' =>$workid,'tplid'=>$tplid,'typeid'=>$typeid));
	}
	
}
function workform_view_update(){
	global $db;
	global $_USER;
	$workid=getGP('workid','P','int');
	$tplid=getGP('tplid','G','int');
	$typeid=getGP('typeid','G','int');
	$inputname6=getGP('inputname6','P','array');
	foreach ($inputname6 as $from) {
		if($from!=''){
			$froms=explode(',',$from);
			$workform = array();
			$workform[$froms[0]]=$froms[1];
			update_db('wd_'.$tplid,$workform, array('workid' =>$workid,'tplid'=>$tplid,'typeid'=>$typeid));
			$sqld="DELETE FROM ".DB_TABLEPRE."wd_".$tplid."_".$froms[1]." WHERE workid = '".$workid."' and tplid = '".$tplid."' and typeid = '".$typeid."' and fromid = '".$froms[1]."' ";
			$db->query($sqld);
			$t6=getGP('t6'.$froms[1].'','P','array');
			foreach ($t6 as $value) {
				$t6s.=$value.',';
			}
			$t6s=substr($t6s, 0, -1);
			$t6s=explode(',',$t6s);
			for($i=0;$i<sizeof($t6s);$i++){
				$workformview = array();
				$query = $db->query("SELECT inputname FROM ".DB_TABLEPRE."workclass_from_view where tplid='".$tplid."' and typeid='".$typeid."' and fromid='".$froms[1]."' ORDER BY viewid Asc");
				$a1='';
				while ($row = $db->fetch_array($query)) {
					$a=serialize(getGP(''.$row["inputname"].'','P','array'));
					$a1=unserialize($a);
					$workformview[$row["inputname"]]=$a1[$i];
				}
				$workformview['workid']=$workid;
				$workformview['tplid']=$tplid;
				$workformview['typeid']=$typeid;
				$workformview['fromid']=$froms[1];
				insert_db('wd_'.$tplid.'_'.$froms[1],$workformview);
			}
		}
	}	
}
//获取数据
function work_viewdb($tplid,$typeid,$workid,$tpladdr){
	global $db;
	global $_USER;
	$query = $db->query("SELECT inputname,inputtype,inputtype1,inputvaluenum,magnificent FROM ".DB_TABLEPRE."workclass_from where tplid='".$tplid."' and typeid='".$typeid."' and inputtype!='6' ORDER BY inputnumber Asc");
	while ($row = $db->fetch_array($query)) {
		$values=public_value($row['inputname'],'wd_'.$tplid,'workid='.$workid);
		if($values!=''){
			if($row['inputtype1']==4){
				$values=str_replace("|",',',$values);
				$tpladdr=str_replace("<!--{".$row['inputname']."}-->",$values,$tpladdr);
			}elseif($row['inputtype']=='1'){
				$tpladdr=str_replace("<!--{".$row['inputname']."}-->",'<a href="down.php?urls='.$values.'">下载图片</a>| <a href="'.$values.'" target="_blank">查看</a>',$tpladdr);
			}elseif($row['inputtype']=='2'){
				$tpladdr=str_replace("<!--{".$row['inputname']."}-->",'<a href="down.php?urls='.$values.'">下载附件</a>',$tpladdr);
			}else{
				$tpladdr=str_replace("<!--{".$row['inputname']."}-->",$values,$tpladdr);
			}
		}else{
			if($row['inputtype']=='8'){
				//$addr=get_subcontent($tpladdr,"<!--".$row['inputname']."s-->","<!--".$row['inputname']."e-->");
				//<!--toa_5073_20150323222744s--><!--{toa_5073_20150323222744}--><!--toa_5073_20150323222744e-->
				//$addr=str_replace("<!--{",'',str_replace("}-->",'',$addr));
				//$tpladdr=str_replace("&nbsp;",'',$tpladdr);
				$tpladdr=str_replace("<!--".$row['inputname']."s--><!--{".$row['inputname']."}--><!--".$row['inputname']."e-->",work_flows($row['magnificent'],$workid),$tpladdr);
			}
		}
	}
	return $tpladdr;
}
function work_flows($flowid,$workid){
	global $db;
	global $_USER;
	$html='';
	$sql = "SELECT flowkey2 FROM ".DB_TABLEPRE."workclass_flow  WHERE fid = '".$flowid."'";
	$flow = $db->fetch_one_array($sql);
	if($flow['flowkey2']==2){
		$sqls = "SELECT * FROM ".DB_TABLEPRE."workclass_personnel where workid='".$workid."' and flowid='".$flowid."' and pertype!=0  order by perid asc";
		$result = $db->fetch_all($sqls);
		foreach ($result as $pers) {
			$html.='<table width="96%" border="0" cellspacing="0" cellpadding="0" style="margin-left:6px;margin-right:6px;">';
			$html.='<tr>';
			$html.='<td height="30" align="left" valign="middle" style="font-size:14px;">';
			$lnstructions=$pers['lnstructions'];
			$lnstructions=str_replace("<p>",'',$lnstructions);
			$lnstructions=str_replace("</p>",'',$lnstructions);
			$html.=$lnstructions.'</td>';
			$html.='</tr><tr>';
			$html.='<td height="25" align="left" valign="middle" style="font-size:14px;">审批人：'.$pers['name'].'</td>';
			$html.='</tr><tr>';
			$html.='<td align="left" valign="middle" style="font-size:14px;">日期：'.$pers['approvaldate'].'</td>';
			$html.='</tr></table>';
	    }
	}else{
		$sqlss = "SELECT * FROM ".DB_TABLEPRE."workclass_personnel  WHERE workid='".$workid."' and flowid='".$flowid."' and pertype!=0";
		$workid = $db->fetch_one_array($sqlss);
		$sqls = "SELECT * FROM ".DB_TABLEPRE."workclass_personnel_log where workid='".$workid."' and perid='".$workid['perid']."' and pertype!=0  order by perid asc";
		$result = $db->fetch_all($sqls);
		foreach ($result as $pers) {
			$html.='<table width="96%" border="0" cellspacing="0" cellpadding="0" style="margin-left:6px;margin-right:6px;">';
			$html.='<tr>';
			$html.='<td height="30" align="left" valign="top" style="font-size:14px;">';
			$lnstructions=$pers['lnstructions'];
			$lnstructions=str_replace("<p>",'',$lnstructions);
			$lnstructions=str_replace("</p>",'',$lnstructions);
			$html.=$lnstructions.'</td>';
			$html.='</tr><tr>';
			$html.='<td height="25" align="left" valign="middle" style="font-size:14px;">审批人：'.$pers['name'].'</td>';
			$html.='</tr><tr>';
			$html.='<td align="left" valign="middle" style="font-size:14px;">日期：'.$pers['approvaldate'].'</td>';
			$html.='</tr></table>';
	    }
	}
	return $html;			
}

function work_viewdb_view($tplid,$typeid,$workid,$tpladdr){
		global $db;
		global $_USER;
		$query = $db->query("SELECT fromid,fromname FROM ".DB_TABLEPRE."workclass_from where tplid='".$tplid."' and typeid='".$typeid."' and inputtype='6' ORDER BY inputnumber Asc");
			while ($from = $db->fetch_array($query)) {
				$addr=get_subcontent($tpladdr,'<!--{'.$from['fromid'].$from['fromname'].'forstart}-->','<!--{'.$from['fromid'].$from['fromname'].'forend}-->');
				$nums = $db->result("SELECT COUNT(*) AS nums FROM ".DB_TABLEPRE."wd_".$tplid."_".$from['fromid']." where tplid='".$tplid."' and typeid='".$typeid."' and fromid='".$from['fromid']."' and workid='".$workid."' ORDER BY vid asc");
				$sqlv = "SELECT * FROM ".DB_TABLEPRE."wd_".$tplid."_".$from['fromid']." where tplid='".$tplid."' and typeid='".$typeid."' and fromid='".$from['fromid']."' and workid='".$workid."' ORDER BY vid asc";
				$results = $db->fetch_all($sqlv);
				$work_addforms= work_addform($tplid,$typeid,$from['fromid']);
				$form_view=explode(',',$work_addforms);
				$addrs=$addr;
				if($nums>0){
					$j=0;
					$addrs1='';
					$addrss='';
					foreach ($results as $row) {
					$addrs1=$addrs;
					$j++;
						for($i=0;$i<sizeof($form_view);$i++){
							if($row[$form_view[$i]]!=''){
								$addrs1=str_replace('<!--{'.$form_view[$i].'}-->',$row[$form_view[$i]],$addrs1);
							}else{
								$addrs1=str_replace('<!--{'.$form_view[$i].'}-->','',$addrs1);
							}
						}
						$addrss.=str_replace('{序号}',$j,$addrs1);
					}
					$addrs=$addrss;
				}else{
					$addrs1=$addrs;
					for($i=0;$i<sizeof($form_view);$i++){
						
						$addrs1=str_replace('<!--{'.$form_view[$i].'}-->','',$addrs1);
					}

					for($i=1;$i<=10;$i++){
						$addrss.=str_replace('{序号}',$i,$addrs1);
					}
					$addrs=$addrss;
				}
				$tpladdr=str_replace($addr,$addrs,$tpladdr);
			}
	return $tpladdr;
}

function work_modid($type){
	switch ($type)
	{
		case 1:
		  return "考勤";
		  break;
		case 2:
		  return "用车";
		  break;
		default:
		  return "流程";
	}
}
//新成员审批条件
function work_newuser($_flowusertype,$_flowuser){
	global $db;
	global $_USER;
	if($_flowusertype=='2'){
		$html='';
		$flowuser=explode(',',$_flowuser);
		for($i=0;$i<sizeof($flowuser);$i++){
			if(trim($flowuser[$i])!=''){
				$sqluser = "SELECT b.name FROM ".DB_TABLEPRE."user a,".DB_TABLEPRE."user_view b where a.id=b.uid and  a.positionid like '%,".trim($flowuser[$i]).",%'  ORDER BY b.uid desc";
				$rowuserresult = $db->fetch_all($sqluser);
				foreach ($rowuserresult as $rowuser1) {
					if($rowuser1['name']!=''){
						$html.=$rowuser1['name'].',';
					}
				}
			}
		}
		$flowuser1=substr($html, 0, -1);
	}elseif($_flowusertype=='3'){
		$html='';
		$flowuser=explode(',',$_flowuser);
		for($i=0;$i<sizeof($flowuser);$i++){
			if(trim($flowuser[$i])!=''){
				$sqluser = "SELECT b.name FROM ".DB_TABLEPRE."user a,".DB_TABLEPRE."user_view b where a.id=b.uid and  a.departmentid like '%,".trim($flowuser[$i]).",%'  ORDER BY b.uid desc";
				$rowuserresult = $db->fetch_all($sqluser);
				foreach ($rowuserresult as $rowuser1) {
					if($rowuser1['name']!=''){
						$html.=$rowuser1['name'].',';
					}
				}
			}
		}
		$flowuser1=substr($html, 0, -1);
	}elseif($_flowusertype=='4'){
		$html='';
		$r = $db->fetch_one_array("SELECT departmentid FROM ".DB_TABLEPRE."user WHERE id = '".$_USER->id."'  ");
		$flowuser=explode(',',$r['departmentid']);
		for($i=0;$i<sizeof($flowuser);$i++){
			if(trim($flowuser[$i])!=''){
				$sqluser = "SELECT b.name FROM ".DB_TABLEPRE."user a,".DB_TABLEPRE."user_view b where a.id=b.uid and  a.departmentid like '%,".trim($flowuser[$i]).",%'  ORDER BY b.uid desc";
				$rowuserresult = $db->fetch_all($sqluser);
				foreach ($rowuserresult as $rowuser1) {
					if($rowuser1['name']!=''){
						$html.=$rowuser1['name'].',';
					}
				}
			}
		}
		$flowuser1=substr($html, 0, -1);
	}else{
		$flowuser1=$_flowuser;
	}
	return $flowuser1;
}
function get_work_numselect($tplid='',$typeid='',$name,$value){
	$html.='<select name="'.$name.'" id="'.$name.'">';
	$html.='<option value="" selected="selected">选择表单</option>';
	global $db;
	$query = $db->query("SELECT inputname,fromname FROM ".DB_TABLEPRE."workclass_from where tplid='".$tplid."' and typeid='".$typeid."' and inputtype1='1' and inputtype='0' ORDER BY inputnumber Asc");
	while ($from = $db->fetch_array($query)) {
		$selected='';
		if($value==$from['inputname']){
			$selected='selected="selected"';
		}
		$html.='<option value="'.$from['inputname'].'" '.$selected.'>'.$from['fromname'].'</option>';	
	}
	$html.='</select> ';
	return $html;
}
function get_work_numview($tplid='',$typeid='',$fromid){
	global $db;
	$query = $db->query("SELECT fromname,w,h,inputname,numtype FROM ".DB_TABLEPRE."workclass_from_view where tplid='".$tplid."' and typeid='".$typeid."' and fromid='".$fromid."' ORDER BY inputnumber Asc");
	$html.='<tr><td class="text_no"><div style="width:60px;"><a href="javascript:;" style="font-size:12px;" onClick="DelTable'.$fromid.'(this)">删除</a><input type="hidden" name="t6'.$fromid.'[]" value="1" /></td>';
	while ($from = $db->fetch_array($query)) {
		if($from["w"]=='' || $from["w"]=='0') $from["w"]='120';
		if($from["h"]=='' || $from["h"]=='0') $from["h"]='20';
		$numtype='';
		if($from["numtype"]=='1'){
			$numtype='oninput="numinput'.$from["inputname"].'(event)" onporpertychange="numinput'.$from["inputname"].'(event)"';
		}
		$html.='<td class="text_value" style="padding-top: 6px;"><input type="text" class="span3" '.$numtype.'  name="'.$from["inputname"].'[]" id="'.$from["inputname"].'" style="width:'.$from["w"].'px;height:'.$from["h"].'px;line-height:30px;font-size:14px;" value="" /></td>';
	}
	$html.=' </tr>';
	return $html;
}
?>