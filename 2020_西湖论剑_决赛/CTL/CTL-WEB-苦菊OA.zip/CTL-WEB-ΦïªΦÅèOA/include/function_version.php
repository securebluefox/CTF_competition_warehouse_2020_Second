<?php
/*
	[Office 515158] (C) 2009-2012 天生创想 Inc.
	$Id: function_version.php 1209087 2012-01-08 08:58:28Z baiwei.jiang $
*/
!defined('IN_TOA') && exit('Access Denied!');

define('TOA_VERSION','v2010.10.28');
define('TOA_RELEASE','20101028');
?>