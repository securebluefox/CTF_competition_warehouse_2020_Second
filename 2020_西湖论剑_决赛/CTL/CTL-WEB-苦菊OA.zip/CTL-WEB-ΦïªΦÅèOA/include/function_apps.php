<?php
/*
	[Office 515158] (C) 2009-2015 天生创想 Inc.
	$Id: function_apps.php 1209087 2015-01-08
*/
!defined('IN_TOA') && exit('Access Denied!');
//单选
function apps_radio($name='',$radiovalue='',$value=''){
		$inputvaluenum=explode('|',$radiovalue); 
		$html.='<!--{radio'.$name.'start}-->';
		for($i=0;$i<sizeof($inputvaluenum);$i++){
			$html.= '<input name="'.$name.'" type="radio" value="'.$inputvaluenum[$i].'" ';
			if($value==''){
				if($i==0){
					$html.= 'checked="checked"';
				}
			}else{
				if(trim($value)==trim($inputvaluenum[$i])){
					$html.= 'checked="checked"';
				}
			}
			$html.= '/>'.$inputvaluenum[$i].' ';
		}
		$html.='<!--{radio'.$name.'end}-->';
	return $html;
}
//多选
function apps_checkbox($name='',$radiovalue='',$value=''){
		$inputvaluenum=explode('|',$radiovalue); 
		$html.='<!--{checkbox'.$name.'start}-->';
		for($i=0;$i<sizeof($inputvaluenum);$i++){
			$html.= '<input name="'.$name.'[]" type="checkbox" value="'.$inputvaluenum[$i].'" ';
			if($value==''){
				if($i=='0'){
					$html.= 'checked="checked"';
				}
			}else{
				if(sizeof(explode($inputvaluenum[$i],$value))>1){
					$html.= 'checked="checked"';
				}
			}
			$html.= '/>'.$inputvaluenum[$i].' ';
		}
		$html.='<!--{checkbox'.$name.'end}-->';
	return $html;
}
//日期
function apps_date($name='',$w,$h,$value){
	if($w=='' || $w=='0') $w='180';
	if($h=='' || $h=='0') $h='20';
	return '<input class="BigInput" style="width:'.$w.'px;height:'.$h.'px;line-height:'.$h.'px;font-size:14px;margin-top:6px;" type="text" value="'.$value.'" name="'.$name.'" onClick="WdatePicker();" />';
}

//文本域
function apps_input($name='',$w,$h,$value=''){
	if($w=='' || $w=='0') $w='260';
	if($h=='' || $h=='0') $h='20';
	return '<input type="text" class="span3" name="'.$name.'" style="width:'.$w.'px;height:'.$h.'px;line-height:'.$h.'px;font-size:14px;margin-top:6px;" value="'.$value.'" />';
}
//下拉框
function apps_select($name='',$radiovalue='',$value='',$w,$h){
	if($w=='' || $w=='0') $w='260';
	if($h=='' || $h=='0') $h='30';
	$inputvaluenum=explode('|',$radiovalue); 
	$html.='<!--{option'.$name.'start}-->';
	$html.='<select class="span3" name="'.$name.'" id="'.$name.'" style="width:'.$w.'px;height:'.$h.'px;line-height:'.$h.'px;font-size:14px;margin-top:6px;">';
	$html.='<option value="" selected="selected">选择内容</option>';
	for($i=0;$i<sizeof($inputvaluenum);$i++){
		if($inputvaluenum[$i]==$value){
			$selected='  selected="selected"';
		}else{
			$selected='';
		}
		$html.='<option value="'.$inputvaluenum[$i].'" '.$selected.'>'.$inputvaluenum[$i].'</option>';	
	}
	$html.='</select> ';
	$html.='<!--{option'.$name.'end}-->';
	return $html;
}
//文本框
function apps_textarea($name='',$w,$h,$value=''){
	if($w=='' || $w=='0') $w='600';
	if($h=='' || $h=='0') $h='200';
	$_CONFIG=new config();
	if($_CONFIG->config_data('configwork')=='1'){
		$html.= '<textarea name="'.$name.'" id="'.$name.'" style="width:'.$w.'px;height:'.$h.'px;margin-top:6px;margin-bottom:6px;" class="ckeditor">'.$value.'</textarea>';
	}else{
		$html.= '<textarea name="'.$name.'" style="width:'.$w.'px;height:'.$h.'px;margin-top:6px;margin-bottom:6px;" class="span3">'.$value.'</textarea>';
	}
	return $html;
}
//模板植入单框数据读取
function apps_db($tplid=0,$inputname='',$w=0,$h=0,$value=''){
	global $db;
	$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE."app_from where  tplid='".$tplid."' and inputname='".$inputname."'  ORDER BY fromid Asc");
	if($tpl['inputtype']=='0'){
		if($tpl["inputtype1"]=='1'){
			return apps_input($tpl["inputname"],$w,$h,$value);
		}elseif($tpl["inputtype1"]=='2'){
			return apps_textarea($tpl["inputname"],$w,$h,$value);
		}elseif($tpl["inputtype1"]=='3'){
			return apps_radio($tpl["inputname"],$tpl["inputvaluenum"],$value);
		}elseif($tpl["inputtype1"]=='4'){
			return apps_checkbox($tpl["inputname"],$tpl["inputvaluenum"],$value);		
		}elseif($tpl["inputtype1"]=='5'){
			return apps_select($tpl["inputname"],$tpl["inputvaluenum"],$value);	
		}
	}elseif($tpl["inputtype"]=='3'){
		return apps_date($tpl["inputname"],$w,$h,$value);
	}elseif($tpl["inputtype"]=='4'){
		$dep= "<input type='text' name='".$tpl["inputname"]."' style='width:".$w."px;height:".$h."px;background-color:#F5F5F5;color:#006600;margin-top:6px;' value='".$value."' readonly />";
        $dep.= '<a href="#" onClick="window.open ';
		$dep.="('admin.php?ac=dep_radio&fileurl=public&inputname=".$tpl["inputname"]."', '".$tpl["inputname"]."', 'height=500, width=500, top=50, left=100, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no')";
		$dep.='">+选择部门</a>';
		return $dep;
	}elseif($tpl["inputtype"]=='5'){
	   $user= "<input type='text' name='".$tpl["inputname"]."' style='width:".$w."px;height:".$h."px;background-color:#F5F5F5;color:#006600;margin-top:6px;' value='".$value."' readonly />";
       $user.='<a href="javascript:;" onClick="window.open (';
	   $user.="'admin.php?ac=user_radio&fileurl=public&inputname=".$tpl["inputname"]."', '".$tpl["inputname"]."', 'height=500, width=500, top=50, left=100, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no'";
	   $user.=')">+选择人员</a>';
	   return $user;
	}elseif($tpl["inputtype"]=='7'){
		if($tpl["magnificent"]=='read'){
			return '<!--{阅者签名'.$tpl["inputname"].'}-->';
		}else{	
			return '<!--{流程控件'.$tpl["magnificent"].$tpl["inputname"].'}-->';
		}
	}
}
//获取并过滤表单数据
function apps_adddb($tplid,$tpltype,$appid,$tpladdr,$flowid){
	global $db;
	global $_USER;
	$query = $db->query("SELECT inputname,inputtype,inputtype1,inputvaluenum FROM ".DB_TABLEPRE."app_from where tplid='".$tplid."' and inputtype!='7' ORDER BY fromid Asc");
	while ($row = $db->fetch_array($query)) {
		$values=public_value($row['inputname'],'apps_'.$tplid,'appid='.$appid);
		if($flowid!=''){
			$formkey=public_value('formkey','app_flow','fid='.$flowid);
		}
		if($values!=''){
			if($row['inputtype1']==3){
			    $values=apps_radio($row["inputname"],$row["inputvaluenum"],$values);
				$addr=get_subcontent($tpladdr,'<!--{radio'.$row['inputname'].'start}-->','<!--{radio'.$row['inputname'].'end}-->');
				$tpladdr=str_replace($addr,$values,$tpladdr);
			}elseif($row['inputtype1']==4){
				$values=apps_checkbox($row["inputname"],$row["inputvaluenum"],$values);
				$addr=get_subcontent($tpladdr,'<!--{checkbox'.$row['inputname'].'start}-->','<!--{checkbox'.$row['inputname'].'end}-->');
				$tpladdr=str_replace($addr,$values,$tpladdr);
			}elseif($row['inputtype1']==5){
				$values=apps_select($row["inputname"],$row["inputvaluenum"],$values);
				$addr=get_subcontent($tpladdr,'<!--{option'.$row['inputname'].'start}-->','<!--{option'.$row['inputname'].'end}-->');
				$tpladdr=str_replace($addr,$values,$tpladdr);
			}else{
				$tpladdr=str_replace("{".$row['inputname']."}",$values,$tpladdr);
			}
		}else{
			if($row['inputtype']==3){
				$tpladdr=str_replace("{".trim($row['inputname'])."}",get_date('Y-m-d',PHP_TIME),$tpladdr);
			}elseif($row['inputtype']==4){
				$tpladdr=str_replace("{".$row['inputname']."}",get_realdepaname(public_value('departmentid','user','id='.$_USER->id)),$tpladdr);
			}elseif($row['inputtype']==5){
				$tpladdr=str_replace("{".$row['inputname']."}",get_realname($_USER->id),$tpladdr);
			}else{
				$tpladdr=str_replace("{".$row['inputname']."}",'',$tpladdr);
			}
		}
		if(sizeof(explode('"'.$row['inputname'].'"',$formkey))>1){
			
		}else{
			$tpladdr=str_replace('name="'.$row['inputname'],'disabled="disabled" name="'.$row['inputname'],$tpladdr);
		}
		
	}
	return $tpladdr;
}
//更新主表信息
function apps_update(){
	global $db;
	global $_USER;
	$apps = array();
	$apps['number']=check_str(getGP('number','P'));
	$apps['title']=check_str(getGP('title','P'));
	update_db('apps',$apps, array('id' =>getGP('appid','P','int'),'uid'=>$_USER->id));
}
//更新表单信息
function appsform_update(){
	global $db;
	global $_USER;
	$apps = array();
	$appid=getGP('appid','P','int');
	$tplid=getGP('tplid','G','int');
	$tpltype=getGP('tpltype','G','int');
	$flowid=getGP('flowid','P','int');
	$formkey=public_value('formkey','app_flow','fid='.$flowid);
	if(sizeof(explode('toa',$formkey))>1){
	$query = $db->query("SELECT * FROM ".DB_TABLEPRE."app_from where tplid='".$tplid."' and  inputtype!=7 ORDER BY fromid Asc");
	while ($row = $db->fetch_array($query)) {
		if(sizeof(explode('"'.$row['inputname'].'"',$formkey))>1){
			if($row['inputtype1']=='4'){
				$inputvalues='';
				$inputvalue=getGP(''.$row["inputname"].'','P','array');
				foreach ($inputvalue as $arrsave) {
					$inputvalues.=$arrsave.'|';
				}
				$apps[$row["inputname"]]=substr($inputvalues, 0, -1);
			}else{
				$apps[$row["inputname"]]=trim(getGP(''.$row["inputname"].'','P'));
			}
		}
	}
	update_db('apps_'.$tplid,$apps, array('appid' =>$appid,'tplid'=>$tplid));
	}
	
}
//获取数据
function apps_viewdb($tplid,$tpltype,$appid,$tpladdr){
	global $db;
	global $_USER;
	$query = $db->query("SELECT inputname,inputtype,inputtype1,inputvaluenum,magnificent FROM ".DB_TABLEPRE."app_from where tplid='".$tplid."' ORDER BY fromid Asc");
	while ($row = $db->fetch_array($query)) {
		$values=public_value($row['inputname'],'apps_'.$tplid,'appid='.$appid);
		if($values!=''){
			if($row['inputtype1']==4){
				$values=str_replace("|",',',$values);
				$tpladdr=str_replace("<!--{".$row['inputname']."}-->",$values,$tpladdr);
			}else{
				$tpladdr=str_replace("<!--{".$row['inputname']."}-->",$values,$tpladdr);
			}
		}else{
			if($row['inputtype']=='7'){
				$addr=get_subcontent($tpladdr,"<!--".$row['inputname']."s-->","<!--".$row['inputname']."e-->");
				$addr=str_replace("<!--{",'',str_replace("}-->",'',$addr));
				if($addr=='read'){
					$tpladdr=str_replace("&nbsp;",'',$tpladdr);
					$tpladdr=str_replace("<!--".$row['inputname']."s--><!--{".$row['magnificent']."}--><!--".$row['inputname']."e-->",apps_read($appid),$tpladdr);
				}else{
					$tpladdr=str_replace("&nbsp;",'',$tpladdr);
					$tpladdr=str_replace("<!--".$row['inputname']."s--><!--{".$row['magnificent']."}--><!--".$row['inputname']."e-->",apps_flows($addr,$appid),$tpladdr);
				}
			}
		}
	}
	return $tpladdr;
}
//显示流程
function apps_read($appid){
	global $db;
	global $_USER;
	$html='';
	$sqls = "SELECT readuid FROM ".DB_TABLEPRE."app_read where appid='".$appid."' and readdate!='' order by rid asc";
	$result = $db->fetch_all($sqls);
	foreach ($result as $rows) {
			$html.=get_realname($rows['readuid']).' , ';
	}
	return substr($html, 0, -3);		
}
function apps_flows($flowid,$appid){
	global $db;
	global $_USER;
	$html='';
	$sql = "SELECT flowkey2 FROM ".DB_TABLEPRE."app_flow  WHERE fid = '".$flowid."'";
	$flow = $db->fetch_one_array($sql);
	if($flow['flowkey2']==2){
		$sqls = "SELECT * FROM ".DB_TABLEPRE."app_personnel where appid='".$appid."' and flowid='".$flowid."' and pertype!=0  order by perid asc";
		$result = $db->fetch_all($sqls);
		foreach ($result as $pers) {
			$html.='<table width="96%" border="0" cellspacing="0" cellpadding="0">';
			$html.='<tr>';
			$html.='<td height="30" colspan="2" align="left" valign="top" style="font-size:14px;">';
			$html.=$pers['lnstructions'].'</td>';
			$html.='</tr><tr>';
			$html.='<td width="29%" height="40" align="left" valign="middle" style="font-size:14px;">办理人：'.$pers['name'].'</td><td width="71%" align="left" valign="middle" style="font-size:14px;">办理日期：'.$pers['approvaldate'].'</td>';
			$html.='</tr></table>';
	    }
	}else{
		$sqls = "SELECT * FROM ".DB_TABLEPRE."app_personnel  WHERE appid='".$appid."' and flowid='".$flowid."' and pertype!=0";
		$perid = $db->fetch_one_array($sqls);
		$sqls = "SELECT * FROM ".DB_TABLEPRE."app_personnel_log where appid='".$appid."' and perid='".$perid['perid']."' and pertype!=0  order by perid asc";
		$result = $db->fetch_all($sqls);
		foreach ($result as $pers) {
			$html.='<table width="96%" border="0" cellspacing="0" cellpadding="0">';
			$html.='<tr>';
			$html.='<td height="30" colspan="2" align="left" valign="top" style="font-size:14px;">';
			$html.=$pers['lnstructions'].'</td>';
			$html.='</tr><tr>';
			$html.='<td width="29%" height="40" align="left" valign="middle" style="font-size:14px;">办理人：'.$pers['name'].'</td><td width="71%" align="left" valign="middle" style="font-size:14px;">办理日期：'.$pers['approvaldate'].'</td>';
			$html.='</tr></table>';
	    }
	}
	return $html;			
}
function apps_pertype($type){
	switch ($type)
	{
		case 0:
		  echo "未审批";
		  break;
		case 1:
		  echo "通过";
		  break;
		case 2:
		  echo "拒绝";
		  break;
		case 3:
		  echo "退回";
		  break;
		case 4:
		  echo "等待审批";
		  break;
		case 5:
		  echo "结束";
		  break;
		default:
		  echo "错误类型";
	}
	return ;
}
function apps_pertype_log($type){
	switch ($type)
	{
		case 0:
		  echo "未审批";
		  break;
		case 1:
		  echo "通过";
		  break;
		case 2:
		  echo "拒绝";
		  break;
		case 3:
		  echo "退回";
		  break;
		default:
		  echo "错误类型";
	}
	return ;
}
?>