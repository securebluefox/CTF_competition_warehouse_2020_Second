<?php
/*
	[Office 515158] (C) 2009-2014 天生创想 Inc.
	$Id: function_email.php 1209087 2014-09-08 baiwei.jiang $
*/
!defined('IN_TOA') && exit('Access Denied!');


?>