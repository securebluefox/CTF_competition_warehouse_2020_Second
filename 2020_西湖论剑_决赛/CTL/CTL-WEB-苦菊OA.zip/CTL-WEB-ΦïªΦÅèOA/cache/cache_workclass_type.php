<?php
//该文件是系统自动生成的缓存文件，请勿修改
//创建时间：2018-05-16 13:22:34

if (!defined('IN_TOA')) {exit('Access Denied!');}

$_CACHE['workclass_type'] = array (
  11 => 
  array (
    'tid' => '11',
    'typename' => '财务类',
    'uid' => '1',
    'typenum' => '1',
  ),
  12 => 
  array (
    'tid' => '12',
    'typename' => '采购类',
    'uid' => '1',
    'typenum' => '2',
  ),
  19 => 
  array (
    'tid' => '19',
    'typename' => '行政类',
    'uid' => '1',
    'typenum' => '3',
  ),
  17 => 
  array (
    'tid' => '17',
    'typename' => '销售类',
    'uid' => '1',
    'typenum' => '4',
  ),
  14 => 
  array (
    'tid' => '14',
    'typename' => '人事类',
    'uid' => '1',
    'typenum' => '5',
  ),
);

?>