<?php
//该文件是系统自动生成的缓存文件，请勿修改
//创建时间：2019-05-15 13:20:29

if (!defined('IN_TOA')) {exit('Access Denied!');}

$_CACHE['config'] = array (
  'name' => 
  array (
    'id' => '1',
    'value' => '苦菊OA协同办公软件',
    'name' => 'name',
  ),
  'web' => 
  array (
    'id' => '2',
    'value' => 'http://www.831209.net/',
    'name' => 'web',
  ),
  'pagenum' => 
  array (
    'id' => '3',
    'value' => '20',
    'name' => 'pagenum',
  ),
  'opendate' => 
  array (
    'id' => '4',
    'value' => '0',
    'name' => 'opendate',
  ),
  'enddate' => 
  array (
    'id' => '5',
    'value' => '24',
    'name' => 'enddate',
  ),
  'sworknum' => 
  array (
    'id' => '6',
    'value' => '1',
    'name' => 'sworknum',
  ),
  'swork' => 
  array (
    'id' => '7',
    'value' => '9:00',
    'name' => 'swork',
  ),
  'ework' => 
  array (
    'id' => '8',
    'value' => '18:00',
    'name' => 'ework',
  ),
  'swork1' => 
  array (
    'id' => '9',
    'value' => '14:30',
    'name' => 'swork1',
  ),
  'ework1' => 
  array (
    'id' => '10',
    'value' => '18:30',
    'name' => 'ework1',
  ),
  'configwork' => 
  array (
    'id' => '11',
    'value' => '1',
    'name' => 'configwork',
  ),
  'configoffice' => 
  array (
    'id' => '12',
    'value' => '0',
    'name' => 'configoffice',
  ),
  'configinfo' => 
  array (
    'id' => '13',
    'value' => '1',
    'name' => 'configinfo',
  ),
  'configsms' => 
  array (
    'id' => '14',
    'value' => '0',
    'name' => 'configsms',
  ),
  'configflag' => 
  array (
    'id' => '15',
    'value' => '1',
    'name' => 'configflag',
  ),
  'mobile1' => 
  array (
    'id' => '16',
    'value' => '0',
    'name' => 'mobile1',
  ),
  'configinfoview' => 
  array (
    'id' => '18',
    'value' => '0',
    'name' => 'configinfoview',
  ),
  'oaurl' => 
  array (
    'id' => '19',
    'value' => 'm.515158.com|down.515158.com|api.515158.com',
    'name' => 'oaurl',
  ),
  'usernum' => 
  array (
    'id' => '20',
    'value' => '0',
    'name' => 'usernum',
  ),
  'com_editionnum' => 
  array (
    'id' => '21',
    'value' => 'V2014.v201402',
    'name' => 'com_editionnum',
  ),
  'crmdate' => 
  array (
    'id' => '22',
    'value' => '2019-05-22 11:42:48',
    'name' => 'crmdate',
  ),
  'home' => 
  array (
    'id' => '23',
    'value' => '0',
    'name' => 'home',
  ),
  'uploadtype' => 
  array (
    'id' => '24',
    'value' => 'doc|docx|xlsx|jpg|gif|rar|txt|zip|pdf|xls|ppt|esp|cad|3ds|img|psd|pdf|ai|log|mdb|pot|csv|png',
    'name' => 'uploadtype',
  ),
  'closereason' => 
  array (
    'id' => '25',
    'value' => '系统维护中.....',
    'name' => 'closereason',
  ),
);

?>