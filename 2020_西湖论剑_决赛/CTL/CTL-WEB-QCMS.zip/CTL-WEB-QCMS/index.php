<?php
/*
 * Name   : Collection
 * Date	  : 20120107 
 * Author : Qesy 
 * QQ	  : 762264
 * Mail   : 762264@qq.com
 *
 *(̅_̅_̅(̲̅(̅_̅_̅_̅_̅_̅_̅_̅()ڪے 
 *
*/ 
error_reporting(E_ALL ^ E_NOTICE);
define('EXT','.php');
define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME));
define('SITEPATH', str_replace(SELF, '', $_SERVER["PHP_SELF"]));
define('BASEPATH', 'System/');
define('LIB', 'Lib/');
require_once LIB.'X'.EXT;
?>
