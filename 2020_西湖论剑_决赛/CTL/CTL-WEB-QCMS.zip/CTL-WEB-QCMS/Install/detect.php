<?php
!empty($_GET['act']) || die('参数错误');
$configPath = '../Lib/Config/';
switch($_GET['act']){
  case 1:
    $result = is_writable($configPath);
    break;
  case 2:
    $result = file_exists($configPath.'Config.php');
    break;
  default:
  echo '参数错误';break;
}
echo $result ? 1 : 0;