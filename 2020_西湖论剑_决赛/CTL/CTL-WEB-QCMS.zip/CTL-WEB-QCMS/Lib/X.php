<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Name   : Collection
 * Date	  : 20120107 
 * Author : Qesy 
 * QQ	  : 762264
 * Mail   : 762264@qq.com
 *
 *(̅_̅_̅(̲̅(̅_̅_̅_̅_̅_̅_̅_̅()ڪے 
 *
*/ 
date_default_timezone_set('Asia/Shanghai');
ini_set('display_errors', '1');
//var_dump(ini_get_all());exit;
define('BOOT_PATH', SITEPATH.'Static/bootstrap/');
define('IMG_PATH', SITEPATH.'Static/images/');
define('JS_PATH', SITEPATH.'Static/scripts/');
define('CSS_PATH', SITEPATH.'Static/styles/');
define('CACHE_PATH', 'Static/cache/');
define('VERI', '123465');
define('SITE_KEY', 'QCMS');
require LIB.'Config/Common'.EXT;
require LIB.'Config/Base'.EXT;
require LIB.'Config/Controllers'.EXT;
require LIB.'Config/Db'.EXT;
require LIB.'Config/Db_pdo'.EXT;
if(!file_exists(LIB.'Config/Config'.EXT)){
	exec_script('window.location.href="'.SITEPATH.'Install/";');exit;
}
require LIB.'Config/Config'.EXT;
require LIB.'Config/Router'.EXT;
require LIB.'Helper/PHPMailer'.EXT;
$lifeTime = 24 * 3600;
session_set_cookie_params($lifeTime);
session_start();
Router::get_instance();
?>