
/* Copyright (c) 2006 Brandon Aaron (http://brandonaaron.net)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) 
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * $LastChangedDate: 2007-07-21 18:45:56 -0500 (Sat, 21 Jul 2007) $
 * $Rev: 2447 $
 *
 * Version 2.1.1
 */
(function(a){a.fn.bgiframe=(a.browser.msie&&/msie 6\.0/i.test(navigator.userAgent)?function(d){d=a.extend({top:"auto",left:"auto",width:"auto",height:"auto",opacity:true,src:"javascript:false;"},d);var c='<iframe class="bgiframe"frameborder="0"tabindex="-1"src="'+d.src+'"style="display:block;position:absolute;z-index:-1;'+(d.opacity!==false?"filter:Alpha(Opacity='0');":"")+"top:"+(d.top=="auto"?"expression(((parseInt(this.parentNode.currentStyle.borderTopWidth)||0)*-1)+'px')":b(d.top))+";left:"+(d.left=="auto"?"expression(((parseInt(this.parentNode.currentStyle.borderLeftWidth)||0)*-1)+'px')":b(d.left))+";width:"+(d.width=="auto"?"expression(this.parentNode.offsetWidth+'px')":b(d.width))+";height:"+(d.height=="auto"?"expression(this.parentNode.offsetHeight+'px')":b(d.height))+';"/>';return this.each(function(){if(a(this).children("iframe.bgiframe").length===0){this.insertBefore(document.createElement(c),this.firstChild)}})}:function(){return this});a.fn.bgIframe=a.fn.bgiframe;function b(c){return c&&c.constructor===Number?c+"px":c}})(jQuery);





//纯数字验证
var numOnly=function(str){
	var regNum=/^[0-9]{1,20}$/;
	if (regNum.test(str)){
		return true;
	} else {
		return false;
	}
}


$(function(){
	//申请礼物
	$('#gift-btn').click(function(){
		if (!document.getElementById('jquery_addmask')){
			$.documentMask();
		}
		var _top=($(window).height()-400)/2+document.documentElement.scrollTop+document.body.scrollTop;
		if (_top<0) _top=0;
		$('#overlay-gift').css('top', _top+'px').show().bgiframe();
		return false;
	});
	
	$('#overlay-gift-close').click(function(){
		$('#overlay-gift').hide();
		$('#jquery_addmask').remove();
		return false;
	});
	
	$('#overflow-gift-list input').attr('autocomplete', 'off');
	$('#overflow-gift-list div.name').click(function(){
		var container=$(this).parent();
		if (container.is('.selected')){
			container.find('input').attr('disabled', true).val('');
			container.removeClass('selected');
		} else {
			container.find('input').attr('disabled', false);
			container.addClass('selected');
		}
	});
	
	var strGift='';
	$('#overflow-gift-btn1').click(function(){
		if ($(this).is('.loading')) return false;
		var msg=$('#overflow-gift-callback1');
		msg.hide();
		var fields=$('#overflow-gift-list li.selected input');
		if (fields.length<1){
			msg.html('请选择要申请的礼品').show();
			return false;
		}
		var str=[];
		for (var i=0;i<fields.length;i++){
			var num=fields.eq(i).val();
			if (!num || num==''){
				msg.html('请填写礼品数量').show();
				return false;
			}
			if (!numOnly(num) || Number(num)<1){
				msg.html('礼品数量不正确').show();
				return false;
			}
			str[i]=fields.eq(i).attr('name')+'='+num;
		}
		str=str.join('&');
		strGift=str;
		var this1=$(this);
		this1.addClass('loading');
		var url=this1.attr('rel');
		$.ajax({
			type: 'post',
			url: url,
			data: str,
			cache: false,
			dataType: 'json',
			success: function(data){
				if (data.status=='failed'){
					msg.html(data.msg).show();
					this1.removeClass();
				}
				if (data.status=='success'){
					$('#overflow-gift-list li').removeClass().find('input').attr('disabled', true).val('');
					this1.removeClass();
					var _html='';
					for (var i=0;i<data.data.length;i++){
						_html+='<p>'+data.data[i].name+'，数量：'+data.data[i].num+'</p>';
					}
					$('#overlay-gift-step2-list').html(_html);
					$('#overlay-gift-step1').hide();
					$('#overlay-gift-step2').show();
				}
			}
		});
		return false;
	});
	
	$('#overlay-gift-back').click(function(){
		$('#overlay-gift-step2').hide();
		$('#overlay-gift-step1').show();
		return false;
	});
	
	$('#overflow-gift-btn2').click(function(){
		if ($(this).is('.loading')) return false;
		var msg=$('#overflow-gift-callback2');
		msg.hide();
		var fields=$('#overlay-gift-contact input');
		var str=[];
		for (var i=0;i<fields.length;i++){
			var _field=fields.eq(i);
			var value=_field.val();
			if (!value || $.trim(value)==''){
				msg.html('为了礼品顺利寄出，请输入完整的联系信息').show();
				return false;
			}
			if (_field.is('.postcode')){
				if (!numOnly(value) || value.length!=6){
					msg.html('邮编格式错误').show();
					return false;
				}
			}
			str[i]=_field.attr('name')+'='+value;
		}
		str=strGift+'&'+str.join('&');
		//alert(str);
		var this1=$(this);
		this1.addClass('loading');
		var url=this1.attr('rel');
		$.ajax({
			url: url,
			data: str,
			cache: false,
			dataType: 'json',
			success: function(data){
				if (data.status=='failed'){
					msg.html(data.msg).show();
					this1.removeClass();
				}
				if (data.status=='success'){
					$('#overlay-gift-step1, #overlay-gift-step2').hide();
					$('#overlay-gift-step3').show();
				}
			}
		});
	});
	
	$('#overflow-gift-btn3').click(function(){
		$('#overlay-gift-close').click();
		return false;
	});
	
	//表格斑马纹背景
	$('#activity-table tbody tr:odd').addClass('even')
	
	//复制活动邀请链接	
	$('#share-copy-button').click(function() {
		if($.browser.msie){
			var tVal = $('#share-copy-text').val();
			window.clipboardData.setData('text', tVal);
			alert('复制成功，你可以粘贴到MSN或QQ中发给好友。');			
		}
		else {
			alert('您使用的浏览器不支持此复制功能，请使用Ctrl+C或鼠标右键');	
		}
		
	});
	$('#share-copy-button').mousedown(function() {
		$(this).addClass('button-active');
	});
	$('#share-copy-button').mouseup(function() {
		$(this).removeClass('button-active');
	});
	$('#share-copy-text').click(function() {
		$(this).select();
	});
});

$(function(){
	//用户首次登录引导
	var filterImg=function(){
		if (!document.getElementById('activity-filter')) return false;
		$.documentMask();
		var graybg=$('#jquery_addmask')
		graybg.css('background', '#000');		
		$('#bd').css('position', 'static');
		$('#activity-filter').bgiframe();
		$('#activity-close-btn').click(function(){
			$('#jquery_addmask, #activity-filter').remove();
			$('#bd').css('position', 'relative');
			var url=$(this).attr('rel');
			$.ajax({
				url: url,
				cache: false
			});
			return false;
		});
		$('#activity-filter div.filter-left p, #jquery_addmask').click(function(){
			$('#activity-close-btn').click();
		});
	}
	filterImg();
	
});