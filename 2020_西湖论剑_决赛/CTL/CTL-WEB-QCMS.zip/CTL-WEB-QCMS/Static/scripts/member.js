$(function(){	
	//右下角的浮动框
	/*
	var floatBox=function(){
		if (!document.getElementById('float-box')) return false;
		var floatBox=$('#float-box');
		if(!window.XMLHttpRequest){
			$(window).scroll(function(){
				floatBox.css({'top': document.documentElement.scrollTop+document.body.scrollTop+$(window).height()-122+'px'});
			});
		} else {
			floatBox.css({
				'position': 'fixed'
			});
		}
	}
	floatBox();
	*/

	
	//关闭公告提醒
	$('#js-attention a.cancel').click(function(){
		var url=$(this).attr('rel');
		$('#js-attention').remove();
		$.ajax({
			url: url,
			cache: false
		});
	});
	
	//关闭完善资料提示
	$('#overlay-profile-closer, #overlay-profile-closer2').click(function(){
		$('#overlay-profile').remove();
		var url=$(this).attr('rel');
		$.ajax({
			url: url,
			cache: false
		});
		return false;
	});
});