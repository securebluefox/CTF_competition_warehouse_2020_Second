/*
 * Dialog
*/

//easy drag
(function($){var isMouseDown=false;var currentElement=null;var dropCallbacks={};var dragCallbacks={};var lastMouseX;var lastMouseY;var lastElemTop;var lastElemLeft;$.getMousePosition=function(e){var posx=0;var posy=0;if(!e)var e=window.event;if(e.pageX||e.pageY){posx=e.pageX;posy=e.pageY;}
else if(e.clientX||e.clientY){posx=e.clientX+document.body.scrollLeft+document.documentElement.scrollLeft;posy=e.clientY+document.body.scrollTop+document.documentElement.scrollTop;}
return{'x':posx,'y':posy};}
$.updatePosition=function(e){var pos=$.getMousePosition(e);var spanX=(pos.x-lastMouseX);var spanY=(pos.y-lastMouseY);$(currentElement).css("top",(lastElemTop+spanY));$(currentElement).css("left",(lastElemLeft+spanX));}
$(document).mousemove(function(e){if(isMouseDown){$.updatePosition(e);if(dragCallbacks[currentElement.id]!=undefined){dragCallbacks[currentElement.id](e);}
return false;}});$(document).mouseup(function(e){if(isMouseDown){isMouseDown=false;if(dropCallbacks[currentElement.id]!=undefined){dropCallbacks[currentElement.id](e);}
return false;}});$.fn.ondrag=function(callback){return this.each(function(){dragCallbacks[this.id]=callback;});}
$.fn.ondrop=function(callback){return this.each(function(){dropCallbacks[this.id]=callback;});}
$.fn.easydrag=function(allowBubbling,handle_ids){return this.each(function(){if(undefined==this.id)this.id='easydrag'+time();if(handle_ids){for(var i=0;i<handle_ids.length;i++){$("#"+handle_ids[i]).css("cursor","move");}}else{$(this).css("cursor","move");}
$(this).mousedown(function(e){if(handle_ids){var srcElement;e=e||window.event;srcElement=e.srcElement||e.target;var exists=false;if(srcElement.id!=undefined){for(var i=0;i<handle_ids.length;i++){if(handle_ids[i]==srcElement.id){exists=true;break;}}}
if(!exists)
return true;}
$(this).css("position","absolute");$(this).css("z-index","10000");isMouseDown=true;currentElement=this;var pos=$.getMousePosition(e);lastMouseX=pos.x;lastMouseY=pos.y;lastElemTop=this.offsetTop;lastElemLeft=this.offsetLeft;$.updatePosition(e);return allowBubbling?true:false;});});}})(jQuery);

/* Copyright (c) 2006 Brandon Aaron (http://brandonaaron.net)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) 
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * $LastChangedDate: 2007-07-21 18:45:56 -0500 (Sat, 21 Jul 2007) $
 * $Rev: 2447 $
 *
 * Version 2.1.1
 */
(function(a){a.fn.bgiframe=(a.browser.msie&&/msie 6\.0/i.test(navigator.userAgent)?function(d){d=a.extend({top:"auto",left:"auto",width:"auto",height:"auto",opacity:true,src:"javascript:false;"},d);var c='<iframe class="bgiframe"frameborder="0"tabindex="-1"src="'+d.src+'"style="display:block;position:absolute;z-index:-1;'+(d.opacity!==false?"filter:Alpha(Opacity='0');":"")+"top:"+(d.top=="auto"?"expression(((parseInt(this.parentNode.currentStyle.borderTopWidth)||0)*-1)+'px')":b(d.top))+";left:"+(d.left=="auto"?"expression(((parseInt(this.parentNode.currentStyle.borderLeftWidth)||0)*-1)+'px')":b(d.left))+";width:"+(d.width=="auto"?"expression(this.parentNode.offsetWidth+'px')":b(d.width))+";height:"+(d.height=="auto"?"expression(this.parentNode.offsetHeight+'px')":b(d.height))+';"/>';return this.each(function(){if(a(this).children("iframe.bgiframe").length===0){this.insertBefore(document.createElement(c),this.firstChild)}})}:function(){return this});a.fn.bgIframe=a.fn.bgiframe;function b(c){return c&&c.constructor===Number?c+"px":c}})(jQuery);


function dialogError(hook, mask, title, msg, dowhat, buttonText, width){
	$('#dialog-error-'+hook).remove();
	if (mask=='yes'&&!document.getElementById('jquery_addmask')){
		$.documentMask();
	}
	if (!width||width=='') var width=310;
	if (!mask||mask=='') var mask='';
	if (!buttonText||buttonText=='') var buttonText='确定';
	if (!dowhat||dowhat=='') var dowhat='removeSelf';
	if (!title||title=='') var title='操作失败';
	var _msg;
	if (!msg||msg==''){
		_msg='';
	} else {
		_msg='<div id="dialog-error-msg-'+hook+'" class="info">'+msg+'</div>';
	}
	width=Number(width);
	var _left=($(window).width()-width) / 2;
	if (_left<0) _left=0;
	var _top=($(window).height()-150)/2+document.documentElement.scrollTop+document.body.scrollTop;
	if (_top<0) _top=0;
	$('<div id="dialog-error-'+hook+'" class="dialog dialog-e" style="width:'+(width-8)+'px;left:'+_left+'px;top:'+_top+'px;"><div id="dialog-error-hd-'+hook+'" class="hd"><a id="dialog-error-cancel-'+hook+'" class="cancel" href="javascript:void(0);" title="取消">取消</a></div><div class="bd"><div class="content"><div class="msg-2"><div class="title">'+title+'</div>'+_msg+'</div></div><div class="footer"><a id="dialog-error-confirm-'+hook+'" class="btnwrap btn-mwm" href="javascript:void(0);" title="'+buttonText+'"><span class="inner"><span class="btn">'+buttonText+'</span></span></a></div></div></div>').appendTo(document.body);
	$('#dialog-error-'+hook).easydrag(false, ['dialog-error-hd-'+hook]).bgiframe();
	if (dowhat=='removeAll'){
		$('#dialog-error-confirm-'+hook).click(function(){
			$('#jquery_addmask, div.dialog, div.dialog1').remove();
		});
	}
	if (dowhat=='removeThis'){
		$('#dialog-error-confirm-'+hook).click(function(){
			$('#jquery_addmask, #dialog-error-'+hook).remove();
		});
	}
	if (dowhat=='removeSelf'){
		$('#dialog-error-confirm-'+hook).click(function(){
			//$('div.dialog1').css('z-index', 51);
			$('#dialog-error-'+hook).remove();
		});
	}
	$('#dialog-error-cancel-'+hook).click(function(){
		$('#dialog-error-confirm-'+hook).click();
	});
}

function dialogConfirm(hook, mask, msg, width, confirmTxt, cancelTxt, doCancel){
	$('#dialog-confirm-'+hook).remove();
	if (mask=='yes'&&!document.getElementById('jquery_addmask')){
		$.documentMask();
	}
	if (!width||width=='') var width=310;
	if (!mask||mask=='') var mask='';
	if (!confirmTxt||confirmTxt=='') var confirmTxt='确定';
	if (!cancelTxt||cancelTxt=='') var cancelTxt='取消';
	if (!doCancel||doCancel=='') var doCancel='removeSelf';
	width=Number(width);
	var _left=($(window).width()-width) / 2;
	if (_left<0) _left=0;
	var _top=($(window).height()-150)/2+document.documentElement.scrollTop+document.body.scrollTop;
	if (_top<0) _top=0;
	$('<div id="dialog-confirm-'+hook+'" class="dialog dialog-c" style="width:'+(width-8)+'px;left:'+_left+'px;top:'+_top+'px;"><div id="dialog-confirm-hd-'+hook+'" class="hd"><a id="dialog-confirm-shut-'+hook+'" class="cancel" href="javascript:void(0);" title="取消">取消</a></div><div class="bd"><div class="content"><div class="msg-s">'+msg+'</div></div><div class="footer"><a id="dialog-confirm-confirm-'+hook+'" class="btnwrap btn-mgm-round" href="javascript:void(0);" title="'+confirmTxt+'"><span class="inner"><span class="btn">'+confirmTxt+'</span></span></a> <a id="dialog-confirm-cancel-'+hook+'" class="btnwrap btn-mgm-round-1" href="javascript:void(0);" title="'+cancelTxt+'"><span class="inner"><span class="btn">'+cancelTxt+'</span></span></a></div></div></div>').appendTo(document.body);
	$('#dialog-confirm-'+hook).easydrag(false, ['dialog-confirm-hd-'+hook]).bgiframe();
	if (doCancel=='removeThis'){
		$('#dialog-confirm-shut-'+hook).click(function(){
			$('#jquery_addmask, #dialog-confirm-'+hook).remove();
			return false;
		});
	}
	if (doCancel=='removeSelf'){
		$('#dialog-confirm-shut-'+hook).click(function(){
			$('#dialog-confirm-'+hook).remove();
			return false;
		});
	}
	$('#dialog-confirm-cancel-'+hook).click(function(){
		$('#dialog-confirm-shut-'+hook).click();
		return false;
	});
}

function dialogSuccess(hook, mask, title, msg, dowhat, buttonText, width){
	$('#dialog-ok-'+hook).remove();
	if (mask=='yes'&&!document.getElementById('jquery_addmask')){
		$.documentMask();
	}
	if (!width||width=='') var width=310;
	if (!mask||mask=='') var mask='';
	if (!buttonText||buttonText=='') var buttonText='确定';
	if (!dowhat||dowhat=='') var dowhat='';
	if (!title||title=='') var title='操作成功';
	var _msg;
	if (!msg||msg==''){
		_msg='';
	} else {
		_msg='<div id="dialog-ok-msg-'+hook+'" class="info">'+msg+'</div>';
	}
	width=Number(width);
	var _left=($(window).width()-width) / 2;
	if (_left<0) _left=0;
	var _top=($(window).height()-150)/2+document.documentElement.scrollTop+document.body.scrollTop;
	if (_top<0) _top=0;
	$('<div id="dialog-ok-'+hook+'" class="dialog dialog-s" style="width:'+(width-8)+'px;left:'+_left+'px;top:'+_top+'px;"><div id="dialog-ok-hd-'+hook+'" class="hd"><a id="dialog-ok-cancel-'+hook+'" class="cancel" href="javascript:void(0);" title="取消">取消</a></div><div class="bd"><div class="content"><div class="msg-2"><div class="title">'+title+'</div>'+_msg+'</div></div><div class="footer"><a id="dialog-ok-confirm-'+hook+'" class="btnwrap btn-mwm" href="javascript:void(0);" title="'+buttonText+'"><span class="inner"><span class="btn">'+buttonText+'</span></span></a></div></div></div>').appendTo(document.body);
	$('#dialog-ok-'+hook).easydrag(false, ['dialog-ok-hd-'+hook]).bgiframe();
	if (dowhat=='removeAll'){
		$('#dialog-ok-confirm-'+hook).click(function(){
			$('#jquery_addmask, div.dialog, div.dialog1').remove();
			return false;
		});
	}
	if (dowhat=='removeSelf'){
		$('#dialog-ok-confirm-'+hook).click(function(){
			$('#dialog-ok-'+hook).remove();
			return false;
		});
	}
	$('#dialog-ok-cancel-'+hook).click(function(){
		$('#dialog-ok-confirm-'+hook).click();
	});
}

//弹出表单
var dialog1=function(hook, mask, title, height, width, btn2, btn1_text, btn2_text, scroll, body_height){
	$('#dialog1-'+hook).remove();
	if (mask=='yes'&&!document.getElementById('jquery_addmask')){
		$.documentMask();
	}
	if (!btn1_text||btn1_text=='') var btn1_text='确定';
	if (!btn2_text||btn2_text=='') var btn2_text='取消';
	
	if (!width||width=='') var width=410;
	if (!height||height=='') var height=400;
	width=Number(width);
	height=Number(height);
	var _left=($(window).width()-width) / 2;
	if (_left<0) _left=0;
	var _top=($(window).height()-height)/2+document.documentElement.scrollTop+document.body.scrollTop;
	if (_top<0) _top=0;
	
	if (btn2=='no'){
		var link_shut='';
		var buttons='<span class="btnwrap btn-mwm"><span class="inner"><button id="dialog1-'+hook+'-btn1" class="btn" type="button">'+btn1_text+'</button></span></span>';
	} else {
		var link_shut='<a id="dialog1-'+hook+'-shut" href="#" title="关闭">关闭</a>';
		var buttons='<span class="btnwrap btn-mwm"><span class="inner"><button id="dialog1-'+hook+'-btn1" class="btn" type="button">'+btn1_text+'</button></span></span> <span class="btnwrap btn-mwm"><span class="inner"><button id="dialog1-'+hook+'-btn2" class="btn" type="button">'+btn2_text+'</button></span></span>';
	}
	
	if(scroll=='allow'){
		var dialog_body='<div id="dialog1-'+hook+'-bd" class="clearfix bd" style="overflow:auto;height:'+body_height+'px">loading...</div>';
	} else {
		var dialog_body='<div id="dialog1-'+hook+'-bd" class="clearfix bd">loading...</div>';
	}
	
	$('<div id="dialog1-'+hook+'" class="dialog1" style="width:'+width+'px;height:'+height+'px;left:'+_left+'px;top:'+_top+'px;"><div class="hd"><div class="hd-inner"><div id="dialog1-'+hook+'-handle" class="handle"><h3 class="title">'+title+'</h3><p class="closer">'+link_shut+'</p></div></div></div>'+dialog_body+'<div class="ft"><div class="ft-inner"><div class="ft-inner"><div id="dialog1-'+hook+'-buttons" class="buttons">'+buttons+'</div></div></div></div></div>').appendTo(document.body);
	$('#dialog1-'+hook).easydrag(false, ['dialog1-'+hook+'-handle']).bgiframe();
	$('#dialog1-'+hook+'-shut').click(function(){
		$('#jquery_addmask, #dialog1-'+hook).remove();
		return false;
	});
	$('#dialog1-'+hook+'-buttons button').click(function(){
		if ($(this).val()=='确定'||$(this).text()=='确定'){
			$('#dialog1-'+hook+'-bd form').submit();
		}
		if ($(this).val()=='取消'||$(this).text()=='取消'){
			$('#dialog1-'+hook+'-shut').click();
		}
	});
}
