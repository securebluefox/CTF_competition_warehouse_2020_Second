jQuery.fn.extend({everyTime:function(a,b,c,d){return this.each(function(){jQuery.timer.add(this,a,b,c,d)})},oneTime:function(a,b,c){return this.each(function(){jQuery.timer.add(this,a,b,c,1)})},stopTime:function(a,b){return this.each(function(){jQuery.timer.remove(this,a,b)})}});jQuery.extend({timer:{global:[],guid:1,dataKey:"jQuery.timer",regex:/^([0-9]+(?:\.[0-9]*)?)\s*(.*s)?$/,powers:{ms:1,cs:10,ds:100,s:1000,das:10000,hs:100000,ks:1000000},timeParse:function(c){if(c==undefined||c==null){return null}var a=this.regex.exec(jQuery.trim(c.toString()));if(a[2]){var b=parseFloat(a[1]);var d=this.powers[a[2]]||1;return b*d}else{return c}},add:function(d,b,c,f,h){var a=0;if(jQuery.isFunction(c)){if(!h){h=f}f=c;c=b}b=jQuery.timer.timeParse(b);if(typeof b!="number"||isNaN(b)||b<0){return}if(typeof h!="number"||isNaN(h)||h<0){h=0}h=h||0;var g=jQuery.data(d,this.dataKey)||jQuery.data(d,this.dataKey,{});if(!g[c]){g[c]={}}f.timerID=f.timerID||this.guid++;var e=function(){if((++a>h&&h!==0)||f.call(d,a)===false){jQuery.timer.remove(d,c,f)}};e.timerID=f.timerID;if(!g[c][f.timerID]){g[c][f.timerID]=window.setInterval(e,b)}this.global.push(d)},remove:function(c,b,d){var e=jQuery.data(c,this.dataKey),a;if(e){if(!b){for(b in e){this.remove(c,b,d)}}else{if(e[b]){if(d){if(d.timerID){window.clearInterval(e[b][d.timerID]);delete e[b][d.timerID]}}else{for(var d in e[b]){window.clearInterval(e[b][d]);delete e[b][d]}}for(a in e[b]){break}if(!a){a=null;delete e[b]}}}for(a in e){break}if(!a){jQuery.removeData(c,this.dataKey)}}}}});jQuery(window).bind("unload",function(){jQuery.each(jQuery.timer.global,function(a,b){jQuery.timer.remove(b)})});

//easy drag
(function($){var isMouseDown=false;var currentElement=null;var dropCallbacks={};var dragCallbacks={};var lastMouseX;var lastMouseY;var lastElemTop;var lastElemLeft;$.getMousePosition=function(e){var posx=0;var posy=0;if(!e)var e=window.event;if(e.pageX||e.pageY){posx=e.pageX;posy=e.pageY;}
else if(e.clientX||e.clientY){posx=e.clientX+document.body.scrollLeft+document.documentElement.scrollLeft;posy=e.clientY+document.body.scrollTop+document.documentElement.scrollTop;}
return{'x':posx,'y':posy};}
$.updatePosition=function(e){var pos=$.getMousePosition(e);var spanX=(pos.x-lastMouseX);var spanY=(pos.y-lastMouseY);$(currentElement).css("top",(lastElemTop+spanY));$(currentElement).css("left",(lastElemLeft+spanX));}
$(document).mousemove(function(e){if(isMouseDown){$.updatePosition(e);if(dragCallbacks[currentElement.id]!=undefined){dragCallbacks[currentElement.id](e);}
return false;}});$(document).mouseup(function(e){if(isMouseDown){isMouseDown=false;if(dropCallbacks[currentElement.id]!=undefined){dropCallbacks[currentElement.id](e);}
return false;}});$.fn.ondrag=function(callback){return this.each(function(){dragCallbacks[this.id]=callback;});}
$.fn.ondrop=function(callback){return this.each(function(){dropCallbacks[this.id]=callback;});}
$.fn.easydrag=function(allowBubbling,handle_ids){return this.each(function(){if(undefined==this.id)this.id='easydrag'+time();if(handle_ids){for(var i=0;i<handle_ids.length;i++){$("#"+handle_ids[i]).css("cursor","move");}}else{$(this).css("cursor","move");}
$(this).mousedown(function(e){if(handle_ids){var srcElement;e=e||window.event;srcElement=e.srcElement||e.target;var exists=false;if(srcElement.id!=undefined){for(var i=0;i<handle_ids.length;i++){if(handle_ids[i]==srcElement.id){exists=true;break;}}}
if(!exists)
return true;}
$(this).css("position","absolute");$(this).css("z-index","10000");isMouseDown=true;currentElement=this;var pos=$.getMousePosition(e);lastMouseX=pos.x;lastMouseY=pos.y;lastElemTop=this.offsetTop;lastElemLeft=this.offsetLeft;$.updatePosition(e);return allowBubbling?true:false;});});}})(jQuery);

/* Copyright (c) 2006 Brandon Aaron (http://brandonaaron.net)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) 
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * $LastChangedDate: 2007-07-21 18:45:56 -0500 (Sat, 21 Jul 2007) $
 * $Rev: 2447 $
 *
 * Version 2.1.1
 */
(function(a){a.fn.bgiframe=(a.browser.msie&&/msie 6\.0/i.test(navigator.userAgent)?function(d){d=a.extend({top:"auto",left:"auto",width:"auto",height:"auto",opacity:true,src:"javascript:false;"},d);var c='<iframe class="bgiframe"frameborder="0"tabindex="-1"src="'+d.src+'"style="display:block;position:absolute;z-index:-1;'+(d.opacity!==false?"filter:Alpha(Opacity='0');":"")+"top:"+(d.top=="auto"?"expression(((parseInt(this.parentNode.currentStyle.borderTopWidth)||0)*-1)+'px')":b(d.top))+";left:"+(d.left=="auto"?"expression(((parseInt(this.parentNode.currentStyle.borderLeftWidth)||0)*-1)+'px')":b(d.left))+";width:"+(d.width=="auto"?"expression(this.parentNode.offsetWidth+'px')":b(d.width))+";height:"+(d.height=="auto"?"expression(this.parentNode.offsetHeight+'px')":b(d.height))+';"/>';return this.each(function(){if(a(this).children("iframe.bgiframe").length===0){this.insertBefore(document.createElement(c),this.firstChild)}})}:function(){return this});a.fn.bgIframe=a.fn.bgiframe;function b(c){return c&&c.constructor===Number?c+"px":c}})(jQuery);



/*!
 * jQuery Form Plugin
 * version: 2.49 (18-OCT-2010)
 * @requires jQuery v1.3.2 or later
 *
 * Examples and documentation at: http://malsup.com/jquery/form/
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 */
(function(b){b.fn.ajaxSubmit=function(s){if(!this.length){a("ajaxSubmit: skipping submit process - no element selected");return this}if(typeof s=="function"){s={success:s}}var d=b.trim(this.attr("action"));if(d){d=(d.match(/^([^#]+)/)||[])[1]}d=d||window.location.href||"";s=b.extend(true,{url:d,type:this.attr("method")||"GET",iframeSrc:/^https/i.test(window.location.href||"")?"javascript:false":"about:blank"},s);var t={};this.trigger("form-pre-serialize",[this,s,t]);if(t.veto){a("ajaxSubmit: submit vetoed via form-pre-serialize trigger");return this}if(s.beforeSerialize&&s.beforeSerialize(this,s)===false){a("ajaxSubmit: submit aborted via beforeSerialize callback");return this}var f,o,l=this.formToArray(s.semantic);if(s.data){s.extraData=s.data;for(f in s.data){if(s.data[f] instanceof Array){for(var h in s.data[f]){l.push({name:f,value:s.data[f][h]})}}else{o=s.data[f];o=b.isFunction(o)?o():o;l.push({name:f,value:o})}}}if(s.beforeSubmit&&s.beforeSubmit(l,this,s)===false){a("ajaxSubmit: submit aborted via beforeSubmit callback");return this}this.trigger("form-submit-validate",[l,this,s,t]);if(t.veto){a("ajaxSubmit: submit vetoed via form-submit-validate trigger");return this}var c=b.param(l);if(s.type.toUpperCase()=="GET"){s.url+=(s.url.indexOf("?")>=0?"&":"?")+c;s.data=null}else{s.data=c}var r=this,j=[];if(s.resetForm){j.push(function(){r.resetForm()})}if(s.clearForm){j.push(function(){r.clearForm()})}if(!s.dataType&&s.target){var p=s.success||function(){};j.push(function(n){var k=s.replaceTarget?"replaceWith":"html";b(s.target)[k](n).each(p,arguments)})}else{if(s.success){j.push(s.success)}}s.success=function(v,n,w){var u=s.context||s;for(var q=0,k=j.length;q<k;q++){j[q].apply(u,[v,n,w||r,r])}};var g=b("input:file",this).length>0;
var e="multipart/form-data";var i=(r.attr("enctype")==e||r.attr("encoding")==e);if(s.iframe!==false&&(g||s.iframe||i)){if(s.closeKeepAlive){b.get(s.closeKeepAlive,m)}else{m()}}else{b.ajax(s)}this.trigger("form-submit-notify",[this,s]);return this;function m(){var k=r[0];if(b(":input[name=submit],:input[id=submit]",k).length){alert('Error: Form elements must not have name or id of "submit".');return}var y=b.extend(true,{},b.ajaxSettings,s);y.context=y.context||y;var B="jqFormIO"+(new Date().getTime()),w="_"+B;window[w]=function(){var n=q.data("form-plugin-onload");if(n){n();window[w]=undefined;try{delete window[w]}catch(K){}}};var q=b('<iframe id="'+B+'" name="'+B+'" src="'+y.iframeSrc+'" onload="window[\'_\'+this.id]()" />');var x=q[0];q.css({position:"absolute",top:"-1000px",left:"-1000px"});var u={aborted:0,responseText:null,responseXML:null,status:0,statusText:"n/a",getAllResponseHeaders:function(){},getResponseHeader:function(){},setRequestHeader:function(){},abort:function(){this.aborted=1;q.attr("src",y.iframeSrc)}};var G=y.global;if(G&&!b.active++){b.event.trigger("ajaxStart")}if(G){b.event.trigger("ajaxSend",[u,y])}if(y.beforeSend&&y.beforeSend.call(y.context,u,y)===false){if(y.global){b.active--}return}if(u.aborted){return}var C=false;var F=0;var v=k.clk;if(v){var D=v.name;if(D&&!v.disabled){y.extraData=y.extraData||{};y.extraData[D]=v.value;if(v.type=="image"){y.extraData[D+".x"]=k.clk_x;y.extraData[D+".y"]=k.clk_y}}}function E(){var M=r.attr("target"),K=r.attr("action");k.setAttribute("target",B);if(k.getAttribute("method")!="POST"){k.setAttribute("method","POST")}if(k.getAttribute("action")!=y.url){k.setAttribute("action",y.url)}if(!y.skipEncodingOverride){r.attr({encoding:"multipart/form-data",enctype:"multipart/form-data"})}if(y.timeout){setTimeout(function(){F=true;A()},y.timeout)}var L=[];try{if(y.extraData){for(var N in y.extraData){L.push(b('<input type="hidden" name="'+N+'" value="'+y.extraData[N]+'" />').appendTo(k)[0])}}q.appendTo("body");q.data("form-plugin-onload",A);k.submit()}finally{k.setAttribute("action",K);
if(M){k.setAttribute("target",M)}else{r.removeAttr("target")}b(L).remove()}}if(y.forceSync){E()}else{setTimeout(E,10)}var I,J,H=50;function A(){if(C){return}q.removeData("form-plugin-onload");var L=true;try{if(F){throw"timeout"}J=x.contentWindow?x.contentWindow.document:x.contentDocument?x.contentDocument:x.document;var P=y.dataType=="xml"||J.XMLDocument||b.isXMLDoc(J);a("isXml="+P);if(!P&&window.opera&&(J.body==null||J.body.innerHTML=="")){if(--H){a("requeing onLoad callback, DOM not available");setTimeout(A,250);return}}C=true;u.responseText=J.documentElement?J.documentElement.innerHTML:null;u.responseXML=J.XMLDocument?J.XMLDocument:J;u.getResponseHeader=function(R){var Q={"content-type":y.dataType};return Q[R]};var O=/(json|script)/.test(y.dataType);if(O||y.textarea){var K=J.getElementsByTagName("textarea")[0];if(K){u.responseText=K.value}else{if(O){var N=J.getElementsByTagName("pre")[0];var n=J.getElementsByTagName("body")[0];if(N){u.responseText=N.innerHTML}else{if(n){u.responseText=n.innerHTML}}}}}else{if(y.dataType=="xml"&&!u.responseXML&&u.responseText!=null){u.responseXML=z(u.responseText)}}I=b.httpData(u,y.dataType)}catch(M){a("error caught:",M);L=false;u.error=M;b.handleError(y,u,"error",M)}if(L){y.success.call(y.context,I,"success",u);if(G){b.event.trigger("ajaxSuccess",[u,y])}}if(G){b.event.trigger("ajaxComplete",[u,y])}if(G&&!--b.active){b.event.trigger("ajaxStop")}if(y.complete){y.complete.call(y.context,u,L?"success":"error")}setTimeout(function(){q.removeData("form-plugin-onload");q.remove();u.responseXML=null},100)}function z(n,K){if(window.ActiveXObject){K=new ActiveXObject("Microsoft.XMLDOM");K.async="false";K.loadXML(n)}else{K=(new DOMParser()).parseFromString(n,"text/xml")}return(K&&K.documentElement&&K.documentElement.tagName!="parsererror")?K:null}}};b.fn.ajaxForm=function(c){if(this.length===0){var d={s:this.selector,c:this.context};if(!b.isReady&&d.s){a("DOM not ready, queuing ajaxForm");b(function(){b(d.s,d.c).ajaxForm(c)});return this}a("terminating; zero elements found by selector"+(b.isReady?"":" (DOM not ready)"));
return this}return this.ajaxFormUnbind().bind("submit.form-plugin",function(f){if(!f.isDefaultPrevented()){f.preventDefault();b(this).ajaxSubmit(c)}}).bind("click.form-plugin",function(j){var i=j.target;var g=b(i);if(!(g.is(":submit,input:image"))){var f=g.closest(":submit");if(f.length==0){return}i=f[0]}var h=this;h.clk=i;if(i.type=="image"){if(j.offsetX!=undefined){h.clk_x=j.offsetX;h.clk_y=j.offsetY}else{if(typeof b.fn.offset=="function"){var k=g.offset();h.clk_x=j.pageX-k.left;h.clk_y=j.pageY-k.top}else{h.clk_x=j.pageX-i.offsetLeft;h.clk_y=j.pageY-i.offsetTop}}}setTimeout(function(){h.clk=h.clk_x=h.clk_y=null},100)})};b.fn.ajaxFormUnbind=function(){return this.unbind("submit.form-plugin click.form-plugin")};b.fn.formToArray=function(q){var p=[];if(this.length===0){return p}var d=this[0];var g=q?d.getElementsByTagName("*"):d.elements;if(!g){return p}var k,h,f,r,e,m,c;for(k=0,m=g.length;k<m;k++){e=g[k];f=e.name;if(!f){continue}if(q&&d.clk&&e.type=="image"){if(!e.disabled&&d.clk==e){p.push({name:f,value:b(e).val()});p.push({name:f+".x",value:d.clk_x},{name:f+".y",value:d.clk_y})}continue}r=b.fieldValue(e,true);if(r&&r.constructor==Array){for(h=0,c=r.length;h<c;h++){p.push({name:f,value:r[h]})}}else{if(r!==null&&typeof r!="undefined"){p.push({name:f,value:r})}}}if(!q&&d.clk){var l=b(d.clk),o=l[0];f=o.name;if(f&&!o.disabled&&o.type=="image"){p.push({name:f,value:l.val()});p.push({name:f+".x",value:d.clk_x},{name:f+".y",value:d.clk_y})}}return p};b.fn.formSerialize=function(c){return b.param(this.formToArray(c))};b.fn.fieldSerialize=function(d){var c=[];this.each(function(){var h=this.name;if(!h){return}var f=b.fieldValue(this,d);if(f&&f.constructor==Array){for(var g=0,e=f.length;g<e;g++){c.push({name:h,value:f[g]})}}else{if(f!==null&&typeof f!="undefined"){c.push({name:this.name,value:f})}}});return b.param(c)};b.fn.fieldValue=function(h){for(var g=[],e=0,c=this.length;e<c;e++){var f=this[e];var d=b.fieldValue(f,h);if(d===null||typeof d=="undefined"||(d.constructor==Array&&!d.length)){continue}d.constructor==Array?b.merge(g,d):g.push(d)
}return g};b.fieldValue=function(c,j){var e=c.name,p=c.type,q=c.tagName.toLowerCase();if(j===undefined){j=true}if(j&&(!e||c.disabled||p=="reset"||p=="button"||(p=="checkbox"||p=="radio")&&!c.checked||(p=="submit"||p=="image")&&c.form&&c.form.clk!=c||q=="select"&&c.selectedIndex==-1)){return null}if(q=="select"){var k=c.selectedIndex;if(k<0){return null}var m=[],d=c.options;var g=(p=="select-one");var l=(g?k+1:d.length);for(var f=(g?k:0);f<l;f++){var h=d[f];if(h.selected){var o=h.value;if(!o){o=(h.attributes&&h.attributes.value&&!(h.attributes.value.specified))?h.text:h.value}if(g){return o}m.push(o)}}return m}return b(c).val()};b.fn.clearForm=function(){return this.each(function(){b("input,select,textarea",this).clearFields()})};b.fn.clearFields=b.fn.clearInputs=function(){return this.each(function(){var d=this.type,c=this.tagName.toLowerCase();if(d=="text"||d=="password"||c=="textarea"){this.value=""}else{if(d=="checkbox"||d=="radio"){this.checked=false}else{if(c=="select"){this.selectedIndex=-1}}}})};b.fn.resetForm=function(){return this.each(function(){if(typeof this.reset=="function"||(typeof this.reset=="object"&&!this.reset.nodeType)){this.reset()}})};b.fn.enable=function(c){if(c===undefined){c=true}return this.each(function(){this.disabled=!c})};b.fn.selected=function(c){if(c===undefined){c=true}return this.each(function(){var d=this.type;if(d=="checkbox"||d=="radio"){this.checked=c}else{if(this.tagName.toLowerCase()=="option"){var e=b(this).parent("select");if(c&&e[0]&&e[0].type=="select-one"){e.find("option").selected(false)}this.selected=c}}})};function a(){if(b.fn.ajaxSubmit.debug){var c="[jquery.form] "+Array.prototype.join.call(arguments,"");if(window.console&&window.console.log){window.console.log(c)}else{if(window.opera&&window.opera.postError){window.opera.postError(c)}}}}})(jQuery);



//灰色背景
(function($){
    $.extend({
        documentMask: function(options,opa){
            if(opa == 'undefined'){
            		var op = $.extend({
                    opacity: 0.1,
                    z: 50,
                    bgcolor: '#000'
                }, options);
            	}else{
            		var op = $.extend({
            			opacity: 0.7,
                        z: 50,
                        bgcolor: '#000'
                }, options);
            	}
            $('<div id="jquery_addmask" class="jquery_addmask">&nbsp;</div>').appendTo(document.body).css({
                position: 'absolute',
                top: '0px',
                left: '0px',
				background: 'url(/img/mask.png)',
                'z-index': op.z,
                width: document.documentElement.clientWidth,
                height: $(document).height(),
                'background-color': op.bgcolor,
                opacity: 0
            }).fadeIn('fast', function(){
                $(this).fadeTo('fast', op.opacity);
            }).click(function(){
            }).bgiframe();

            return this;
        }
    });
})(jQuery);

//获取滚动条的高度
function getPageScroll(){
var yScroll;
if (self.pageYOffset) {
yScroll = self.pageYOffset;
} else if (document.documentElement && document.documentElement.scrollTop){
yScroll = document.documentElement.scrollTop;
} else if (document.body) {
yScroll = document.body.scrollTop;
}
arrayPageScroll = new Array('',yScroll)
return arrayPageScroll;
}
//获取页面实际大小
function getPageSize(){
var xScroll,yScroll;
if (window.innerHeight && window.scrollMaxY){
xScroll = document.body.scrollWidth;
yScroll = window.innerHeight + window.scrollMaxY;
} else if (document.body.scrollHeight > document.body.offsetHeight){
sScroll = document.body.scrollWidth;
yScroll = document.body.scrollHeight;
} else {
xScroll = document.body.offsetWidth;
yScroll = document.body.offsetHeight;
}
var windowWidth,windowHeight;
//var pageHeight,pageWidth; 
if (self.innerHeight) {
windowWidth = self.innerWidth;
windowHeight = self.innerHeight;
} else if (document.documentElement && document.documentElement.clientHeight) {
windowWidth = document.documentElement.clientWidth;
windowHeight = document.documentElement.clientHeight;
} else if (document.body) {
windowWidth = document.body.clientWidth;
windowHeight = document.body.clientHeight;
}
var pageWidth,pageHeight
if(yScroll < windowHeight){
pageHeight = windowHeight;
} else {
pageHeight = yScroll;
}
if(xScroll < windowWidth) {
pageWidth = windowWidth;
} else {
pageWidth = xScroll;
}
arrayPageSize = new Array(pageWidth,pageHeight,windowWidth,windowHeight)
return arrayPageSize;
}

//提示信息对话框
//错误提示
var dialogError=function(msg, dowhat, buttonText){
		if (document.getElementById('dialogError')){
			alert(msg);
			return false;
		}
		if (!document.getElementById('jquery_addmask')){
			$.documentMask();
		}
		$('div.dialog').css('z-index', 49);
		var styleNoticeLeft=((document.documentElement.clientWidth)-410) / 2;
		if (styleNoticeLeft<0) styleNoticeLeft=0;
		var arrayPageSize = getPageSize();
		var arrayPageScroll = getPageScroll();
		if(!msg||msg==null) var msg='';
		if(!buttonText||buttonText==null) var buttonText='确定';
		$('<div class="dialog" style="left:'+styleNoticeLeft+'px;z-index:101" id="dialogError"><div class="dialog-head"><div class="head-inner"><div id="handle_dialogError" class="clearfix head-inner"><h3 class="dialog-title">提示信息</h3><p class="dialog-closer"><a id="dialogError_shut" href="#" title="关闭">关闭</a></p></div></div></div><div id="container_dialogError" class="clearfix dialog-body"><div class="operatetip operatetip-error"><p id="dialogErrorContent" class="info">'+msg+'</p></div></div><div class="dialog-foot"><div class="foot-inner"><div class="clearfix foot-inner"><div id="buttons_dialogError" class="dialog-button"><span class="buttonwrap"><span class="inner"><input id="confirm_dialogError" type="button" class="button" value="'+buttonText+'" /></span></span></div></div></div></div></div>').appendTo(document.body);
		var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 250) / 2 + 'px';
		$('#dialogError').css('top', css_top).easydrag(false, ['handle_dialogError']).bgiframe();
		if (dowhat=='removeAll'){
			$('#confirm_dialogError').click(function(){
				$('div.dialog').remove();
				$('#jquery_addmask').remove();
			});
		}
		if (dowhat=='removeThis'){
			$('#confirm_dialogError').click(function(){
				$('#dialogError').remove();
				$('#jquery_addmask').remove();
			});
		}
		if (dowhat=='removeSelf'){
			$('#confirm_dialogError').click(function(){
				$('div.dialog').css('z-index', 51);
				$('#dialogError').remove();
			});
		}
		$('#dialogError_shut').click(function(){
			$('#confirm_dialogError').click();
		});
}
//警告信息
var dialogWarning=function(msg){
		if (!document.getElementById('jquery_addmask')){
			$.documentMask();
		}
		var styleNoticeLeft=((document.documentElement.clientWidth)-410) / 2;
		if (styleNoticeLeft<0) styleNoticeLeft=0;
		var arrayPageSize = getPageSize();
		var arrayPageScroll = getPageScroll();
		if(!msg||msg==null) var msg='';
		$('<div class="dialog" style="left:'+styleNoticeLeft+'px;z-index:101" id="dialogWarning"><div class="dialog-head"><div class="head-inner"><div id="handle_dialogWarning" class="clearfix head-inner"><h3 class="dialog-title">提示信息</h3><p class="dialog-closer"><a id="dialogWarning_shut" href="#" title="关闭">关闭</a></p></div></div></div><div id="container_dialogWarning" class="clearfix dialog-body"><div class="operatetip operatetip-warning"><p id="dialogWarningContent" class="info">'+msg+'</p></div></div><div class="dialog-foot"><div class="foot-inner"><div class="clearfix foot-inner"><div id="buttons_dialogWarning" class="dialog-button"><span class="buttonwrap"><span class="inner"><input id="confirm_dialogWarning" type="button" class="button" value="确定" /></span></span> <span class="buttonwrap"><span class="inner"><input id="cancel_dialogWarning" type="reset" class="button" value="取消" /></span></span></div></div></div></div></div>').appendTo(document.body);
		var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 250) / 2 + 'px';
		$('#dialogWarning').css('top', css_top).easydrag(false, ['handle_dialogWarning']).bgiframe();
		$('#cancel_dialogWarning').click(function(){
			$('#jquery_addmask').remove();
			$('#dialogWarning').remove();
		});
		$('#dialogWarning_shut').click(function(){
			$('#cancel_dialogWarning').click();
		});
}
//成功提示
var dialogSuccess=function(msg, dowhat){
		if (document.getElementById('dialogSuccess')){
			alert(msg);
			return false;
		}
		if (!document.getElementById('jquery_addmask')){
			$.documentMask();
		}
		var styleNoticeLeft=((document.documentElement.clientWidth)-410) / 2;
		if (styleNoticeLeft<0) styleNoticeLeft=0;
		var arrayPageSize = getPageSize();
		var arrayPageScroll = getPageScroll();
		if(!msg||msg==null) var msg='';
		$('<div class="dialog" style="left:'+styleNoticeLeft+'px;z-index:101" id="dialogSuccess"><div class="dialog-head"><div class="head-inner"><div id="handle_dialogSuccess" class="clearfix head-inner"><h3 class="dialog-title">提示信息</h3><p class="dialog-closer"><a id="dialogSuccess_shut" href="#" title="关闭">关闭</a></p></div></div></div><div id="container_dialogSuccess" class="clearfix dialog-body"><div class="operatetip operatetip-success"><p id="dialogSuccessContent" class="info">'+msg+'</p></div></div><div class="dialog-foot"><div class="foot-inner"><div class="clearfix foot-inner"><div id="buttons_dialogSuccess" class="dialog-button"><span class="buttonwrap"><span class="inner"><input id="confirm_dialogSuccess" type="button" class="button" value="确定" /></span></span></div></div></div></div></div>').appendTo(document.body);
		var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 250) / 2 + 'px';
		$('#dialogSuccess').css('top', css_top).easydrag(false, ['handle_dialogSuccess']).bgiframe();
		if (dowhat=='removeAll'){
			$('#confirm_dialogSuccess').click(function(){
				$('div.dialog').remove();
				$('#jquery_addmask').remove();
			});
		}
		$('#dialogSuccess_shut').click(function(){
			$('#confirm_dialogSuccess').click();
		});
}
//弹出表单
var dialog1=function(title, height, width, cancel, confirm_text, cancel_text, scroll, body_height){
		if (!document.getElementById('jquery_addmask')){
			$.documentMask();
		}
		if (!width) var width=410;
		var styleNoticeLeft=((document.documentElement.clientWidth)-width) / 2;
		if (styleNoticeLeft<0) styleNoticeLeft=0;
		var arrayPageSize = getPageSize();
		var arrayPageScroll = getPageScroll();
		if (!confirm_text) var confirm_text='确定';
		if (!cancel_text) var cancel_text='取消';
		if (cancel=='no'){
			var link_shut='';
			var buttons='<span class="buttonwrap"><span class="inner"><input id="confirm_dialog1" type="button" class="button" value="'+confirm_text+'" /></span></span>';
		} else {
			var link_shut='<a id="dialog1_shut" href="#" title="关闭">关闭</a>';
			var buttons='<span class="buttonwrap"><span class="inner"><input id="confirm_dialog1" type="button" class="button" value="'+confirm_text+'" /></span></span> <span class="buttonwrap"><span class="inner"><input type="button" class="button" value="'+cancel_text+'" /></span></span>';
		}
		if(scroll=='allow'){
			var dialog_body='<div id="dialog1_container" class="clearfix dialog-body" style="overflow:auto;height:'+body_height+'px">loading...</div>';
		} else {
			var dialog_body='<div id="dialog1_container" class="clearfix dialog-body">loading...</div>';
		}
		$('<div class="dialog" style="left:'+styleNoticeLeft+'px;width:'+width+'px;" id="dialog1"><div class="dialog-head"><div class="head-inner"><div id="handle_dialog1" class="clearfix head-inner"><h3 class="dialog-title">'+title+'</h3><p class="dialog-closer">'+link_shut+'</p></div></div></div>'+dialog_body+'<div class="dialog-foot"><div class="foot-inner"><div class="clearfix foot-inner"><div id="dialog1_buttons" class="dialog-button">'+buttons+'</div></div></div></div></div>').appendTo(document.body);
		var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - height) / 2;
		if (css_top<0) css_top=0;
		css_top=css_top+'px';
		$('#dialog1').css('top', css_top).easydrag(false, ['handle_dialog1']).bgiframe();
		$('#dialog1_shut').click(function(){
			$('#jquery_addmask').remove();
			$('#dialog1').remove();
			$('.formError').remove();
			return false;
		});
		$('#dialog1_buttons input').click(function(){
			if ($(this).val()=='确定'){
				$('#dialog1_container form').submit();
			}
			if ($(this).val()=='取消'){
				$('#dialog1_shut').click();
			}
		});
}

//不允许输入中文
var engOnly=function(str){
	for(i=0;i<str.length;i++){
		var c = str.substr(i,1);
		var ts = escape(c);
		if(ts.substring(0,2) == "%u"){
			return false;
		} else {
			return true;
		}
	}
}
//电子邮件验证
var emailOnly=function(str){
	var regEmail=/[_a-zA-Z\d\-\.]+@[_a-zA-Z\d\-]+(\.[_a-zA-Z\d\-]+)+$/;
	if (regEmail.test(str)){
		return true;
	} else {
		return false;
	}
}
//纯数字验证
var numOnly=function(str){
	var regNum=/^[0-9]{1,20}$/;
	if (regNum.test(str)){
		return true;
	} else {
		return false;
	}
}

//电话号码验证
var idOnly=function(str){
	var regId=/(^\d{15}$)|(^\d{17}([0-9]|X)$)/;
	if (regId.test(str))
		return true;
	else
		return false;
}

//取两位小数
function changeTwoDecimal(x)
{
   var f_x = parseFloat(x);
   if (isNaN(f_x))
   {
      alert('function:changeTwoDecimal->parameter error');
      return false;
   }
   var f_x = Math.round(x*100)/100;
   return f_x;
}

function ckeckradio(){
	var el = document.getElementsByTagName('input');
	var len = el.length;     
	for(var i=0; i <len; i++){
		if(el[i].type=="radio" && el[i].checked){
			return true;
		}
	}
	return false;
}

$(function(){

	//隐藏的表单项禁用自动完成
	$('input:hidden').attr('autocomplete', 'off');
	
	//表单验证
	var focusNormal=function(){
		var row=$(this).parent().parent();
		var tips=row.find('span.tips');
		var msgHelp=tips.attr('title');
		if(msgHelp==''||msgHelp==null) return false;
		tips.hide();
		if (row.find('blockquote').length<1){
			row.append('<blockquote></blockquote>');
		}
		row.find('blockquote').removeClass().text(msgHelp);
	}
	var blurNormal=function(thisInput){
		var value=thisInput.val();
		var row=thisInput.parent().parent();
		var tips=row.find('span.tips');
		var msgError=tips.attr('rev');
		var boxMsg=row.find('blockquote');
		if((msgError==''||!msgError)&&tips.length>0){
			if (boxMsg.length>0){
				boxMsg.remove();
				tips.show();
			}
			return false;
		}
		if (value==''||value==null){
			boxMsg.remove();
			tips.show();
		} else if(thisInput.is('.engonly')&&!engOnly(value)){
			boxMsg.removeClass().addClass('error').text('不允许中文');
		} else if(thisInput.is('.emailonly')&&!emailOnly(value)){
			boxMsg.removeClass().addClass('error').text(msgError);
		} else if(thisInput.is('.numonly')&&!numOnly(value)){
			if (msgError==''||!msgError) msgError='只能是数字';
			boxMsg.removeClass().addClass('error').text(msgError);
		} else if(thisInput.is('.idonly')&&!idOnly(value)){
			if (msgError==''||!msgError) msgError='身份证号码格式错误';
			boxMsg.removeClass().addClass('error').text(msgError);
		} else {
			var textReg=thisInput.attr('rec');
			if (textReg==''||textReg==null){
				if (thisInput.is('.bind')){
					boxMsg.removeClass().text('如修改，请点击绑定进行操作，否则无法生效');
					row.find('a.bind').attr('rel', 'binding');
				} else {
					boxMsg.remove();
					tips.show();
				}
			} else if (thisInput.is('.js-length')){
				var length_array=textReg.split(',');
				var valueTrim=$.trim(value);
				if (valueTrim.length<Number(length_array[0])||valueTrim.length>Number(length_array[1])){
					var msgError=tips.attr('rev');
					if(msgError==''||!msgError) return false;
					boxMsg.removeClass().addClass('error').text(msgError);
				} else {
					boxMsg.removeClass().addClass('accepted').text('');
				}
			} else {
				var re=eval(textReg.replace(/\/\//g,"\/"));
				if (re.test(value)){
					if (thisInput.is('.bind')){
						boxMsg.removeClass().text('如修改，请点击绑定进行操作，否则无法生效');
						row.find('a.bind').attr('rel', 'binding');
					} else {
						boxMsg.removeClass().addClass('accepted').text('');
					}
				} else {
					var msgError=tips.attr('rev');
					if(msgError==''||!msgError) return false;
					boxMsg.removeClass().addClass('error').text(msgError);
				}
			}
		}
	}
	var blurRequired=function(thisInput){
		var value=thisInput.val();
		var row=thisInput.parent().parent();
		var tips=row.find('span.tips');
		var msgError=tips.attr('rev');
		if((msgError==''||!msgError)&&tips.length>0) return false;
		if (row.find('blockquote').length<1){
			tips.hide();
			row.append('<blockquote></blockquote>');
		}
		var boxMsg=row.find('blockquote');
		if (value==''||value==null){
			tips.show();
			boxMsg.remove();
		} else if(thisInput.is('.js-clone')){
			var targetId=thisInput.attr('rel');
			if (thisInput.val()!=$('#'+targetId).val()){
				var msgError=tips.attr('rev');
				if(msgError==''||!msgError) return false;
				boxMsg.removeClass().addClass('error').text(msgError);
			} else {
				boxMsg.removeClass().addClass('accepted').text('');
			}
		} else if(thisInput.is('.engonly')&&!engOnly(value)){
			boxMsg.removeClass().addClass('error').text('不允许中文');
		} else if(thisInput.is('.emailonly')&&!emailOnly(value)){
			boxMsg.removeClass().addClass('error').text(msgError);
		} else if(thisInput.is('.numonly')&&!numOnly(value)){
			if (msgError==''||!msgError) msgError='只能是数字';
			boxMsg.removeClass().addClass('error').text(msgError);
		} else if(thisInput.is('.idonly')&&!idOnly(value)){
			if (msgError==''||!msgError) msgError='身份证号码格式错误';
			boxMsg.removeClass().addClass('error').text(msgError);
		} else {
			var textReg=thisInput.attr('rec');
			if (textReg==''||textReg==null){
				if (thisInput.is('.bind')){
					boxMsg.removeClass().text('如修改，请点击绑定进行操作，否则无法生效');
					row.find('a.bind').attr('rel', 'binding');
				} else {
					boxMsg.removeClass().addClass('accepted').text('');
				}
			} else if (thisInput.is('.js-length')){
				var length_array=textReg.split(',');
				var valueTrim=$.trim(value);
				if (valueTrim.length<Number(length_array[0])||valueTrim.length>Number(length_array[1])){
					var msgError=tips.attr('rev');
					if(msgError==''||!msgError) return false;
					boxMsg.removeClass().addClass('error').text(msgError);
				} else {
					boxMsg.removeClass().addClass('accepted').text('');
				}
			} else {
				var re=eval(textReg.replace(/\/\//g,"\/"));
				if (re.test(value)){
					if (thisInput.is('.bind')){
						boxMsg.removeClass().text('如修改，请点击绑定进行操作，否则无法生效');
						row.find('a.bind').attr('rel', 'binding');
					} else {
						boxMsg.removeClass().addClass('accepted').text('');
					}
				} else {
					var msgError=tips.attr('rev');
					if(msgError==''||!msgError) return false;
					boxMsg.removeClass().addClass('error').text(msgError);
				}
			}
		}
	}
	$('form.form-validate input.text').focus(focusNormal);
	$('form.form-validate select').change(function(){
		var row=$(this).parent().parent();
		row.find('blockquote').remove();
	});
	$('form.form-validate div.row').not($('div.required')).find('input.text').blur(function(){
		var thisInput=$(this);
		setTimeout(function(){blurNormal(thisInput);}, 500);
	});
	$('form.form-validate div.required input.text').blur(function(){
		var thisInput=$(this);
		setTimeout(function(){blurRequired(thisInput);}, 500);	
	});
	//帮助图示
	$('form span.help').hover(function(){
		$(this).find('div').show();
	}, function(){
		$(this).find('div').hide();
	});
	//表单提交
	$('form.form-validate').submit(function(){
		if (document.getElementById('dialogError')) return false;
		//去除优惠码错误提示
		if (document.getElementById('j-btn-renew-msg')){
			$('#j-btn-renew-msg').removeClass().hide();
		}
		//是否选择站点
		if ($(this).find('#inputSiteid').length>0&&$('#inputSiteid').val()==''&&!$('#inputSiteid').is('.optional')){
			dialogError('请选择点击“选择网站”按钮选择一个站点', 'removeThis');
			return false;
		}
		
		//是否填写完整
		var checkList=$(this).find('ul.check');
		for (var i=0;i<checkList.length;i++){
			var needs=Number(checkList.eq(i).attr('rel'));
			if (checkList.eq(i).find('input:checked').length<needs){
				dialogError(checkList.eq(i).attr('title'), 'removeThis');
				return false;
			}
		}
		
		var colRequired=$(this).find('div.required input.text');
		for(var i=0;i<colRequired.length;i++){
			var value=$.trim(colRequired.eq(i).val());
                        var id=colRequired.eq(i).attr('id');
			var row=colRequired.eq(i).parents('.row');
			var tips=row.find('span.tips');
			if ((value==''||value==null) && id != 'dengji'){
				if (row.find('blockquote').length<1){
					tips.hide();
					row.append('<blockquote></blockquote>');
				}
				var boxMsg=row.find('blockquote');
				boxMsg.removeClass().addClass('error').text('此项为必填项');
			} else {
				//row.find('blockquote').remove();
			}
		}
		
		var colRequired2=$(this).find('div.required select,div.required input.upload[type="hidden"]');
		for(var i=0;i<colRequired2.length;i++){
			var value=$.trim(colRequired2.eq(i).val());
			var row=colRequired2.eq(i).parents('.row');
			var tips=row.find('span.tips');
			if (value==''||value==null||colRequired2.eq(i).find('option:selected').text()=='请选择'){
				if (row.find('blockquote').length<1){
					tips.hide();
					row.append('<blockquote></blockquote>');
				}
				var boxMsg=row.find('blockquote');
				if (colRequired2.eq(i).is('#city')){
					boxMsg.removeClass().addClass('error').text('请选择地区');
				} else if (colRequired2.eq(i).is('.upload')){
					boxMsg.removeClass().addClass('error').text('请上传文件');
				} else {
					boxMsg.removeClass().addClass('error').text('此项为必填项');
				}
			} else {
				row.find('blockquote').remove();
			}
		}

		//文件是否已上传
		if ($(this).find('#outputUpload').length>0){
			var uploads=$('#outputUpload input');
			for (var i=0;i<uploads.length;i++){
				if (uploads.eq(i).val()==''){
					dialogError('请上传'+uploads.eq(i).attr('rel'), 'removeThis');
					return false;
				}
			}
		}
		//是否存在输入错误，并且跳到出错的位置
		var colError=$(this).find('blockquote.error');
		
		if (colError.length>0){
			//dialogError('表单输入有错误，请按暗红色区块提示修正后再提交', 'removeThis');
			var errorFirst=colError.eq(0).parents('div.row');
			$('html,body').animate({scrollTop: errorFirst.offset().top}, 1000);
			return false;
		}
		
		//是否是AJAX提交
		if ($(this).is('.form-ajax')){
			var btnSubmit=$(this).find('button.formsubmit');
			var btnSubmit2=btnSubmit.parent().parent();
			var _box=btnSubmit2.parent();
			var _callback=_box.find('blockquote');
			if (_callback.length>0){
				if (_callback.is('.ok')){
					return false;
				} else {
					_callback.remove();
				}
			}
			btnSubmit.attr('disabled', true);
			btnSubmit2.addClass('btn-disable-ml');
			$(this).ajaxSubmit({
				dataType: 'json',
				cache: false,
				error: function(){
					_box.append('<blockquote class="clearfix failed" role="callback"><span class="icon">.</span><p>连接服务器失败，请重试</p></blockquote>');
					_box.find('blockquote').fadeIn('normal');
					btnSubmit2.removeClass('btn-disable-ml');
					btnSubmit.attr('disabled', false);
				},
				success: function(data){
					if (data.status=='failed'){
						_box.append('<blockquote class="clearfix failed" role="callback"><span class="icon">.</span><p>'+data.msg+'</p></blockquote>');
						_box.find('blockquote').fadeIn('normal');
						btnSubmit2.removeClass('btn-disable-ml');
						btnSubmit.attr('disabled', false);
					}
					if (data.status=='success'){
						if (data.msg){
							_box.append('<blockquote class="clearfix ok" role="callback"><span class="icon">.</span><p>'+data.msg+'</p></blockquote>');
							_box.find('blockquote').fadeIn('normal');
							_callback=_box.find('blockquote');
							if (data.dowhat=='reload'){
								setTimeout(function(){
									window.location.reload();
								}, 1000);
							} else if (data.dowhat=='direct'){
								setTimeout(function(){
									window.location.href=data.url;
								}, 1000);
							} else {
								setTimeout(function(){
									_callback.fadeTo('normal',0.0,function(){
										$(this).remove();
										btnSubmit2.removeClass('btn-disable-ml');
										btnSubmit.attr('disabled', false);
									});
								}, 1000);
							}
						} else {				
							window.location.href=data.url;
						}
					}
				}
			});
			return false;
		}
	});
	
	
	//输入框的focus事件
	var inputFocus=function(){
		if ($(this).val()==$(this).attr('rel')) $(this).val('');
		$(this).unbind('blur').blur(function(){
			if ($(this).val()==''||$(this).val()==null) $(this).val($(this).attr('rel'));
		});
	}
	$('input.js-focus').focus(inputFocus);
	
	//搜索表单提交
	$('form #datasearch').submit(function(){
		var keyword=$(this).find('input[name="keyword"]').val();
		if (keyword==''||keyword==null){
			dialogError('请输入搜索关键词！', 'removeThis');
			return false;
		}
	});
	
	/*
	 * panel install
	 */
	$('#siteIns-linkReset').click(function(){
		var iptReset=$('#siteIns-optReset');
		if ($(this).is('.selected')){
			$(this).removeClass('selected');
			iptReset.val('no');
		} else {
			$(this).addClass('selected');
			iptReset.val('yes');
		}
		return false;
	});
	$('#form-siteIns').submit(function(){
		var theForm=$(this);
		if ($('#siteIns-linkReset').is('.selected')){
			var items=$(this).find('input');
			var _data='';
			for (var i=0;i<items.length;i++){
				if (!items.eq(i).is('.button')){
					if (i!=0) _data+='&';
					var _label=items.eq(i).attr('name');
					var _val=items.eq(i).val();
					_data+=(_label+'='+_val);
				}
			}
			var source=$(this).attr('action');
			$(this).hide().parent().prepend('<div id="operatetip-siteIns" class="loading-ball">正在导入网站数据，请不要离开本页面...</div>');
			var disabledLinks=function(){
				if (!confirm('正在导入网站数据，离开本页将导致操作失败，您确定要继续吗？')){return false;}
			}
			$('a').click(disabledLinks);
			$.ajax({
				type: 'post',
				url: source,
				cache: false,
				data: _data,
				dataType: 'json',
				error: function(){
					dialogError('连接失败，请重试或联系管理员！');
					$('#confirm_dialogError').click(function(){
						$('#dialogError').remove();
						$('#jquery_addmask').remove();
						$('#operatetip-siteIns').remove();
						theForm.show();
						$('a').unbind('click', disabledLinks);
						return false;
					});
				},
				success: function(callback){
					if (callback.status=='failed'){
						dialogError(callback.msg);
						$('#confirm_dialogError').click(function(){
							$('#dialogError').remove();
							$('#jquery_addmask').remove();
							$('#operatetip-siteIns').remove();
							theForm.show();
							$('a').unbind('click', disabledLinks);
							return false;
						});
					}
					if (callback.status=='success'){
						location.href=callback.url;
					}
				}
			});
			return false;
		}
	});
	
	/*
	 * panel domain
	 */
	 
	 /*
	//选择购买年限
	$('#selectPeriod').change(function(){
		$('#textAmount').text($(this).find('option:selected').attr('rel'));
		$('#amount').attr('value', $(this).find('option:selected').attr('rel'));
	});
	//表单验证
	var validateForm=function(){
		var passwords=$(this).find('input[type="password"]');
		if (passwords.length>0&&passwords.eq(0).val()!=passwords.eq(1).val()){
			dialogError('两次输入的密码不一致', 'removeThis');
			return false;
		}
		if(passwords.eq(0).is('.required')==true&&$.trim(passwords.eq(0).val())!=''&&passwords.eq(0).val().length<6&&passwords.eq(0).val().length>18){
			dialogError('密码长度必须是6位至18位', 'removeThis');
			return false;
		}
		var texts=$(this).find('input.required, select.required');
		for (var i=0;i<texts.length;i++){
			var value=texts.eq(i).val();
			if (value==''||value==null){
				dialogError('所有带 * 的空都需要填写', 'removeThis');
				return false;
			}
			if (texts.eq(i).is('.engonly')){
				if (!engOnly(value)){
					dialogError('英文域名信息不允许输入中文和全角字符', 'removeThis');
					return false;
				}
			}
		}
	}
	$('#formDomainReg').submit(validateForm);
	$('#formWhoisModify').submit(validateForm);
	$('#formPasswordModify').submit(function(){
		var passwords=$(this).find('input[type="password"]');
		if (passwords.eq(0).val()==''||passwords.eq(0).val()==null){
			dialogError('请输入你要修改为的新密码', 'removeThis');
			return false;
		}
		if (passwords.eq(0).val()!=passwords.eq(1).val()){
			dialogError('两次输入的密码不一致', 'removeThis');
			return false;
		}
		if($.trim(passwords.eq(0).val())!=''&&passwords.eq(0).val().length<6&&passwords.eq(0).val().length>18){
			dialogError('密码长度必须是6位至18位', 'removeThis');
			return false;
		}
	});


	//选择网站
	var loadSitelist=function(url){
		$.ajax({
			url: url,
			dataType: 'json',
			cache: false,
			success: function(callback){
				if (callback.status=='failed'){
					dialogError(callback.msg, 'removeAll');
				}
				if (callback.status=='success'){
					var _html='';
					for (var i=0;i<callback.data.length;i++){
						_html+='<li class="clearfix" rel="'+callback.data[i].siteid+'" rev="'+callback.data[i].ends2+'"><div class="sitename">'+callback.data[i].name+'</div><div class="ends"><span class="grey">可用免费域名：</span><span class="text-ends2">'+callback.data[i].nums+'</span>个 <span class="grey">可用年限：</span><span class="text-ends">'+callback.data[i].years+'</span>年</div></li>';
					}
					$('#dialog1_container ul.list-site').html(_html);
					$('#dialog1_container ul.list-site li').hover(function(){
						$(this).addClass('hover');
					}, function(){
						$(this).removeClass('hover');
					});
					$('#dialog1_container ul.list-site li').click(function(){
						var sitename=$(this).find('div.sitename').text();
						var years=$(this).find('span.text-ends').text();
						var amount=0;
						var siteid=$(this).attr('rel');
						$('#inputSiteid').attr('value', siteid);
						$('#textYears').text(years);
						$('#period2').attr('value', years);
						$('#year1').hide();
						$('#year2').show();
						$('#button-choose').hide();
						$('#button-cancel').attr('style', '');
						$('#textSitename').text(sitename);
						$('#textAmount').text(amount);
						if (amount>Number($('#textBalance').text())){
							$('#textBalance').next().show();
							$('#containerSubmit').addClass('submit-disabled').find('.renewsubmit').attr('disabled',true);
						} else {
							$('#textBalance').next().hide();
							$('#containerSubmit').removeClass('submit-disabled').find('.renewsubmit').removeAttr('disabled');
						}
						$('#dialog1').fadeTo('slow', 0, function(){
							$(this).remove();
						});
						$('#jquery_addmask').fadeTo('slow', 0, function(){
							$(this).remove();
						});
					});
				}
			}
		});
	}
	$('#buttonSiteChange').click(function(){
		dialog1('选择网站', 352, 462, 'no', '取消');
		$('#dialog1 p.dialog-closer').html('<a id="dialog1_shut" href="#" title="关闭">关闭</a>');
		$('#dialog1_shut').click(function(){
			$('#jquery_addmask').fadeTo('slow', 0, function(){
				$(this).remove();
			});
			$('#dialog1').fadeTo('slow', 0, function(){
				$(this).remove();
			});
			$('.formError').remove();
			return false;
		});
		$('#dialog1_container').html('<div class="datalist-header"><div class="text"></div><form action="/member/domains/selectwebsite/"><input class="keywords" type="text" value="请输入网站名称" /><input class="submit" type="submit" value="" /></form></div><ul class="datalist list-site"></ul>');
		var url=$(this).attr('rel');
		loadSitelist(url);
		$('#dialog1_container form').submit(function(){
			var keywords=$(this).find('input.keywords').val();
			var url=$(this).attr('action')+keywords;
			loadSitelist(url);
			return false;
		});
		return false;
	});

	$('#cancel').click(function(){
		$('#year1').show();
		$('#year2').hide();
		$('#period2').attr('value', '');
		$('#inputSiteid').attr('value', '');
		$('#textAmount').text($('#amount').val());
		$('#textSitename').html('<strong class="red">不使用</strong>');
		$('#button-choose').show();
		$('#button-cancel').hide();
	});
	
	*/
	
	/*
	 * panel dns
	 */
	var dnsOperate=function(){
		var container=$(this).parents('tr');
		var host=container.find('input[name="host"]').val();
		var domain_id=container.find('input[name="domain_id"]').val();
		var domain=container.find('input[name="domain"]').val();
		var record_id=container.find('input[name="record_id"]').val();
		var type=container.find('select[name="type"]').val();
		var value=container.find('input[name="value"]').val();
		var priority=container.find('input[name="priority"]').val();
		var ttl=container.find('input[name="ttl"]').val();
		var source=$(this).attr('href');
		var submitMode=$(this).text();
		if (submitMode!='删除'){
			if (host==''||host==null){
				dialogError('请填写主机记录。', 'removeThis');
				return false;
			}else if($.trim(host)=='*'){
				dialogError('本站不支持泛解析。', 'removeThis');
				return false;				
			}
			if (value==''||value==null){
				dialogError('请填写记录值。', 'removeThis');
				return false;
			}
			var patrn_ip =/^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/;
			var patrn_domain =/^([\w-]+\.)+((com)|(net)|(org)|(gov\.cn)|(info)|(cc)|(com\.cn)|(net\.cn)|(org\.cn)|(name)|(biz)|(tv)|(cn)|(mobi)|(name)|(sh)|(ac)|   (io)|(tw)|(com\.tw)|(hk)|(com\.hk)|(ws)|(travel)|(us)|(tm)|(la)|(me\.uk)|(org\.uk)|(ltd\.uk)|(plc\.uk)|(in)|(eu)|(it)|(jp))$/;
			
			if(type=='CNAME'){
				var cname;
				if(value.substr(value.length-1,1)=='.'){
					cname = value.substr(0,value.length-1);
				}
				else cname = value;
				if(!patrn_domain.test(cname)){
					dialogError("CNAME记录值必须是正确的域名格式", 'removeThis');
					return false;
				}
			}else if(type=='A'&&!patrn_ip.test(value)){
				dialogError("A记录值必须以是IP格式", 'removeThis');
				return false;			
			}else if(type=='MX'){
				var mx_va;
				if(value.substr(value.length-1,1)=='.'){
					mx_va = value.substr(0,value.length-1);
				}
				else mx_va = value;
				if(!patrn_ip.test(mx_va)&&!patrn_domain.test(mx_va)){
					dialogError("MX记录值必须以是IP格式或者正确的域名格式", 'removeThis');
					return false;
				}
			}
			if(isNaN(priority)){
				dialogError("优先级必须为数字", 'removeThis');
				return false;				
			}
		}
		switch(submitMode){
			case '删除':
				var _data='data[Domain_name][action]=del&data[Domain_name][record_id]='+record_id;
				break;
			case '添加记录':
				var _data='data[Domain_name][action]=create&data[Domain_name][host_record]='+host+'&data[Domain_name][domain_id]='+domain_id+'&data[Domain_name][record_type]='+type+'&data[Domain_name][record_value]='+value+'&data[Domain_name][priority]='+priority+'&data[Domain_name][ttl]='+ttl+'&data[Domain_name][domain]='+domain;
				break;
			case '修改':
				var _data='data[Domain_name][action]=modify&data[Domain_name][record_id]='+record_id+'&data[Domain_name][host_record]='+host+'&data[Domain_name][record_type]='+type+'&data[Domain_name][record_value]='+value+'&data[Domain_name][priority]='+priority+'&data[Domain_name][ttl]='+ttl+'&data[Domain_name][domain]='+domain;
				break;
			default:
				var _data='';
		}
		var thisLink=$(this);
		$.documentMask();
		$('body').append('<div id="loadDns" class="note-loading">正在载入...</div>');
		var arrayPageSize = getPageSize();
		var arrayPageScroll = getPageScroll();
		var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 26) / 2 + 'px';
		$('#loadDns').css('top', css_top).show();
		$.ajax({
			type: 'post',
			url: source,
			data: _data,
			dataType: 'json',
			cache: false,
			error: function(){
				$('#loadDns').remove();
				dialogError('请求提交失败，请重试', 'removeThis');
			},
			success: function(callback){
				
/*
 * JSON格式
 * status: success/failed
 * msg: 错误提示（如成功则不输出）
 * 
 * 以下数据仅在 修改 和 添加的情形下输出
 * 
 * domain: 域名（chinaz.com）
 * host: 主机记录（www）
 * id: 解析记录的ID
 * type: 记录类型（A / CNAME / MX / URL转发）
 * value: 记录值（202.23.0.88）
 * priority: 优先级
 * ttl: TTl（3600）
 * directmode: 是否隐藏转发（hide / show）
 * 
 * 
 */
				
				$('#loadDns').remove();
				if (callback.status=='failed'){
					dialogError(callback.msg, 'removeThis');
					return false;
				}
				$('#jquery_addmask').fadeTo('slow', 0, function(){
					$(this).remove();
				});
				if (submitMode=='删除'){
					container.remove();
				} else {
					switch(callback.type){
						case 'A':
							var _type='<select name="type"><option value="A" selected="selected">A</option><option value="CNAME">CNAME</option><option value="MX">MX</option><option value="TXT">TXT</option></select>';
							break;
						case 'CNAME':
							var _type='<select name="type"><option value="A">A</option><option value="CNAME" selected="selected">CNAME</option><option value="MX">MX</option><option value="TXT">TXT</option></select>';
							break;
						case 'MX':
							var _type='<select name="type"><option value="A">A</option><option value="CNAME">CNAME</option><option value="MX" selected="selected">MX</option><option value="TXT">TXT</option></select>';
							break;
						case 'TXT':
							var _type='<select name="type"><option value="A">A</option><option value="CNAME">CNAME</option><option value="MX">MX</option><option value="TXT" selected="selected">TXT</option></select>';
							break;
						default:
							var _type='';
					}
					if(callback.priority == null){
						callback.priority = '';
					}
					var _html='<td class="dns-host"><input name="host" class="text" type="text" size="4" value="'+callback.host+'" /></td><td class="dns-domain">.'+callback.domain+' <input type="hidden" name="record_id" value="'+callback.record_id+'" /></td><td class="dns-type">'+_type+'</td><td class="dns-value"><input name="value" class="text" type="text" size="14" value="'+callback.value+'" /></td><td class="dns-priority"><input name="priority" class="text" type="text" size="2" value="'+callback.priority+'" /></td><td class="dns-ttl"><input name="ttl" class="text" type="text" size="3" value="'+callback.ttl+'" /></td><td class="dns-operate"><span class="button"><a href="/member/domains/names/'+callback.domain_id+'">修改</a></span><span class="button button-del"><a href="/member/domains/names/'+callback.domain_id+'">删除</a></span></td>';
					if (submitMode=='修改'){
						container.html(_html);
						container.find('span.button a').click(dnsOperate);
					}
					if (submitMode=='添加记录'){
						container.find('input[name="host"]').attr('value','');
						container.find('select[name="type"] option:nth-child(1)').attr('selected','selected');
						container.find('input[name="value"]').attr('value','');				
						$('#listDns').prepend('<tr>'+_html+'</tr>');
						$('#listDns tr').eq(0).find('span.button a').click(dnsOperate);
					}
				}
			}
		});
		return false;
	}
	$('#containerDns span.button a').click(dnsOperate);
	
	
	var dnsOperate_admin=function(){
		var container=$(this).parents('tr');
		var host=container.find('input[name="host"]').val();
		var domain_id=container.find('input[name="domain_id"]').val();
		var domain=container.find('input[name="domain"]').val();
		var id=container.find('input[name="id"]').val();
		var record_id=container.find('input[name="record_id"]').val();
		var type=container.find('select[name="type"]').val();
		var value=container.find('input[name="value"]').val();
		var priority=container.find('input[name="priority"]').val();
		var ttl=container.find('input[name="ttl"]').val();
		var source=$(this).attr('href');
		var submitMode=$(this).text();
		if (submitMode!='删除'){
			if (host==''||host==null){
				dialogError('请填写主机记录。', 'removeThis');
				return false;
			}else if($.trim(host)=='*'){
				dialogError('本站不支持泛解析。', 'removeThis');
				return false;				
			}
			if (value==''||value==null){
				dialogError('请填写记录值。', 'removeThis');
				return false;
			}
			var patrn_ip =/^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/;
			var patrn_domain =/^([\w-]+\.)+((com)|(net)|(org)|(gov\.cn)|(info)|(cc)|(com\.cn)|(net\.cn)|(org\.cn)|(name)|(biz)|(tv)|(cn)|(mobi)|(name)|(sh)|(ac)|   (io)|(tw)|(com\.tw)|(hk)|(com\.hk)|(ws)|(travel)|(us)|(tm)|(la)|(me\.uk)|(org\.uk)|(ltd\.uk)|(plc\.uk)|(in)|(eu)|(it)|(jp))$/;
			
			if(type=='CNAME'){
				var cname;
				if(value.substr(value.length-1,1)=='.'){
					cname = value.substr(0,value.length-1);
				}
				else cname = value;
				if(!patrn_domain.test(cname)){
					dialogError("CNAME记录值必须是正确的域名格式", 'removeThis');
					return false;
				}
			}else if(type=='A'&&!patrn_ip.test(value)){
				dialogError("A记录值必须以是IP格式", 'removeThis');
				return false;			
			}else if(type=='MX'){
				var mx_va;
				if(value.substr(value.length-1,1)=='.'){
					mx_va = value.substr(0,value.length-1);
				}
				else mx_va = value;
				if(!patrn_ip.test(mx_va)&&!patrn_domain.test(mx_va)){
					dialogError("MX记录值必须以是IP格式或者正确的域名格式", 'removeThis');
					return false;
				}
			}
			if(isNaN(priority)){
				dialogError("优先级必须为数字", 'removeThis');
				return false;				
			}
		}
		alert(record_id);
		switch(submitMode){
			case '删除':
				var _data='data[Domain_name][action]=del&data[Domain_name][record_id]='+record_id;
				break;
			case '添加记录':
				var _data='data[Domain_name][action]=create&data[Domain_name][host_record]='+host+'&data[Domain_name][domain_id]='+domain_id+'&data[Domain_name][record_type]='+type+'&data[Domain_name][record_value]='+value+'&data[Domain_name][priority]='+priority+'&data[Domain_name][ttl]='+ttl+'&data[Domain_name][domain]='+domain;
				break;
			case '保存':
				var _data='data[Domain_name][action]=modify&data[Domain_name][record_id]='+record_id+'&data[Domain_name][host_record]='+host+'&data[Domain_name][record_type]='+type+'&data[Domain_name][record_value]='+value+'&data[Domain_name][priority]='+priority+'&data[Domain_name][ttl]='+ttl+'&data[Domain_name][domain]='+domain;
				break;
			default:
				var _data='';
		}
		var thisLink=$(this);
		$('body').append('<div id="loadDns" class="note-loading">正在载入...</div>');
		var arrayPageSize = getPageSize();
		var arrayPageScroll = getPageScroll();
		var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 26) / 2 + 'px';
		$('#loadDns').css('top', css_top).show();
		$.ajax({
			type: 'post',
			url: source,
			data: _data,
			dataType: 'json',
			cache: false,
			error: function(){
				$('#loadDns').remove();
				alert('请求提交失败，请重试', 'removeThis');
			},
			success: function(callback){
			$('#loadDns').remove();
				if (callback.status=='failed'){
					alert(callback.msg);
					return false;
				}
				$('#jquery_addmask').fadeTo('slow', 0, function(){
					$(this).remove();
				});
				if (submitMode=='删除'){
					container.remove();
				} else {
					switch(callback.type){
						case 'A':
							var _type='<select name="type"><option value="A" selected="selected">A</option><option value="CNAME">CNAME</option><option value="MX">MX</option></select>';
							break;
						case 'CNAME':
							var _type='<select name="type"><option value="A">A</option><option value="CNAME" selected="selected">CNAME</option><option value="MX">MX</option></select>';
							break;
						case 'MX':
							var _type='<select name="type"><option value="A">A</option><option value="CNAME">CNAME</option><option value="MX" selected="selected">MX</option></select>';
							break;
						default:
							var _type='';
					}
				//	var _html='<td class="dns-host"><input name="host" class="text" type="text" size="4" value="'+callback.host+'" /></td><td class="dns-domain">.'+callback.domain+' <input type="hidden" name="domain" value="'+callback.domain+'" /><input type="hidden" name="id" value="'+callback.id+'" /></td><td class="dns-type">'+_type+'</td><td class="dns-value"><input name="value" class="text" type="text" size="14" value="'+callback.value+'" /></td><td class="dns-priority"><input name="priority" class="text" type="text" size="2" value="'+callback.priority+'" /></td><td class="dns-ttl"><input name="ttl" class="text" type="text" size="3" value="'+callback.ttl+'" /></td><td class="dns-operate"><span class="button"><a href="/member/domains/names/'+callback.domain_id+'">修改</a></span><span class="button button-del"><a href="/member/domains/names/'+callback.domain_id+'">删除</a></span></td>';
				//	if (submitMode=='修改'){
				//		container.html(_html);
				//		container.find('span.button a').click(dnsOperate_admin);
				//	}
					alert('操作成功！');
					var _html = '<td width="22"><input name="del_id[]" class=\'ids\' type="checkbox" value="'+callback.id+'" /><input type=\'hidden\' name=\'id\' value=\''+callback.id+'\' /></td>';
					_html += '<td width="60">'+callback.id+'</td>';
					_html += '<td width="40"><input type=\'text\' name=\'host\' value='+callback.host+' /><input type=\'hidden\' name=\'domain_id\' value='+callback.domain_id+' /></td>';
					_html += '<td>.'+callback.domain+'<input type=\'hidden\' name=\'domain\' value='+callback.domain+' /></td>';
					_html += '<td>'+_type+'</td>';
					_html += '<td><input type=\'text\' name=\'value\' value='+callback.value+' /></td>';
					_html += '<td><input type=\'text\' name=\'priority\' value='+callback.priority+' /></td>';
					_html += '<td><input type=\'text\' name=\'ttl\' value='+callback.ttl+' /></td>';
					_html += '<td width="160"><span class=\'button\'><a href=\'/admin/Domains/names_edit/'+callback.domain_id+'\' >保存</a>  <a href=\'/admin/Domains/names_edit/'+callback.domain_id+' onclick="return confirm(\'确认删除吗?\');">删除</a></span></td>';
					if (submitMode=='添加记录'){
						container.find('input[name="host"]').attr('value','');
						container.find('select[name="type"] option:nth-child(1)').attr('selected','selected');
						container.find('input[name="value"]').attr('value','');
						container.find('input[name="priority"]').attr('value','');						
						$('#listDns').prepend('<tr onmouseout="this.style.backgroundColor=\'\';" onmouseover="this.style.backgroundColor=\'#e6f1ff\';">'+_html+'</tr>');
						$('#listDns tr').eq(0).find('span.button a').click(dnsOperate_admin);
					}
				}
			}
		});
		return false;
	}	
	$('#containerDns_admin span.button a').click(dnsOperate_admin);
	$('#containerDns_add span.button a').click(dnsOperate_admin);
	
	
	//操作日志表格
	var datatable=$('#listRecords tr:odd').addClass('even');
	var openDetail=function(){
		var row=$(this).parents('tr');
		if (row.next().is('.detail-view')){
			row.removeClass('detail-opener').next().remove();
		} else {
			row.addClass('detail-opener').after('<tr class="detail-view"><td colspan="6"><div class="detail-box"><img class="arrow" src="../../img/mod/member/arrow-popo.gif" alt="" /><div class="detail-inner">正在读取...</div></div></td></tr>');
			var container=row.next().find('div.detail-inner');
			$.ajax({
				url: $(this).attr('rel'),
				dataType: 'json',
				cache: false,
				error: function(){
					container.html('<span class="red">读取失败，请重试！</span>');
				},
				success: function(callback){
					if (callback.status=='failed'){
						container.html('<span class="red">'+callback.msg+'</span>');
					}
					if (callback.status=='success'){
						var _html='';
							_html+=('<span class="item"><span class="">'+callback.msg+'</span> </span>');
						container.html(_html);
					}
				}
			});
		}
		return false;
	}
	$('#listRecords a.detail').click(openDetail);
	$('#buttonMoreRecords').click(function(){
		if ($(this).text()=='正在载入...') return false;
		var source=$(this).attr('rel');
		$(this).text('正在载入...');
		var thisLinks=$(this);
		$.ajax({
			url: source,
			cache: false,
			error: function(){
				dialogError('请求提交失败，请重试', 'removeThis');
				$(this).html('<strong>.::</strong> 更多日志 <strong>::.</strong>');
			},
			success: function(callback){
				$('#listRecords').append(callback);
				thisLinks.remove();
				var datatable=$('#listRecords tr:not(.detail-view):odd').addClass('even');
				$('#listRecords a.detail').unbind('click');
				$('#listRecords a.detail').click(openDetail);
			}
		});
		return false;
	});
	
	$('#dnsDefault input').click(function(){
		var value = $(this).val();
		if(value=='0')$('#dnsValue').hide();
		else $('#dnsValue').show();
	});
	
	//账户明细操作日志表格
	var datatable=$('#listFinance tr:odd').addClass('even');
	var openDetail=function(){
		var row=$(this).parents('tr');
		if (row.next().is('.detail-view')){
			row.removeClass('detail-opener').next().remove();
		} else {
			row.addClass('detail-opener').after('<tr class="detail-view"><td colspan="8"><div class="detail-box"><img class="arrow" src="../../img/mod/member/arrow-popo.gif" alt="" /><div class="detail-inner">正在读取...</div></div></td></tr>');
			var container=row.next().find('div.detail-inner');
			$.ajax({
				url: $(this).attr('rel'),
				dataType: 'json',
				cache: false,
				error: function(){
					container.html('<span class="red">读取失败，请重试！</span>');
				},
				success: function(callback){
					if (callback.status=='failed'){
						container.html('<span class="red">'+callback.msg+'</span>');
					}
					if (callback.status=='success'){
						var _html='';
							_html+=('<span class="item"><span class="">'+callback.msg+'</span> </span>');
						container.html(_html);
					}
				}
			});
		}
		return false;
	}
	$('#listFinance a.detail').click(openDetail);
	$('#buttonMoreRecords').click(function(){
		if ($(this).text()=='正在载入...') return false;
		var source=$(this).attr('rel');
		$(this).text('正在载入...');
		var thisLinks=$(this);
		$.ajax({
			url: source,
			cache: false,
			error: function(){
				dialogError('请求提交失败，请重试', 'removeThis');
				$(this).html('<strong>.::</strong> 更多日志 <strong>::.</strong>');
			},
			success: function(callback){
				$('#listFinance').append(callback);
				thisLinks.remove();
				var datatable=$('#listFinance tr:not(.detail-view):odd').addClass('even');
				$('#listFinance a.detail').unbind('click');
				$('#listFinance a.detail').click(openDetail);
			}
		});
		return false;
	});
	
	$('#dnsDefault input').click(function(){
		var value = $(this).val();
		if(value=='0')$('#dnsValue').hide();
		else $('#dnsValue').show();
	});
	
	/*
	 * panel agent recharge
	 */
	//分销商模块下属用户入款
	$('#formRecharge input[name="lower"]').blur(function(){
		var value=$(this).val();
		var row=$(this).parent().parent();
		var tips=row.find('span.tips');
		if (row.find('blockquote').length<1){
			tips.hide();
			row.append('<blockquote></blockquote>');
		}
		var boxMsg=row.find('blockquote');
		if (value==''||value==null){
			boxMsg.removeClass().addClass('error').text('不能为空！');
			return false;
		}
		boxMsg.removeClass().addClass('loading').text('用户名检测中...');
		$.ajax({
			url: 'callback/check-lower.php',
			dataType: 'json',
			error: function(){
				boxMsg.removeClass().addClass('error').text('连接失败，请重试');
			},
			success: function(callback){
				if (callback.status=='failed'){
					boxMsg.removeClass().addClass('error').text(callback.msg);
					return false;
				}
				if (callback.status=='success'){
					boxMsg.removeClass().addClass('accepted').text(callback.msg);
					$('#formRecharge input[name="lower"]').attr('rel', 'ok');
					if ($('#formRecharge input[name="amount"]').attr('rel')=='ok'){
						$('#containerSubmit').removeClass('submit-disabled');
					}
				}
			}
		});
	});
	$('#formRecharge input[name="lower"]').focus(function(){
		$('#containerSubmit').addClass('submit-disabled');
		var row=$(this).parent().parent();
		var tips=row.find('span.tips');
		if (row.find('blockquote').length<1){
			tips.hide();
			row.append('<blockquote></blockquote>');
		}
		var boxMsg=row.find('blockquote');
		boxMsg.removeClass().text('请输入下属用户名');
		$(this).attr('rel', 'wrong');
	});
	$('#formRecharge input[name="amount"]').blur(function(){
		var value=$(this).val();
		var row=$(this).parent().parent();
		if (row.find('blockquote').length<1){
			row.append('<blockquote></blockquote>');
		}
		var boxMsg=row.find('blockquote');
		if (value==''||value==null){
			boxMsg.removeClass().addClass('error').text('不能为空！');
			return false;
		}
		var regAmount=/^([1-9]\d+|[1-9])(\.\d\d?)*$/;
		if (!regAmount.test(value)){
			boxMsg.removeClass().addClass('error').text('请输入正确的金额');
			return false;
		}
		var balance=$('#textBalance').text();
		if (Number(value)>Number(balance)){
			boxMsg.removeClass().addClass('error').html('您的余额不足，请您<a href="#">充值</a>');
			$('#textBalance').next().show();
			return false;
		}
		boxMsg.remove();
		$(this).attr('rel', 'ok');
		if ($('#formRecharge input[name="lower"]').attr('rel')=='ok'){
			$('#containerSubmit').removeClass('submit-disabled');
		}
	});
	$('#formRecharge input[name="amount"]').focus(function(){
		$('#containerSubmit').addClass('submit-disabled');
		$(this).attr('rel', 'wrong');
		$('#textBalance').next().hide();
	});
	
	
	/*
	 * panel withdraw
	 */
	//验证提现金额
	$('#applicationsubmit').click(function(){
		var money=$('#applicationmoney').val();
		if (!ckeckradio()){
			dialogError('请选择提现方式', 'removeAll');
			return false;
		}
		if (money==''||money==null){
			dialogError('请输入提现金额', 'removeAll');
			return false;
		}
		var regMoney=/^(([1-9]\d*)|0)(\.\d{1,2})?$/;
		if (!regMoney.test(money)||Number(money)<100){
			dialogError('最小提现金额不能低于100元，请您核对', 'removeAll');
			return false;
		}
	});
	//添加提现帐号
	$('#listPassport a.create, #listPassport a.validate').click(function(){
		var title=$(this).attr('title');
		if ($(this).is('.create')){
			dialog1(title, 372, 442, '', '提交绑定');
		} else if ($(this).is('.validate')){
			dialog1(title, 267, 442, '', '提交验证');
		} else {
			return false;
		}
		var source=$(this).attr('rel');
		$.ajax({
			url: source,
			cache: false,
			error: function(){
				dialogError('连接失败，请重试', 'removeAll');
			},
			success: function(callback){
				$('#dialog1_container').html(callback);
				$('#selectBank').change(function(){
					var bankSelected=$(this).find('option:selected');
					var bankName=bankSelected.text();
					var bankImg=bankSelected.attr('rel');
					if (bankName=='请选择银行'||bankImg==''||bankImg==null){
						$('#viewBankimg').removeClass().text('');
					} else {
						$('#viewBankimg').removeClass().addClass('bankimg').addClass('bankimg-'+bankImg).text(bankName);
					}
				});
				//验证银行帐号
				$('#formBankvalidate').submit(function(){
					var money=$('#inputBankvalidate').val();
					if (money==''||money==null){
						dialogError('请输入您收到的转账金额', 'removeSelf');
						return false;
					}
					var regMoney=/^(([1-9]\d*)|0)(\.\d{1,2})?$/;
					if (!regMoney.test(money)||Number(money)>0.99||Number(money)<0.01){
						dialogError('金额为0.01~0.99之间，保留两位小数点，请您核对', 'removeSelf');
						return false;
					}
				});
				//绑定支付宝、财付通
				$('#formPayinfo').submit(function(){
					var inputs=$(this).find('input.text');
					for (var i=0;i<inputs.length;i++){
						if (inputs.eq(i).val()==''||inputs.eq(i).val()==null){
							dialogError('请将表单输入完整', 'removeSelf');
							return false;
						}
					}
				});
				//提交银行账户
				$('#formBankinfo').submit(function(){
					var selects=$(this).find('select');
					for (var i=0;i<selects.length;i++){
						var text=selects.eq(i).find('option:selected').text();
						if (text=='请选择'||text=='请选择银行'){
							dialogError('请将表单输入完整', 'removeSelf');
							return false;
						}
					}
					var inputs=$(this).find('input.text');
					for (var i=0;i<inputs.length;i++){
						if (inputs.eq(i).val()==''||inputs.eq(i).val()==null){
							dialogError('请将表单输入完整', 'removeSelf');
							return false;
						}
					}
					var v_account = $(this).find('input[name="data[account]"]').val();
					var v_account_confirm = $(this).find('input[name="data[bank_account_confirm]"]').val();
					if(!v_account.length || v_account.length <=10){
						dialogError('银行卡号输入位数有误', 'removeSelf');
						return false;
					}
					if (v_account != v_account_confirm){
						if (inputs.eq(i).val()==''||inputs.eq(i).val()==null){
							dialogError('两次输入的银行卡号不一致，请核对！', 'removeSelf');
							return false;
						}
					}
				});
				$('#confirm_dialog1').click(function(){
					$('#dialog1_container form').submit();
				});
			}
		});
		return false;
	});
	
	
	/*
	 * panel website
	 */
	//续费
	
	(function(){
		if (!document.getElementById('j-btn-renew-coupon')) return false;
		var httpCouponUse=null;
		$('#j-btn-renew-coupon').click(function(){
			$('#j-btn-renew-msg').hide()
			if (httpCouponUse) httpCouponUse.abort();
			var coupon=$(this).parent().find('input').val();
			if (!coupon || coupon==''){
				$('#j-btn-renew-msg').addClass('error').text('请输入优惠码').show();
				return false;
			}
			var container=$(this).parent();
			httpCouponUse=$.ajax({
				type: 'post',
				url: $(this).attr('rel')+$('#selectRenew').val(),
				data: 'coupon_code='+coupon,
				dataType: 'json',
				cache: false,
				error: function(){
					$('#j-btn-renew-msg').addClass('error').text('连接服务器失败，请重试').show();
				},
				success: function(data){
					if (data.status=='failed'){
						$('#j-btn-renew-msg').addClass('error').text(data.msg).show();
					}
					if (data.status=='success'){
						container.html('<span class="saved">您使用的优惠码为您节省 <strong class="red">'+data.save+' </strong>元</span> <input name="memc_code" type="hidden" value="'+data.memc_code+'" />');
						$('#textAmount').text(data.amount);
					}
				}
			});
			return false;
		});
	})();
	
	
	$('#selectRenew').change(function(){
		var cost=$(this).find('option:selected').attr('rel');
		$('#textAmount').text(cost);
	/*	if (Number(cost)>Number($('#textBalance').text())){
			$('#textBalance').next().show();
			$('#containerSubmit').addClass('submit-disabled').find('.renewsubmit').attr('disabled',true);
		} else {
			$('#textBalance').next().hide();
			$('#containerSubmit').removeClass('submit-disabled').find('.renewsubmit').removeAttr('disabled');
		}
		var years=Number($(this).val());
		var source=$(this).attr('rel')+'?year='+years;
		$('#listFees').html('<li>正在加载中...</li>');
		$.ajax({
			url: source,
			dataType: 'json',
			error: function(){
				$('#listFees').html('<li class="red">费用清单载入失败，请重试</li>');
			},
			success: function(callback){
				if (callback.status=='failed'){
					$('#listFees').html('<li class="red">'+callback.msg+'</li>');
				}
				if (callback.status=='success'){
					var _html='';
					for (var i=0;i<callback.data.length;i++){
						_html+='<li>'+callback.data[i].name+'： <strong class="orange">'+callback.data[i].fee+'</strong> <span class="grey">元</span></li>';
					}
					$('#textAmount').text(callback.amount);
					$('#listFees').html(_html);
				}
			}
		});
		*/
	});
	
	//域名续费
	$('#selectRenew_domain').change(function(){
		var cost=$(this).find('option:selected').attr('rel');
		$('#textAmount').text(cost);
	});	
	
	//升级套餐
	$('#radioUpgrade input').click(function(){
		var cost=$(this).attr('rel');
		$('#textAmount').text(cost);
		/*	if (Number(cost)>Number($('#textBalance').text())){
			$('#textBalance').next().show();
			$('#containerSubmit').addClass('submit-disabled').find('.renewsubmit').attr('disabled',true);
		} else {
			$('#textBalance').next().hide();
			$('#containerSubmit').removeClass('submit-disabled').find('.renewsubmit').removeAttr('disabled');
		}*/
	});
	
	var appChange=function(){
		if (document.getElementById('costPackage'))
			var costPackage=Number($('#costPackage').text());
		else
			var costPackage=0;
		var appList=$('#fieldApplication input:checked');
		if (appList.length<1){
			$('#countApp').html('<span class="choice grey">未选择拓展功能</span>');
			$('#textAmount').text(costPackage);
		} else {
			var restTime=Number($('#textResttime').text());
			var costApp=0;
			for (var i=0;i<appList.length;i++){
				costApp+=Number(appList.eq(i).parents('li').find('.price').text());
			}
			costApp=changeTwoDecimal(costApp/12*restTime);
			$('#countApp').html('<strong class="choice">已选择'+appList.length+'个拓展功能</strong> 所需费用：<strong id="costApp" class="orange">'+costApp+'</strong>元');
			$('#textAmount').text((costPackage*1000+costApp*1000)/1000);
		}
	}
	$('#fieldApplication input').click(appChange);
	
	/*
	//升级套餐
	$('#fieldPackage input').click(function(){
		if (document.getElementById('costApp'))
			var costApp=Number($('#costApp').text());
		else
			var costApp=0;
		if ($(this).is('.active')){
			$('#countPackage').html('<span class="choice grey">不升级套餐</span>');
			$('#textAmount').text(costApp);
		} else {
			var container=$(this).parents('li');
			var restTime=Number($('#textResttime').text());
			var costPackage=changeTwoDecimal(((Number(container.find('.price').text())-Number($('#fieldPackage input.active').parents('li').find('span.price').text()))/12)*restTime);
			var _package=container.find('.package').text();
			//$('#countPackage').html('<strong class="choice">'+_package+'</strong> 升级所需费用：<strong id="costPackage" class="orange"></strong>元');
		//	$('#textAmount').text('');
		}
		$('#fieldApplication').html('');
		$('#countApp').html('<div class="loading">正在载入插件信息...</div>');
		$.ajax({
			type:'post',
			url: $('#fieldPackage').attr('rel'),
			data: 'data[packageid]='+$(this).val()+'&data[restTime]='+restTime,
			dataType: 'json',
			cache: false,
			error: function(msg,s){
				$('#countApp').html('<div class="error">连接失败，请重试</div>');
			},
			success: function(callback){
				if (callback.status=='failed'){
					$('#countApp').html('<div class="error">'+callback.msg+'</div>');
				}
				if (callback.status=='success'){
					var _html='';
					for (var i=0;i<callback.data.length;i++){
						switch(callback.data[i].status){
							case '已包含':
								var item='<span class="input"><input id="checkboxApp_'+callback.data[i].appid+'" name="data[package_ext][]" type="checkbox" autocomplete="off" disabled="disabled" value="'+callback.data[i].appid+'" rel="" /></span><span class="text grey"><label for="checkboxApp_'+callback.data[i].appid+'">'+callback.data[i].name+' (套餐已包含)</label></span>';
								break;
							case '已选':
								var item='<span class="input"><input id="checkboxApp_'+callback.data[i].appid+'" name="data[package_ext][]" type="checkbox" autocomplete="off" disabled="disabled" value="'+callback.data[i].appid+'" rel="" /></span><span class="text grey"><label for="checkboxApp_'+callback.data[i].appid+'">'+callback.data[i].name+' (套餐已选)</label></span>';
								break;
							case '可选':
								var item='<span class="input"><input id="checkboxApp_'+callback.data[i].appid+'" name="data[package_ext][]" type="checkbox" autocomplete="off" value="'+callback.data[i].appid+'" rel="" /></span><span class="text"><label for="checkboxApp_'+callback.data[i].appid+'">'+callback.data[i].name+' <span class="grey">(<strong class="orange price">'+callback.data[i].price+'</strong>元/年)</span></label></span>';
								break;
						}
						_html+='<li class="clearfix">'+item+'</li>';
					}
					if(callback.suit_price_remain) {
						$('#textAmount').text(callback.suit_price_remain);
						$('#countPackage').html('<strong class="choice">'+_package+'</strong> 升级所需费用：<strong id="costPackage" class="orange">'+callback.suit_price_remain+'</strong>元');
					}
					$('#fieldApplication').html(_html);
					$('#fieldApplication input').click(appChange);
					$('#countApp').html('<span class="choice grey">请选择拓展功能</span>');
				}
			}
		});
	});
	*/
	
	//升级套餐
	$('#fieldPackage input').click(function(){
		if (document.getElementById('costApp'))
			var costApp=Number($('#costApp').text());
		else
			var costApp=0;
		if ($(this).is('.active')){
			$('#countPackage').html('<span class="choice grey">不升级套餐</span>');
			$('#textAmount').text(costApp);
		} else {
			var container=$(this).parents('li');
			var restTime=Number($('#textResttime').text());
			var costPackage=changeTwoDecimal(((Number(container.find('.price').text())-Number($('#fieldPackage input.active').parents('li').find('span.price').text()))/12)*restTime);
			var _package=container.find('.package').text();
			//$('#countPackage').html('<strong class="choice">'+_package+'</strong> 升级所需费用：<strong id="costPackage" class="orange"></strong>元');
		//	$('#textAmount').text('');
		}
		$('#fieldApplication').html('');
		$('#countApp').html('<div class="loading">正在载入插件信息...</div>');
		$.ajax({
			type:'post',
			url: $('#fieldPackage').attr('rel'),
			data: 'data[packageid]='+$(this).val()+'&data[restTime]='+restTime,
			dataType: 'json',
			cache: false,
			error: function(msg,s){
				$('#countApp').html('<div class="error">连接失败，请重试</div>');
			},
			success: function(callback){
				if (callback.status=='failed'){
					$('#countApp').html('<div class="error">'+callback.msg+'</div>');
				}
				if (callback.status=='success'){
					var _html='';
					for (var i=0;i<callback.data.length;i++){
						switch(callback.data[i].status){
							case '已包含':
								var item='<span class="input"><input id="checkboxApp_'+callback.data[i].appid+'" name="data[package_ext][]" type="checkbox" autocomplete="off" disabled="disabled" value="'+callback.data[i].appid+'" rel="" /></span><span class="text grey"><label for="checkboxApp_'+callback.data[i].appid+'">'+callback.data[i].name+' (套餐已包含)</label></span>';
								break;
							case '已选':
								var item='<span class="input"><input id="checkboxApp_'+callback.data[i].appid+'" name="data[package_ext][]" type="checkbox" autocomplete="off" disabled="disabled" value="'+callback.data[i].appid+'" rel="" /></span><span class="text grey"><label for="checkboxApp_'+callback.data[i].appid+'">'+callback.data[i].name+' (套餐已选)</label></span>';
								break;
							case '可选':
								var item='<span class="input"><input id="checkboxApp_'+callback.data[i].appid+'" name="data[package_ext][]" type="checkbox" autocomplete="off" value="'+callback.data[i].appid+'" rel="" /></span><span class="text"><label for="checkboxApp_'+callback.data[i].appid+'">'+callback.data[i].name+' <span class="grey">(<strong class="orange price">'+callback.data[i].price+'</strong>元/年)</span></label></span>';
								break;
						}
						_html+='<li class="clearfix">'+item+'</li>';
					}
					if(callback.suit_price_remain) {
						$('#textAmount').text(callback.suit_price_remain);
						$('#countPackage').html('<strong class="choice">'+_package+'</strong> 升级所需费用：<strong id="costPackage" class="orange">'+callback.suit_price_remain+'</strong>元');
					}
					$('#fieldApplication').html(_html);
					$('#fieldApplication input').click(appChange);
					$('#countApp').html('<span class="choice grey">请选择拓展功能</span>');
				}
			}
		});
	});
	
	//购买域名/模板/应用等产品
	//购买应用选择购买年限
	$('#apporderLimit').blur(function(){
		var regNumber=/^\+?[1-9][0-9]*$/;
		if (!regNumber.test($(this).val())){
			dialogError('购买年限必须是正整数');
			var this1=$(this);
			$('#confirm_dialogError').click(function(){
				$('#dialogError').fadeTo('slow', 0, function(){
					$(this).remove();
				});
				$('#jquery_addmask').fadeTo('slow', 0, function(){
					$(this).remove();
				});
				this1.val('1').focus();
			});
		} else {
			$('#textAmount span').text((Number($(this).val()))*(Number($('#appPrice').text())*100)/100);	
		}
	});
	//选择网站：模板与应用购买
	var loadSitelist=function(url){
		$.ajax({
			url: url,
			dataType: 'json',
			cache: false,
			success: function(callback){
				if (callback.status=='failed'){
					dialogError(callback.msg, 'removeAll');
				}
				if (callback.status=='success'){
					var _html='';
					for (var i=0;i<callback.data.length;i++){
						if (callback.data[i].free){
							_html+='<li class="clearfix" rel="'+callback.data[i].siteid+'" rev="yes"><div class="sitename">'+callback.data[i].name+'</div><div class="info"><span class="grey">还可获赠 <span class="orange">'+callback.data[i].free+'</span> 套</span></div></li>';
						} else if (callback.data[i].ends) {
							_html+='<li class="clearfix" rel="'+callback.data[i].siteid+'" rev="no"><div class="sitename">'+callback.data[i].name+'</div><div class="info"><span class="grey">到期时间：</span><span class="text-ends">'+callback.data[i].ends+'</span></div></li>';
						} else {
							_html+='<li class="clearfix" rel="'+callback.data[i].siteid+'" rev="no"><div class="sitename">'+callback.data[i].name+'</div></li>';
						}
					}
					$('#dialog1_container ul.list-site').html(_html);
					$('#dialog1_container ul.list-site li').hover(function(){
						$(this).addClass('hover');
					}, function(){
						$(this).removeClass('hover');
					});
					$('#dialog1_container ul.list-site li').click(function(){
						var sitename=$(this).find('div.sitename').text();
						var siteid=$(this).attr('rel');
						$('#inputSiteid').attr('value', siteid);
						$('#textSitename').text(sitename);
						if ($(this).attr('rev')=='yes') {
							$('#textAmount').text('随套餐免费赠送，无须额外付费');
							$('#containerSubmit input').val('确定');
						} else if ($('#textAmount').attr('rel')!=''&&$('#textAmount').attr('rel')!=null){
							$('#textAmount').text($('#textAmount').attr('rel')+' 元');
							$('#containerSubmit input').val('购买');
						}
						$('#dialog1').fadeTo('slow', 0, function(){
							$(this).remove();
						});
						$('#jquery_addmask').fadeTo('slow', 0, function(){
							$(this).remove();
						});
						$('#apporderLimit').blur();
					});
				}
			}
		});
	}
	
	//赠送域名： 选择网站
	$('#freedomain-choose').click(function(){
		dialog1('以下网站套餐等您领取赠送域名！', 450, 600, 'no', '取消');
		$('#dialog1 p.dialog-closer').html('<a id="dialog1_shut" href="#" title="关闭">关闭</a>');
		$('#dialog1_shut').click(function(){
			$('#jquery_addmask').fadeTo('slow', 0, function(){
				$(this).remove();
			});
			$('#dialog1').fadeTo('slow', 0, function(){
				$(this).remove();
			});
			$('.formError').remove();
			return false;
		});
		$('#dialog1_container').html('<div class="datalist-header"><div class="text">选择网站套餐：</div><form action="/member/domains/selectwebsite/"><input id="keywordsSitechange" class="keywords" type="text" value="请输入网站名称" /><input class="submit" type="submit" value="" /></form></div><ul class="datalist list-site"></ul><div class="box-msg"><div class="inner"><p>赠送域名的注册年限将与套餐的购买使用年限一致；</p><p>域名注册成功后，将默认解析到您选择的套餐网站。</p></div></div>');
		var url=$(this).attr('rel');
		loadSitelistforDomain(url);
		$('#keywordsSitechange').focus(function(){
			if ($(this).val()=='请输入网站名称') $(this).val('');
		});
		$('#keywordsSitechange').blur(function(){
			if ($(this).val()==''||$(this).val()==null) $(this).val('请输入网站名称');
		});
		$('#dialog1_container form').submit(function(){
			var keywords=$('#keywordsSitechange').val();
			var url=$(this).attr('action')+keywords;
			loadSitelistforDomain(url);
			return false;
		});
		return false;
	});
	
	//未激活腾讯邮箱
	$('#exmail-choose').click(function(){
		dialog1('以下邮局等你激活！', 450, 600, 'no', '取消');
		$('#dialog1 p.dialog-closer').html('<a id="dialog1_shut" href="#" title="关闭">关闭</a>');
		$('#dialog1_shut').click(function(){
			$('#jquery_addmask').fadeTo('slow', 0, function(){
				$(this).remove();
			});
			$('#dialog1').fadeTo('slow', 0, function(){
				$(this).remove();
			});
			$('.formError').remove();
			return false;
		});
		$('#dialog1_container').html('<div class="datalist-header"><div class="text">选择邮局：</div></div><ul class="datalist list-site"></ul><div class="box-msg"><div class="inner"><p>购买的邮箱用户数越多，单价将越便宜；</p><p>激活成功后，可登入腾讯企业邮箱进行管理。</p></div></div>');
		var url=$(this).attr('rel');
		getexmail(url);
		return false;
	});
	
	//选择邮箱：激活
	var getexmail=function(url){
		$.ajax({
			url: url,
			dataType: 'json',
			cache: false,
			success: function(callback){
				if (callback.status=='failed'){
					dialogError(callback.msg, 'removeAll');
				}
				if (callback.status=='success'){
					var _html='';
					for (var i=0;i<callback.data.length;i++){
						_html+='<li class="clearfix"><div class="sitename">邮箱用户数'+callback.data[i].mail_nums+' ( <span class="red">'+callback.data[i].buy_years+'</span> 年)</div><div class="info"><a class="freeexmail-active" href="/member/exmails/activation/'+callback.data[i].exmail_id+'">激活</a></span></div></li>';
					}
					$('#dialog1_container ul.list-site').html(_html);
					$('#dialog1_container ul.list-site li').hover(function(){
						$(this).addClass('hover');
					}, function(){
						$(this).removeClass('hover');
					});
				}
			}
		});
	}
	//获取价格
	$('#selectprice').change(function(){
		 var year = $('#selectprice').val();
		 var nums = $('#buynums').val();
		 $.ajax({
				url: '/member/exmails/getprice/'+year+'/'+nums,
				dataType: 'json',
				cache: false,
				success: function(callback){
					if(callback.status=='failed'){
						dialogError(callback.msg,'removeAll');
					}
					if(callback.status=='success'){
						$('#pay').text(callback.data);
					}
				}
			});
	});
	
	//选择网站：域名购买
	var loadSitelistforDomain=function(url){
		$.ajax({
			url: url,
			dataType: 'json',
			cache: false,
			success: function(callback){
				if (callback.status=='failed'){
					dialogError(callback.msg, 'removeAll');
				}
				if (callback.status=='success'){
					var _html='';
					var _url=$('#freedomain-choose').next().attr('href');
					for (var i=0;i<callback.data.length;i++){
						_html+='<li class="clearfix" rel="'+callback.data[i].siteid+'" rev="'+callback.data[i].years+'"><div class="sitename">'+callback.data[i].name+' ( <span class="red">'+callback.data[i].years+'</span> 年)</div><div class="info"><span class="grey">还可获赠域名：<span class="green">'+callback.data[i].nums+'</span> <a class="freedomain-get" href="'+_url+'/'+callback.data[i].siteid+'">领取</a></span></div></li>';
					}
					$('#dialog1_container ul.list-site').html(_html);
					$('#dialog1_container ul.list-site li').hover(function(){
						$(this).addClass('hover');
					}, function(){
						$(this).removeClass('hover');
					});
				}
			}
		});
	}
	//选择网站按钮
	$('#site-buttonSiteChange').click(function(){
		dialog1('选择网站', 352, 462, 'no', '取消');
		$('#dialog1 p.dialog-closer').html('<a id="dialog1_shut" href="#" title="关闭">关闭</a>');
		$('#dialog1_shut').click(function(){
			$('#jquery_addmask').fadeTo('slow', 0, function(){
				$(this).remove();
			});
			$('#dialog1').fadeTo('slow', 0, function(){
				$(this).remove();
			});
			$('.formError').remove();
			return false;
		});
		var url=$(this).attr('rel');
		var textTip='';
		var formAction='';
		if ($(this).is('.forapp')){
			textTip='将应用添加到：';
			var formAction='/member/appstore/selectwebsite/';
		}
		if ($(this).is('.fortpl')){
			textTip='将模板添加到：';
			formAction='/member/templates/selectwebsite/';
		}
		$('#dialog1_container').html('<div class="datalist-header"><div class="text">'+textTip+'</div><form action="'+formAction+'"><input id="keywordsSitechange" class="keywords" type="text" value="请输入网站名称" /><input class="submit" type="submit" value="" /></form></div><ul class="datalist list-site"></ul>');
		loadSitelist(url);
		$('#keywordsSitechange').focus(function(){
			if ($(this).val()=='请输入网站名称') $(this).val('');
		});
		$('#keywordsSitechange').blur(function(){
			if ($(this).val()==''||$(this).val()==null) $(this).val('请输入网站名称');
		});
		$('#dialog1_container form').submit(function(){
			var keywords=$('#keywordsSitechange').val();
			var url=$(this).attr('action')+keywords;
			loadSitelist(url);
			return false;
		});
		return false;
	});
	
	//域名绑定
	$('#site-domain-own').click(function(){
		$('#site-domain-own-container').show();
		$('#site-domain-reg-container').hide();
	});
	$('#site-domain-reg').click(function(){
		$('#site-domain-reg-container').show();
		$('#site-domain-own-container').hide();
	});
	
	
	/*
	
	//鼠标经过样式
	var hoverOver=function(){
		$(this).addClass('hover');
	}
	var hoverLeave=function(){
		$(this).removeClass('hover');
	}
	$('#listDomain li').hover(hoverOver, hoverLeave);
	
	*/
	
	//解除绑定
	var domainUnbind=function(){
		dialogWarning('确定要解除绑定吗？');
		var url=$(this).attr('href');
		$('#confirm_dialogWarning').click(function(){
			$('#cancel_dialogWarning').click();
			$.ajax({
				dataType: 'json',
				url: url,
				cache: false,
				error: function(msg, s){
					dialogError('与服务器通信失败，请重试或联系管理员。返回状态：'+s, 'removeThis');
					return false;
				},
				success: function(data, s){
					if (data.status=='failed'){
						dialogError(data.msg, 'removeThis');
					} else if (data.status=='success'){
						window.location.reload();
					}
				}
			});				
		});
		return false;
	}
	$('#listDomain a.link-unbind').click(domainUnbind);
	
	//搜索域名表单样式
	$('#inputDomainname').focus(function(){
		$(this).parent().parent().addClass('focus');
		$(this).blur(function(){
			$(this).parent().parent().removeClass('focus');
		});
	});
	//搜索域名查询结果
	$('#formDomainSearch').submit(function(){
		var domainname=$(this).find('input[name="domainname"]').val();
		if (domainname==null||domainname==''){
			alert('请输入您要注册的域名');
			return false;
		}
		var regDomainname=/[a-zA-Z0-9][-a-zA-Z0-9]{0,62}/;
		if (!regDomainname.test(domainname)){
			alert('您只能输入字母、数字或减号，并且不能以减号开头。');
			return false;
		}
		var listType=$(this).find('input[name="domaintype"]:checked');
		if (listType.length<1){
			alert('请至少选择一个域名后缀来查询');
			return false;
		}
		var domainType=[];
		for (var i=0;i<listType.length;i++){
			domainType[i]=listType.eq(i).val();
		}
		if (!document.getElementById('viewDomainResult')){
			$(this).after('<div id="viewDomainResult" class="box-domain-show"><h2>域名搜索结果：</h2><ul class="list"><li class="loading">正在提交查询，请稍候...</li></div>');
			$('#viewDomainResult').show('normal');
		} else {
			$('#viewDomainResult ul').append('<li class="loading">正在提交查询，请稍候...</li>');
		}
		url = $(this).attr('action');
		$.ajax({
			type: 'POST',
			url: url,
			data: 'domain='+domainname+'&tld='+domainType,
			dataType: 'json',
			cache: false,
			error: function(){
				$('#viewDomainResult li.loading').eq(0).removeClass().addClass('error').text('查询不成功');
			},
			success: function(callback){
				if (callback.status=='failed'){
					$('#viewDomainResult li.loading').eq(0).removeClass().addClass('error').text(callback.msg);
				}
				if (callback.status=='success'){
					$('#viewDomainResult li.loading').eq(0).remove();
					var _html='';
					for (var i=0;i<callback.data.length;i++){
						var result = false;
						$('#viewDomainResult').find('span').each(function(){
							if($(this).attr('id') == callback.data[i].name){
								if (callback.data[i].stat=='已注册'){
									$(this).text(callback.data[i].cat+' '+callback.data[i].name);
									$(this).next('span').text('已注册');
									$(this).next('span').attr('class','orange');
								}
								if (callback.data[i].stat=='未注册'){
									$(this).text(callback.data[i].cat+' '+callback.data[i].name);
									$(this).next('span').text('未注册');
									$(this).next('span').attr('class','green');
								}
								result = true;
							}
						})
						if(result){
							continue;
						}
						if (callback.data[i].stat=='已注册'){
							_html+='<li><span class="info" id='+callback.data[i].name+'>'+callback.data[i].cat+' '+callback.data[i].name+'</span><p style="float: left; margin: 9px 0px 0px;font-size:14px;">&nbsp;&nbsp;(<span class="orange">已注册</span>)</p> <a href="'+callback.data[i].url+callback.data[i].name+'" target="_blank" class="btnwrap btn-mgs-round"><span class="inner"><span class="btn">查看信息</span></span></a></li>';
						}
						if (callback.data[i].stat=='未注册'){
							_html+='<li><span class="info" id='+callback.data[i].name+'>'+callback.data[i].cat+' '+callback.data[i].name+'</span><p style="float: left; margin: 9px 0px 0px;font-size:14px;">&nbsp;&nbsp;(<span class="green">未注册</span>)</p> <a href="'+callback.data[i].url+callback.data[i].name+'/'+callback.data[i].tld+'" target="_blank" class="btnwrap btn-mos-round"><span class="inner"><span class="btn">立即注册</span></span></a></li>';
						}
					}
					$('#viewDomainResult ul').append(_html);
					$('#viewDomainResult li').unbind('hover').hover(function(){
						$(this).addClass('hover');
					}, function(){
						$(this).removeClass('hover');
					});
				}
			}
		});
		return false;
	});
	
	//提交备案资料
	var icpinfoSubmit=function(){
		dialog1('请选择操作', 252, 462);
		var thedomain=$(this).attr('rel');
		$('#dialog1_container').css('padding', '0').html('<div class="dialog-sitedomain-tips"><div class="message"><p>注意：贵州、黑龙江、甘肃、山东、新疆、天津（仅企业站）、陕西（仅企业站）、暂不受理备案。 如有疑问，请联系客服。</p></div></div><ul class="dialog-sitedomain-icptype"><li><a class="newicp" href="/member/icps/add/?domain='+thedomain+'"><span class="type">新增ICP备案</span><span class="des">该域名未备案，及个人或单位未在工信部备案过任何网站</span></a></li><li><a class="newsite" href="/member/icps/add2/?domain='+thedomain+'"><span class="type">新增备案网站</span><span class="des">该域名未备案，但个人或单位已在工信部备案过</span></a></li><li><a class="changeisp" href="/member/icps/add5/?domain='+thedomain+'"><span class="type">变更接入商</span><span class="des">该域名已备案，现转入我司接入申请</span></a></li><li class="last"><a class="confirm" href="/member/icps/add6/?domain='+thedomain+'"><span class="type">已备案提交</span><span class="des">该域名已备案，提交我司审核</span></a></li></ul>');
		if($(this).attr('j_role')=='vip'){
			$('#dialog1_container').find('div.message').html('<p>注意：黑龙江、甘肃、贵州、山东、新疆地区暂不能提交备案。如有疑问，请联系客服。</p>');
		}
		$('#dialog1_buttons').html('<span class="buttonwrap"><span class="inner"><input type="button" class="button" value="关闭" /></span></span>');
		$('#dialog1_buttons input').unbind('click').click(function(){
			$('#dialog1_shut').click();
		});
		return false;
	}
	$('#listDomain a.link-icp,#listWebsites a.link-icp,#add-s-icp,#add-b-icp').click(icpinfoSubmit);
	
	//添加域名
	$('#buttonDomainbind').click(function(){
		//if ($(this).attr('rel')=='loading') return false;
		var theForm=$(this).parents('div.form');
		var domainInput=theForm.find('input.text');
		var domainName=domainInput.val();
		if (domainName==''||domainName==null){
			dialogError('请输入域名', 'removeThis');
			return false;
		}
		var regDomain=/([0-9a-z\.])*[a-z0-9]+\.([a-z]){2,4}/i;
		if (!regDomain.test(domainName)){
			dialogError('请输入正确的域名格式，不包括http://和斜杠，不包括子目录的路径', 'removeThis');
			return false;
		}
		if(domainName.indexOf(":")!='-1' || domainName.indexOf("http://")!='-1'  || domainName.indexOf("/")!='-1' ){
			dialogError('请输入正确的域名格式，不包括http://和斜杠，不包括子目录的路径', 'removeThis');
			return false;			
		}
		$(this).attr('rel', 'loading');
		var row=$(this).parent().parent();
		var tips=row.find('div.tips');
		row.find('blockquote').remove();
		domainInput.attr('disabled', true);
		tips.hide().after('<blockquote class="loading">正在绑定...</blockquote>');
		var blockquote=row.find('blockquote');
		var thisLink=$(this);
		$.ajax({
			type: 'post',
			url: $(this).attr('href'),
			data: 'data[domain]='+domainName+'&data[WebsiteID]='+$(this).attr('rev'),
			dataType: 'json',
			cache: false,
			error: function(){
				blockquote.removeClass().addClass('error').text('连接失败');
				thisLink.attr('rel', '');
				domainInput.attr('disabled', false);
			},
			success: function(data){
				if (data.status=='failed'){
					blockquote.removeClass().addClass('error').text(data.msg);
					thisLink.attr('rel', '');
					domainInput.attr('disabled', false);
					return false;
				}
				if (data.status=='success'){
					thisLink.attr('rel', '');
					domainInput.attr({'disabled': false, 'value': ''});
					if (data.msg!='域名绑定数量已达到限额'){
						var msg=(data.msg+'，你可以<a href="#">注册新域名</a>。');
					}
					blockquote.remove();
					tips.show().html(msg);
					if (data.registration=='313')
						var linkAdmin=' <span>|</span> <a href="panel-domain-dns.php?id='+data.id+'">管理</a>';
					else
						var linkAdmin='';
					var p_domain='<p class="domain">'+data.domain+linkAdmin+' </p>';
					switch (data.icp_status){
						case '审核中':
							var p_icpOperate='<p class="icp-operate">备案资料已提交 <a href="/member/icps/add3/'+data.icp_id+'">查看备案流程</a></p>';
							break;
						case '已备案':
							var p_icpOperate='<p class="icp-operate">'+data.icp+'</p>';
							break;
						case '备案未通过':
							var p_icpOperate='<p class="icp-operate"><a href="/member/icps/add3/'+data.icp_id+'">查看原因</a></p>';
							break;
						case '未备案':
							var p_icpOperate='<p class="icp-operate"><a class="btnwrap btn-mos-oval link-icp" href="/member/icps/add" rel="'+data.domain+'&uid='+data.ownerid+'"><span class="inner"><span class="btn">提交备案资料</span></span></a></p>';
							break;
						default:
							var p_icpOperate='';
					}
					var _html='<li>'+p_domain+'<p class="icp-stat"><span class="'+data.icp_type+'">'+data.icp_status+'</span></p>'+p_icpOperate+'<p class="unbind"><a class="btnwrap btn-mos-oval link-unbind" href="/member/websites/domainunbind/'+data.id+'/'+data.websiteid+'"><span class="inner"><span class="btn">解除绑定</span></span></a></p></li>';
					if (!document.getElementById('listDomain')) theForm.after('<ul id="listDomain" class="domain-list"></ul>');
					$('#listDomain').prepend(_html);
					$('#listDomain li').eq(0).find('a.link-unbind').click(domainUnbind);
					$('#listDomain a.link-icp').unbind('click').click(icpinfoSubmit);
				}
			}
		});
		return false;
	});
	
	
	//选择模板
	$('#listTheme a.choose').click(function(){
		dialog1('模板应用语言选择', 196, 250);
		var source=$(this).attr('rel');
		$.ajax({
			url: source,
			cache: false,
			error: function(){
				dialogError('连接失败，请重试', 'removeAll');
			},
			success: function(callback){
				$('#dialog1_container').html(callback);
				$('#dialog1_container form').submit(function(){
					if($(this).find('input.language:checked').length<1){
						dialogError('请选择至少一个语言版本', 'removeSelf');
						return false;
					}
				});
			}
		});
		return false;
	});
	
	//购买套餐
	$('#formPackageorder').submit(function(){
		var nameOriginal=$('#websitename').val();
		if (nameOriginal.length<5){
			dialogError('网站名称必须5个字以上', 'removeThis');
			return false;
		}
	});

	//分销商平台域名添加
	$('#buttonDomainadd').click(function(){
		if ($(this).attr('rel')=='loading') return false;
		var theForm=$(this).parents('div.form');
		var domainInput=theForm.find('input.text');
		var domainName=domainInput.val();
		if (domainName==''||domainName==null){
			dialogError('请输入域名', 'removeThis');
			return false;
		}
		var regDomain=/([0-9a-z\.])*[a-z0-9]+\.([a-z]){2,}/i;
		if (!regDomain.test(domainName)){
			dialogError('请输入正确的域名格式，不包括http://和斜杠，不包括子目录的路径', 'removeThis');
			return false;
		}
		$(this).attr('rel', 'loading');
		var row=$(this).parent().parent();
		var tips=row.find('div.tips');
		row.find('blockquote').remove();
		domainInput.attr('disabled', true);
		tips.hide().after('<blockquote class="loading">正在绑定...</blockquote>');
		var blockquote=row.find('blockquote');
		var thisLink=$(this);
		$.ajax({
			type: 'post',
			url: $(this).attr('href'),
			data: 'data[domain]='+domainName,
			dataType: 'json',
			cache: false,
			error: function(){
				blockquote.removeClass().addClass('error').text('连接失败');
				thisLink.attr('rel', '');
				domainInput.attr('disabled', false);
			},
			success: function(data){
				if (data.status=='unbind' || data.status=='limited' || data.status=='binded' || data.status=='exist' || data.status=='unformat'){
					blockquote.removeClass().addClass('error').text(data.msg);
					thisLink.attr('rel', '');
					domainInput.attr('disabled', false);
					return false;
				}else {
					thisLink.attr('rel', '');
					domainInput.attr({'disabled': false, 'value': ''});
					
					var msg=(data.msg+'你可以<a href="/domains/checkdomain">注册新域名</a>。');
					
					blockquote.remove();
					tips.show().html(msg);
					if (data.status=='unsubmit'){
						var _html='<li class=""><p class="domain">'+data.domain+' </p><p class="icp-stat"><span class="warning">未提交</span></p><p class="icp-operate"><a class="btnwrap btn-mos-oval link-icp" href="/member/icps/add" rel="'+data.domain+'"><span class="inner"><span class="btn">提交备案资料</span></span></a></p><p class="unbind"><a class="btnwrap btn-mos-oval link-unbind" href="/member/customers/domain_del/'+data.domain+'"><span class="inner"><span class="btn">解除绑定</span></span></a></p></li>';
					}else if(data.status=='no'){
						var _html='<li class=""><p class="domain">'+data.domain+' </p><p class="icp-stat"><span class="error">未通过</span></p><p class="icp-operate"><a href="/member/icps/add3/'+data.domain+'">查看原因</a></p><p class="unbind"><a class="btnwrap btn-mos-oval link-unbind" href="/member/customers/domain_del/'+data.domain+'"><span class="inner"><span class="btn">解除绑定</span></span></a></p></li>';
					}else if(data.status=='submitted'){
						var _html='<li class=""><p class="domain">'+data.domain+' </p><p class="icp-stat"><span class="warning">审核中</span></p><p class="icp-operate">备案资料已提交&nbsp;&nbsp;&nbsp;<a href="/member/icps/add3/'+data.domain+'">查看备案流程</a></p><p class="unbind"><a class="btnwrap btn-mos-oval link-unbind" href="/member/customers/domain_del/'+data.domain+'"><span class="inner"><span class="btn">解除绑定</span></span></a></p></li>';
					}else if(data.status=='success'){
						var _html='<li class=""><p class="domain"><a href="http://'+data.domain+'" target="_blank" >'+data.domain+'</a> </p><p class="icp-stat"><span class="success">已通过</span></p><p class="icp-operate">'+data.icp+'&nbsp;&nbsp;&nbsp;<a href="/member/icps/add3/'+data.domain+'">查看备案详情</a></p><p class="unbind"><a class="btnwrap btn-mos-oval link-unbind" href="/member/customers/domain_del/'+data.domain+'"><span class="inner"><span class="btn">解除绑定</span></span></a></p></li>';
					}
					$('#listDomain').prepend(_html);
					$('#listDomain li').eq(0).find('a.link-unbind').click(domainUnbind);
					$('#listDomain a.link-icp,#listWebsites a.link-icp').unbind('click').click(icpinfoSubmit);
				}
			}
		});
		return false;
	});
	
	//域名购买：选择购买年限
	$('#selectPeriod').change(function(){
		$('#textAmount').text($(this).find('option:selected').attr('rel'));
		$('#amount').attr('value', $(this).find('option:selected').attr('rel'));
	});
	//域名信息表单验证
	$('#formDomainReg,#formWhoisModify').submit(function(){
		if (document.getElementById('dialogError')) return false;
		if ($(this).find('blockquote.error').length>0) return false;
		$(this).ajaxSubmit({
			type: 'post',
			dataType: 'json',
			cache: false,
			error: function(){
				dialogError('连接失败，请重试！', 'removeThis');
			},
			success: function(callback){
				if (callback.status=='failed'){
					dialogError(callback.msg, 'removeThis');
				}
				if (callback.status=='success'){
					if (callback.msg){
						dialogSuccess(callback.msg);
						$('#confirm_dialogSuccess').click(function(){
							location.href=callback.url;
						});
					} else {				
						location.href=callback.url;
					}
				}
			}
		});
		return false;
	});
	
	$('#formExmailReg').submit(function(){
		if (document.getElementById('dialogError')) return false;
		if ($(this).find('blockquote.error').length>0) return false;
		$(this).ajaxSubmit({
			type: 'post',
			dataType: 'json',
			cache: false,
			error: function(){
				dialogError('连接失败，请重试！', 'removeThis');
			},
			success: function(callback){
				if (callback.status=='failed'){
					dialogError(callback.msg, 'removeThis');
				}
				if (callback.status=='success'){
					if (callback.msg){
						dialogSuccess(callback.msg);
						$('#confirm_dialogSuccess').click(function(){
							location.href=callback.url;
						});
					} else {				
						location.href=callback.url;
					}
				}
			}
		});
		return false;
	});
	
	$('#formRegisterReg').submit(function(){
		if (document.getElementById('dialogError')) return false;
		if ($(this).find('blockquote.error').length>0) return false;
		$(this).ajaxSubmit({
			type: 'post',
			dataType: 'json',
			cache: false,
			error: function(){
				dialogError('连接失败，请重试！', 'removeThis');
			},
			success: function(callback){
				if (callback.status=='failed'){
					dialogError(callback.msg, 'removeThis');
				}
				if (callback.status=='success'){
					if (callback.msg){
						dialogSuccess(callback.msg);
						$('#confirm_dialogSuccess').click(function(){
							location.href=callback.url;
						});
					} else {				
						location.href=callback.url;
					}
				}
			}
		});
		return false;
	});
	
	//模板购买与套餐捆绑
	//选择套餐年限
	var limitTplPackage=function(){
		var costPackage=$(this).find('option:selected').attr('rel');
		$('#costPackage').text(costPackage);
		var amount=((Number(costPackage)*100)+(Number($('#costTpl').attr('rel')*100))/100);
		$('#textAmount').text(amount);
	}
	$('#tpl-limitChange').change(limitTplPackage);
	$('#tpl-fieldPackage input').click(function(){
		var dataList=$(this).attr('rel').split(';');
		var _html='';
		for (var i=0;i<dataList.length;i++){
			var dataGroup=dataList[i].split('|');
			if (i==0)
				_html+='<option selected="selected" value="'+dataGroup[0]+'" rel="'+dataGroup[1]+'">'+dataGroup[0]+'年：'+dataGroup[1]+'元</option>';
			else
				_html+='<option value="'+dataGroup[0]+'" rel="'+dataGroup[1]+'">'+dataGroup[0]+'年：'+dataGroup[1]+'元</option>';
		}
		$('#tpl-limitChange').html(_html).change();
	});
	
	
	/*
	 * panel profile
	 */
	//绑定手机号和邮箱
	$('#formBindPassport input').attr('autocomplete', 'off');
	var buttonBind=function(){
		var colContainer=$(this).parents('div.row');
		var thisButton=$(this);
		var theInput=colContainer.find('input.text');
		var bindType=$(this).attr('title');
		var user=$('#formBindPassport').attr('rel');
		var stat=$(this).attr('rel');
		/*
		if (stat==''||stat==null){
			dialogError('绑定前请先填写或修改', 'removeThis');
			return false;
		}
		*/
		/*
		if (stat=='binding'&&bindType=='手机号码绑定'){
			if (document.getElementById('dialog1')) return false;
			var title=$(this).attr('title');
			dialog1(title, 340, 442, '', '');
			var source=$(this).attr('href');
			var value=theInput.val();
			$.ajax({
				url: source,
				data: 'user='+user+'&mobile='+value,
				cache: false,
				error: function(){
					dialogError('连接失败，请重试！', 'removeAll');
				},
				success: function(callback){
					if (callback=='binded'){
						dialogError('这个手机号码已经绑定过啦', 'removeAll');
						return false;
					}else if (callback=='uninterval'){
						dialogError('手机短信验证码发送频率太快，请稍后再发！', 'removeAll');
						return false;
					}
					$('#dialog1_container').html(callback);
					var buttonResend=$('#formBinding input[name="resend"]');
					var buttonResendAllow=function(){
						var numNow=Number(buttonResend.attr('rel'));
						if (numNow<2){
							buttonResend.attr({
								'value': '重发短信验证码',
								'disabled': false,
								'rel': 0
							}).parent().parent().removeClass('button-grey-disabled');
						} else {
							numNow--;
							buttonResend.attr({
								'value': numNow+'秒后重新获取短信',
								'rel': numNow
							});
						}
					}
					buttonResend.everyTime('1s', buttonResendAllow);
					buttonResend.click(function(){
						$(this).attr('disabled', true).parent().parent().addClass('button-loading');
						$.ajax({
							url: $(this).attr('rev'),
							dataType: 'json',
							cache: false,
							error: function(){
								dialogError('发送失败，请重试', 'removeSelf');
								buttonResend.attr('disabled', false).parent().parent().removeClass('button-loading');
							},
							success: function(callback){
								var msgBox=$('#formBinding blockquote');
								if (callback.status=='success'){
									buttonResend.attr({
										'value': '60秒后重新获取短信',
										'disabled': true,
										'rel': 60
									}).parent().parent().removeClass('button-loading').addClass('button-grey-disabled');
									buttonResend.everyTime('1s', buttonResendAllow);
									msgBox.removeClass().text(callback.msg);
								} else if (callback.status=='failed'){
									msgBox.addClass('error').text(callback.msg);
									buttonResend.attr('disabled', false).parent().parent().removeClass('button-loading');
								} else {
									dialogError('发送失败，请重试', 'removeSelf');
									buttonResend.attr('disabled', false).parent().parent().removeClass('button-loading');
								}
								
							}
						});
					});
					$('#formBinding').submit(function(){
						var smsValidate=$(this).find('input.text').val();
						var msgBox=$('#formBinding blockquote');
						if (smsValidate==''||smsValidate==null){
							msgBox.addClass('error').text('请先输入短信验证码');
							return false;
						}
						var regSms=/^[1-9]\d{5}$/;
						if (!regSms.test(smsValidate)){
							msgBox.addClass('error').text('验证码是6位纯数字哦，请你仔细核对输入是否正确');
							return false;
						}
						var source=$(this).attr('action');
						var user2=$(this).find('input[name="data[username]"]').val();
						var mobile2=$(this).find('input[name="data[mobilenumber]"]').val();
						var smsValidate2=$(this).find('input[name="data[smsvalidate]"]').val();
						$.ajax({
							type: 'post',
							url: source,
							data: 'data[username]='+user2+'&data[smsvalidate]='+smsValidate2+'&data[mobilenumber]='+mobile2,
							dataType: 'json',
							cache: false,
							error: function(){
								dialogError('连接失败，请重试', 'removeSelf');
							},
							success: function(callback){
								if (callback.status=='success'){
									$('#dialog1_shut').click();
									dialogSuccess('手机号码：'+callback.msg+' 绑定成功！', 'removeAll');
									thisButton.parents('div.row').html('<div class="label"><label>手机号码：</label></div><div class="content"><strong class="blue" style="margin:0 0.3em 0 0;">'+callback.msg+'</strong><span class="grey">(已绑定)</span></div><span class="button-bind"><a class="modify-mobile" href="#">更改绑定号码</a></span><span class="tips">更改绑定号码后，将采用新号码登录</span>');
									colContainer.find('a.modify-mobile').click(bindModify);
								} else if (callback.status=='failed'){
									dialogError(callback.msg, 'removeSelf');
								} else {
									dialogError('连接失败，请重试', 'removeSelf');
								}
							}
						});
						return false;
					});
				}
			});
		}
		*/
		if (stat=='binding'&&bindType=='电子邮箱绑定'){
			var value=theInput.val();
			if (value==''||value==null){
				dialogError('请先填写您的邮箱地址', 'removeThis');
				return false;
			}
			var regEmail=/^[A-Za-z0-9]+([._\-\+]*[A-Za-z0-9]+)*@([A-Za-z0-9]+[-A-Za-z0-9]*[A-Za-z0-9]+\.)+[A-Za-z0-9]+$/;
			if (!regEmail.test(value)){
				dialogError('您输入的邮箱地址格式不对', 'removeThis');
				return false;
			}
			$.documentMask();
			$('body').append('<div id="loadingEmailBind" class="note-loading">正在载入...</div>');
			var arrayPageSize = getPageSize();
			var arrayPageScroll = getPageScroll();
			var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 26) / 2 + 'px';
			$('#loadingEmailBind').css('top', css_top).show();
			var source=$(this).attr('href');
			$.ajax({
				url: source,
				data: 'user='+user+'&email='+value,
				dataType: 'json',
				cache: false,
				error: function(){
					$('#loadingEmailBind').remove();
					dialogError('连接失败，请重试！', 'removeThis');
				},
				success: function(callback){
					$('#loadingEmailBind').remove();
					if (callback.status=='success'){
						$('#dialog1_shut').click();
						dialogSuccess('系统已经发送了一封校验邮件至 '+callback.msg+' ，请查收并根据提示激活', 'removeAll');
						thisButton.parents('div.row').html('<div class="label"><label>电子邮件：</label></div><div class="content"><strong class="blue" style="margin:0 0.3em 0 0;">'+callback.msg+'</strong><span class="red">(未激活)</span><input type="hidden" value="'+callback.msg+'" id="email" /></div><span class="btn-bind"><a class="btnwrap btn-mom modify-email" href="#" title="更改邮箱地址"><span class="inner"><span class="btn">更改邮箱地址</span></span></a></span><span class="btn-bind"><a class="btnwrap btn-mom email-resend" href="#" title="重发校验邮件"><span class="inner"><span class="btn">重发校验邮件</span></span></a></span>');
						colContainer.find('a.modify-email').click(bindModify);
						colContainer.find('a.email-resend').click(emailResend);
					} else if (callback.status=='failed'){
						dialogError(callback.msg, 'removeThis');
					} else {
						dialogError('连接失败，请重试', 'removeThis');
					}
				}
			});
		}
		return false;
	}
	$('#formBindPassport a.bind').click(buttonBind);
	//更改绑定
	var bindModify=function(){
		var colContainer=$(this).parents('div.row');
		var value=$(this).parent().prev().find('strong').text();
		if ($(this).text()=='更改绑定号码')
			var _html='<div class="label"><label>手机号码：</label></div><div class="enter"><input class="text bind" type="text" size="25" value="'+value+'" rec="//^0{0,1}(13[0-9]|15[7-9]|153|156|18[5-9])[0-9]{8}$//" /></div><span class="required">*</span><span class="btn-bind"><a class="btnwrap btn-mom bind" href="/member/users/mobileBinding/" title="手机号码绑定" rel="binding"><span class="inner"><span class="btn">绑定</span></span></a></span><span class="tips" title="可绑定移动/联通/电信11位手机号码，用于登录验证" rev="请输入正确的手机号码">绑定后可通过手机号码进行登录</span>';
		if ($(this).text()=='更改邮箱地址')
			var _html='<div class="label"><label>电子邮箱：</label></div><div class="enter"><input class="text bind" type="text" size="25" value="'+value+'" rec="//^\\w+((-\\w+)|(\\.\\w+))*\\@[A-Za-z0-9]+((\\.|-)[A-Za-z0-9]+)*\\.[A-Za-z0-9]+$//" /></div><span class="btn-bind"><a class="btnwrap btn-mom bind" href="/member/users/emailBinding/" title="电子邮箱绑定" rel="binding"><span class="inner"><span class="btn">绑定</span></span></a></span> <span class="btn-bind"><a class="btnwrap btn-mom cancel" href="/member/users/emailBinding/" title="取消绑定"><span class="inner"><span class="btn">取消</span></span></a></span><span class="tips" title="绑定后可同时使用邮箱或手机号码进行登录" rev="请输入正确的邮箱">绑定后可通过邮箱进行登录</span>';
		var _html2=colContainer.html();
		colContainer.html(_html);
		colContainer.find('a.bind').click(buttonBind);
		colContainer.find('a.cancel').click(function(){
			colContainer.html(_html2);
			colContainer.find('a.modify-email').click(bindModify);
			return false;
		});
		colContainer.find('input.text').focus(focusNormal);
		if (colContainer.is('div.required'))
			colContainer.find('input.text').blur(blurRequired);
		else
			colContainer.find('input.text').blur(blurNormal);
		return false;
	}
	$('#formBindPassport a.modify-mobile,#formBindPassport a.modify-email').click(bindModify);
	//重发邮件
	var emailResend=function(){
		$.documentMask();
		$('body').append('<div id="loadingEmailBind" class="note-loading">正在载入...</div>');
		var arrayPageSize = getPageSize();
		var arrayPageScroll = getPageScroll();
		var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 26) / 2 + 'px';
		$('#loadingEmailBind').css('top', css_top).show();
		$.ajax({
			url: '/member/users/emailBinding/',
			data: 'user='+$('#formBindPassport').attr('rel')+'&email='+$('#email').val(),
			dataType: 'json',
			cache: false,
			error: function(){
				$('#loadingEmailBind').remove();
				dialogError('连接失败，请重试！', 'removeThis');
			},
			success: function(callback){
				$('#loadingEmailBind').remove();
				if (callback.status=='success'){
					dialogSuccess('校验邮件已重发至 '+callback.msg+' ，请查收并根据提示激活', 'removeAll');
				} else if (callback.status=='failed'){
					dialogError(callback.msg, 'removeThis');
				} else {
					dialogError('连接失败，请重试', 'removeThis');
				}
			}
		});
		return false;
	}
	$('#formBindPassport a.email-resend').click(emailResend);
});

/*
 * panel payment
 */
$(document).ready(function() {
	var lastPayment = $(".lastPayment").val();
	if(lastPayment)
	$('#viewBankQuota').load('/member/finances/payment_quota/' + lastPayment);
}); 

$(function(){
	//银行图标的样式
	$('#listBanks label').hover(function(){
		$(this).addClass('hover');
	}, function(){
		$(this).removeClass('hover');
	});
	
	//显示银行限额
	$('#listBanks input').click(function(){
		var bankname=$(this).val();
		$.ajax({
			url: '/member/finances/payment_quota/'+bankname,
			cache: false,
			success: function(callback){
				if (!document.getElementById('viewBankQuota')) $('#listBanks').append('<div id="viewBankQuota" class="view-bank-quota"></div>');
				$('#viewBankQuota').html(callback);
			}
		});
	});
	//提交充值
	$('#formOnlinePay').submit(function(){
		if (document.getElementById('inputPayMoney')){
		var money=$('#inputPayMoney').val();
		if (money==''||money==null){
			dialogError('请输入充值金额！', 'removeThis');
			return false;
		}
		var regMoney=/^[0-9]*(\.[0-9]{1,2})?$/;
		if (!regMoney.test(money)){
			dialogError('请输入充值金额！', 'removeThis');
			return false;
		}
		}
		var bank=$('#listBanks input:checked');
		if (bank.length!=1){
			dialogError('请选择一个支付方式', 'removeThis');
			return false;
		}
		//var url=$(this).attr('action')+'?bank='+bank.val()+'&money='+money;
		//window.open(url);
		dialog1('支付提示', 342, 442, '', '已完成充值', '充值遇到问题');
		$.ajax({
			url: '/member/finances/payment_tips/' + bank.val()+'?money='+money,
			cache: false,
			error: function(){
				dialogError('连接失败，请重试', 'removeAll');
			},
			success: function(callback){
				$('#dialog1_container').html(callback);
				$('#dialog1_container a.return').click(function(){
					window.location.reload();
					return false;
				});
			}
		});
		$('#dialog1_buttons input').click(function(){
			if ($(this).val()=='已完成充值'){
				window.location.href='/member/finances/list';
			}
			if ($(this).val()=='充值遇到问题'){
				window.location.href='/info/contact';
			}
		});
		//return false;
	});
	//提交支付
	$('#formPayment').submit(function(){
		var url=$(this).attr('action');
		var returnurl = $('#returnback').val();
		var checkOverage=$('#checkOverage');
		var use_cops = 'no';
		if($("#radio-coupon-yes:checked").length!=0) use_cops = 'yes';
		var money=$('#textAmount').text();
		if (!document.getElementById('checkOverage')){
			var useoverage='no';
		} else if (checkOverage.is('.useoverage')){
			if (checkOverage.attr('checked')==true){
				var useoverage='yes';
			} else {
				var useoverage='no';
			}
		} else {
			if (checkOverage.attr('checked')==true){
				var useoverage='no';
			} else {
				var useoverage='yes';
			}
		}
		if (document.getElementById('listBanks') && money!='0'){
			var bank=$('#listBanks input:checked');
			if (bank.length!=1){
				dialogError('请选择一个支付方式', 'removeThis');
				return false;
			}
			var onlinepay=bank.val();
			//window.open(url+'&useoverage='+useoverage+'&onlinepay='+onlinepay+'&use_cops='+use_cops);
			dialog1('支付提示', 342, 442, '', '已完成充值', '充值遇到问题');
			$.ajax({
				url: '/member/finances/payment_tips/'+onlinepay+'?money='+money,
				cache: false,
				error: function(){
					dialogError('连接失败，请重试', 'removeAll');
				},
				success: function(callback){
					$('#dialog1_container').html(callback);
					$('#dialog1_container a.return').click(function(){
						window.location.reload();
						return false;
					});
				}
			});
			$('#dialog1_buttons input').click(function(){
				if ($(this).val()=='已完成充值'){
					if(returnurl) window.location.href=returnurl;
					else window.location.href='/member/finances/list';
				}
				if ($(this).val()=='充值遇到问题'){
					window.location.href='/info/contact';
				}
			});
		} else {
			//var onlinepay='no';
			//location.href=url+'&useoverage='+useoverage+'&onlinepay='+onlinepay+'&use_cops='+use_cops;
		}
		//return false;
	});
	
	//使用优惠券
	$('#radio-coupon-yes').click(function(){
		if (!document.getElementById('js-box-coupon-use')){
			$(this).parent().parent().after('<div id="js-box-coupon-use" class="row clearfix"><div class="label"><label>请输入优惠码：</label></div><div class="enter"><input class="text" type="text" size="22" name="data[memc_code]" maxlength="19" value="" /></div><span class="button-bind"><a id="js-btn-coupon-use" href="'+$(this).attr('rel')+'">使用</a></span><span class="tips">请输入优惠码</span></div>');
			$('#js-btn-coupon-use').click(function(){
				var coupon=$(this).parent().prev().find('input');
				if (coupon.val()==''||coupon.val==null){
					dialogError('请先输入优惠码！', 'removeThis');
					return false;
				}
				var tips=$(this).parent().next();
				var theRow=$(this).parent().parent();
				$.ajax({
					type: 'post',
					url: $(this).attr('href'),
					data: 'data[memc_code]='+coupon.val(),
					dataType: 'json',
					cache: false,
					error: function(){
						tips.hide();
						if (theRow.find('blockquote').length<1){
							theRow.append('<blockquote></blockquote>');
						}
						theRow.find('blockquote').removeClass().addClass('error').text('连接失败，请重试！');
					},
					success: function(data){
						tips.hide();
						if (theRow.find('blockquote').length<1){
							theRow.append('<blockquote></blockquote>');
						}
						var msgBox=theRow.find('blockquote');
						if (data.status=='failed'){
							msgBox.removeClass().addClass('error').text(data.msg);
						}
						if (data.status=='success'){
							tips.parent().html('<blockquote class="accepted"> '+data.msg+'，优惠码：'+data.coupon+'</blockquote>');
							$('#memc_code').val(data.coupon);
							if(Number($('#textAmount').attr('rel'))>Number(data.discount)) newmoney = Number($('#textAmount').attr('rel'))-Number(data.discount);
							else newmoney = '0';
							$('#textAmount').text(newmoney);
						}
					}
				});
				return false;
			});
		}
	});
	$('#radio-coupon-no').click(function(){
		$('#js-box-coupon-use').remove();
		//$('#textAmount').text($('#textAmount').attr('rel'));
		var memc_code = $('#memc_code').val();
		var tradeno = $(this).attr('rel');
		if(memc_code){
			$.ajax({
				type: 'post',
				url: '/member/paycenter/discoupons/'+tradeno,
				data: 'data[memc_code]='+memc_code,
				dataType: 'json',
				cache: false,
				error: function(){
					dialogError('连接失败，请重试！', 'removeThis');
				},
				success: function(data){
					if(data!=null){
					if (data.status=='failed'){
						dialogError('data.msg', 'removeThis');
					}
					if (data.status=='success'){
						$('#textAmount').text(Number($('#textAmount').attr('rel')));
						$('#memc_code').val('');
					}
					}
				}
			});	
		}
	});

});


/*
 * panel mobile
 */
$(function(){
	var arrayPageSize = getPageSize();
	var arrayPageScroll = getPageScroll();
	//更改绑定
	$('#button_MobileModify').click(function(){
		var colContainer=$(this).parents('div.row');
		var username = $('#username').val();
		var mobile = $('#textMobile').text();
		if ($(this).text()=='更改绑定号码')
			var _html='<div class="label"><label>手机号码：</label></div><div class="enter"><input id="username" type="hidden"  value="'+username+'"  /><input id="inputMobileBind" class="text" type="text" size="25" value="'+mobile+'" rec="//^0{0,1}(13[0-9]|14[0-9]|15[0-9]|18[0-9])[0-9]{8}$//" /></div><span class="btn-bind"><a id="buttonMobileBind" class="btnwrap btn-mom" href="/member/users/mobileBinding/" title="绑定手机号码"><span class="inner"><span class="btn">绑定</span></span></a></span><span class="tips"><span class="red">（未绑定）</span> 绑定后可通过手机号码进行登录</span>';
		colContainer.html(_html);
		colContainer.find('#buttonMobileBind').click(buttonMobileBind);
		return false;
	});
	
	//提交验证码
	var formSmsValidate=function(){
				if (document.getElementById('formBinding')){
					var buttonResend=$('#formBinding input[name="resend"]');
				} else {
					var buttonResend=$('#formMobileValidate input[name="resend"]');
				}
				var buttonResendAllow=function(){
					var numNow=Number(buttonResend.attr('rel'));
					if (numNow<2){
						buttonResend.attr({
							'value': '重发短信验证码',
							'disabled': false,
							'rel': 0
						}).parent().parent().removeClass('button-grey-disabled');
					} else {
						numNow--;
						buttonResend.attr({
							'value': numNow+'秒后重新获取短信',
							'rel': numNow
						});
					}
				}
				buttonResend.everyTime('1s', buttonResendAllow);
				buttonResend.click(function(){
					$(this).attr('disabled', true).parent().parent().addClass('button-loading');
					$.ajax({
						url: $(this).attr('rev'),
						dataType: 'json',
						cache: false,
						error: function(){
							dialogError('发送失败，请重试', 'removeSelf');
							buttonResend.attr('disabled', false).parent().parent().removeClass('button-loading');
						},
						success: function(callback){
							var msgBox=$('#formBinding blockquote');
							if (callback.status=='success'){
								buttonResend.attr({
									'value': '60秒后重新获取短信',
									'disabled': true,
									'rel': 60
								}).parent().parent().removeClass('button-loading').addClass('button-grey-disabled');
								buttonResend.everyTime('1s', buttonResendAllow);
								msgBox.removeClass().text(callback.msg);
							} else if (callback.status=='failed'){
								msgBox.addClass('error').text(callback.msg);
								buttonResend.attr('disabled', false).parent().parent().removeClass('button-loading');
							} else {
								dialogError('发送失败，请重试', 'removeSelf');
								buttonResend.attr('disabled', false).parent().parent().removeClass('button-loading');
							}
						}
					});
				});
				$('#formBinding').submit(function(){
					var msgBox=$(this).find('blockquote');
					var inputValidate=$(this).find('input.text');
					var source=$(this).attr('action');
					var user=$(this).find('input[name="data[username]"]').val();
					if (inputValidate.length==1){
						var smsValidate=inputValidate.val();
						if (smsValidate==''||smsValidate==null){
							msgBox.addClass('error').text('请先输入短信验证码');
							return false;
						}
						var regSms=/^[1-9]\d{5}$/;
						if (!regSms.test(smsValidate)){
							msgBox.addClass('error').text('验证码是6位纯数字哦，请你仔细核对输入是否正确');
							return false;
						}
						var mobile=$(this).find('input[name="data[mobilenumber]"]').val();
						var smsValidate=$(this).find('input[name="data[smsvalidate]"]').val();
						var dataParam='data[username]='+user+'&data[smsvalidate]='+smsValidate+'&data[mobilenumber]='+mobile;
					} else {
						var smsValidate1=inputValidate.eq(0).val();
						var smsValidate2=inputValidate.eq(1).val();
						if (smsValidate1==''||smsValidate1==null){
							msgBox.addClass('error').text('请输入原绑定手机收到的短信验证码');
							return false;
						}
						if (smsValidate2==''||smsValidate2==null){
							msgBox.addClass('error').text('请输入新绑定手机收到的短信验证码');
							return false;
						}
						var regSms=/^[1-9]\d{5}$/;
						if (!regSms.test(smsValidate1)||!regSms.test(smsValidate2)){
							msgBox.addClass('error').text('验证码是6位纯数字哦，请你仔细核对输入是否正确');
							return false;
						}
						var mobile1=$(this).find('input[name="data[mobilenumber1]"]').val();
						var smsValidate1=$(this).find('input[name="data[smsvalidate1]"]').val();
						var mobile2=$(this).find('input[name="data[mobilenumber2]"]').val();
						var smsValidate2=$(this).find('input[name="data[smsvalidate2]"]').val();
						var dataParam='data[username]='+user+'&data[oldsmsvalidate]='+smsValidate1+'&data[oldmobile]='+mobile1+'&data[newsmsvalidate]='+smsValidate2+'&data[newmobile]='+mobile2;
					}
					$('#dialog1').css('z-index',49);
					$('body').append('<div id="loadingBind" class="note-loading">正在验证...</div>');
					var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 26) / 2 + 'px';
					$('#loadingBind').css('top', css_top).show();
					$.ajax({
						type: 'post',
						url: source,
						data: dataParam,
						dataType: 'json',
						cache: false,
						error: function(){
							dialogError('连接失败，请重试', 'removeSelf');
							$('#loadingBind').remove();
						},
						success: function(callback){
							$('#loadingBind').remove();
							if (callback.status=='success'){
								$('#dialog1').remove();
								dialog1('操作提示', 340, 442, 'no', '返回');
								$('#dialog1_container').html('<div class="dialog-operatetip"><div class="status success">您已经成功绑定了手机</div><div class="note"><p>您已经成功绑定了手机号码为： <strong>'+callback.msg+'</strong></p><p>绑定手机后你可以随时更改绑定号码，或解除绑定。</p></div></div>');
								$('#confirm_dialog1').click(function(){
									$('#dialog1').remove();
									$('body').append('<div id="loadingRefresh" class="note-loading">正在跳转...</div>');
									var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 26) / 2 + 'px';
									$('#loadingRefresh').css('top', css_top).show();
									var directUrl=$('#returnurl').val();
									//var directUrl=$('#buttonMobileBind').attr('rel');
									if (directUrl==''||directUrl==null){
										window.location.reload();
									} else {
										window.location.href=directUrl;
									}
								});
							} else if (callback.status=='failed'){
								dialogError(callback.msg, 'removeSelf');
							} else {
								dialogError('连接失败，请重试', 'removeSelf');
							}
						}
					});
					return false;
				});
				$('#formMobileValidate').submit(function(){
					var msgBox=$(this).find('blockquote');
					var inputValidate=$(this).find('input.text');
					var source=$(this).attr('action');
					var user=$(this).find('input[name="data[username]"]').val();
					var smsValidate=inputValidate.val();
					if (smsValidate==''||smsValidate==null){
						msgBox.addClass('error').text('请先输入短信验证码');
						return false;
					}
					var regSms=/^[1-9]\d{5}$/;
					if (!regSms.test(smsValidate)){
						msgBox.addClass('error').text('验证码是6位纯数字哦，请你仔细核对输入是否正确');
						return false;
					}
					var mobile=$(this).find('input[name="data[mobilenumber]"]').val();
					var smsValidate=$(this).find('input[name="data[smsvalidate]"]').val();
					var dataParam='data[username]='+user+'&data[smsvalidate]='+smsValidate+'&data[mobilenumber]='+mobile;
					$('body').append('<div id="loadingSubmit" class="note-loading">正在提交...</div>');
					var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 26) / 2 + 'px';
					$('#dialog1').css('z-index', 49);
					$('#loadingSubmit').css('top', css_top).show();
					$.ajax({
						type: 'post',
						url: source,
						data: dataParam,
						dataType: 'json',
						cache: false,
						error: function(){
							dialogError('连接失败，请重试', 'removeSelf');
							$('#dialog1').css('z-index', 50);
							$('#loadingSubmit').remove();
						},
						success: function(callback){
							$('#loadingSubmit').remove();
							if (callback.status=='success'){
								$('#dialog1').remove();
								dialog1('操作提示', 340, 442, 'no', '继续');
								$('#dialog1_container').html('<div class="dialog-operatetip"><div class="status success">您已经成功通过二次鉴权</div><div class="note"><p>您已经成功通过二次鉴权</p><p><a href="#">点击此处继续</a></p></div></div>');
								$('#confirm_dialog1,#dialog1_container a').click(function(){
									$('#dialog1').remove();
									$('body').append('<div id="loadingRefresh" class="note-loading">正在跳转...</div>');
									var css_top=arrayPageScroll[1] + (arrayPageSize[3] - 35 - 26) / 2 + 'px';
									$('#loadingRefresh').css('top', css_top).show();
									var directUrl=$('#returnurl').val();
									//var directUrl=$('#buttonMobileBind').attr('rel');
									if (directUrl==''||directUrl==null){
										window.location.reload();
									} else {
										window.location.href=directUrl;
									}
									return false;
								});
							} else if (callback.status=='failed'){
								dialogError(callback.msg, 'removeSelf');
							} else {
								dialogError('连接失败，请重试', 'removeSelf');
							}
						}
					});
					return false;
				});
	}
	var buttonMobileBind = function(){
		var title=$(this).attr('title');
		if (title=='帐号二次鉴权'){
			var url=$(this).attr('href');
		} else {
			var mobile=$('#inputMobileBind').val();
			var user=$('#username').val();
			if (mobile==''||mobile==null){
				dialogError('请先填写手机号', 'removeThis');
				return false;
			}
			var regMobile=/^(1[3|5|8])[\d]{9}$/;
			if (!regMobile.test(mobile)){
				dialogError('你输入的手机号码好像不对哦^^', 'removeThis');
				return false;
			}
			var url=$(this).attr('href')+'?user='+user+'&mobile='+mobile;
		}
		if (document.getElementById('dialog1')) return false;
		dialog1(title, 340, 442, '', '');
		$.ajax({
			url: url,
			cache: false,
			error: function(){
				dialogError('连接失败，请重试', 'removeAll');
			},
			success: function(callback){
				if (callback=='binded'){
					dialogError('这个手机号码已经绑定过啦', 'removeAll');
					return false;
				} else if (callback=='uninterval'){
					dialogError('手机短信验证码发送频率太快，请稍后再发！', 'removeAll');
					return false;
				}
				$('#dialog1_container').html(callback);
				formSmsValidate();
			}
		});
		return false;
	} 
	$('#buttonMobileBind').click(buttonMobileBind);
	$('#buttonMobileModify').click(function(){
		if (document.getElementById('dialog1')) return false;
		var title=$(this).attr('title');
		dialog1(title, 340, 442, '', '');
		var url=$(this).attr('rel');
		var user=$(this).attr('rev');
		var mobile=$('#textMobile').text();
		$('#dialog1_container').html('<form class="form" action="'+url+'" method="post" style="margin-bottom:30px;"><input name="user" type="hidden" value="'+user+'" /><div class="row clearfix"><div class="label">当前绑定号码：</div><div class="content"><strong class="orange">'+mobile+'</strong></div></div><div class="row clearfix"><div class="label">新绑定号码：</div><div class="enter"><input class="text" name="newmobile" type="text" size="30" /></div></div></form><div class="block-helper"><p>请先暂时关闭手机的短信防火墙和过滤软件，以免收不到验证码。</p><p>提交后系统会向你提供的2个手机分别发送含验证码的手机短信</p><p>如您丢失原手机号码，请联系我们的客服人员，将协助你完成更改</p></div>');
		$('#dialog1_container form').submit(function(){
			var mobile=$(this).find('input[name="newmobile"]').val();
			if (mobile==''||mobile==null){
				dialogError('请先填写手机号', 'removeSelf');
				return false;
			}
			var regMobile=/^0{0,1}(13[0-9]|14[0-9]|15[0-9]|18[0-9])[0-9]{8}$/;
			if (!regMobile.test(mobile)){
				dialogError('你输入的手机号码好像不对哦^^', 'removeSelf');
				return false;
			}
			$.ajax({
				type: 'get',
				url: $(this).attr('action'),
				data: 'user='+$(this).find('input[name="user"]').val()+'&newmobile='+mobile,
				cache: false,
				error: function(){
					dialogError('连接失败，请重试', 'removeSelf');
					return false;
				},
				success: function(callback){
					if (callback=='binded'){
						dialogError('这个手机号码已经绑定过啦', 'removeAll');
						return false;
					} else if (callback=='uninterval'){
						dialogError('手机短信验证码发送频率太快，请稍后再发！', 'removeAll');
						return false;
					}
					$('#dialog1_container').html(callback);
					formSmsValidate();
				}
			});
			return false;
		});
		return false;
	});
});

/*=====================================
 * Product
 *=====================================*/
$(function(){	
	//应用续费的相关选项与价格变化
	(function(){
		if (!document.getElementById('textAmount')) return false;
		var _amount=$('#textAmount');
		var _price=Number(_amount.attr('j_price'));
		/*$('#selectRenew_domain').click(function(){
			
		});*/
		$("#selectRenew_domain").change(function()
		{
			if($('#selectRenew_domain option:selected').val()==2){
				$('#months input').val(1);
				$('#months').show();
				$('#appPriceMonth').show();
				$('#appPriceYear').hide();
				$('#appPriceMonthCus').show();
				$('#appPriceYearCus').hide();
			}else{
				$('#months input').val(1);
				$('#months').hide();
				$('#appPriceMonth').hide();
				$('#appPriceYear').show();
				$('#appPriceMonthCus').hide();
				$('#appPriceYearCus').show();
			}
		});
		$('#j-app-opt-limit a').click(function(){
			var _box=$(this).parent();
			var _list=_box.parent();
			var _input=_list.parents('tr').next();
			if (_box.is('.current')){
				_list.hide();
				return false;
			}
			var _unit=_box.attr('j_unit');
			if (_unit=='m'){
				_input.show().find('input').val(1);
				_amount.html(_price);
			} else {
				_input.hide();
				var _cost=_box.attr('j_cost').split('|');
				if (_cost.length==2){
					_amount.html('<span class="amount"><strong class="larger2">'+_cost[0]+'</strong> 元</span> <span class="greenarrow"><span class="inner">节省'+_cost[1]+'元</span></span>');
				}
			}
			_box.addClass('current').siblings().removeClass('current');
			_list.hide().prev().text($(this).text());
			$('#j-opt-limit a.current').removeClass('current').click();
			return false;
		});
		
		var numIpt=$('#months input');
		var numHandler=$('#j-app-opt-limit2 a');
		numIpt.keyup(function(){
			var _value=$(this).val();
			$(this).val(_value.replace(/[^0-9]/g,''));
			if (Number(_value)<1 || $.trim(_value)==''){
				$(this).val(1);
			} else if (Number(_value)>11){
				$(this).val(11);
			}
		}).blur(function(){
			var _value=Number($(this).val());
			 _amount.html(_price*_value);
		});
		numHandler.click(function(){
			var _value=Number(numIpt.val());
			if ($(this).is('.up')){
				_value++;
			} else {
				_value--;
			}
			if (_value<1) _value=1;
			if (_value>11) _value=11;
			numIpt.val(_value).blur();
		});
	})();
});



/*=====================================
 * ICP
 *=====================================*/
$(function(){	
	//应用续费的相关选项与价格变化
	(function(){
		if (document.getElementById('fields-corplicence')){
			$('#ipt-ipc-type-personal, #ipt-ipc-type-corp').click(function(){
				var theFields=$('#fields-corplicence,#fields-corplicence2,#fields-corplicence3');
				var theFieldsInfo=$('#fields-info');
				if ($(this).is('#ipt-ipc-type-personal')){
					$('#fields-corplicence3').show();
					theFields.hide();
					theFieldsInfo.hide();
					theFields.find('div.row').removeClass('required');
					theFieldsInfo.find('div.row').removeClass('required');
				}
				if ($(this).is('#ipt-ipc-type-corp')){
					$('#fields-corplicence3').hide();
					theFields.show();
					theFieldsInfo.show();
					theFields.find('div.row').addClass('required');
					theFields.find('div.ppic').removeClass('required');
					theFieldsInfo.find('div.row').addClass('required');
				}
			});
		}
		if (!document.getElementById('j-icp-down')) return false;
		$('#j-icp-down select.down-list').change(function(){
			var downUrl=$(this).find('option:selected').attr('j_url');
			var downBtn=$(this).next().find('a.btnwrap');
			var tipsWriting=$(this).parent().find('p.down-tips-writing');
			downBtn.attr('href',downUrl);	
			if( downUrl=='' ){
				downBtn.removeClass('btn-mgm').addClass('btn-disable-mgm');
				tipsWriting.hide();
			}
			else if( downUrl=='error' ){
				downBtn.removeClass('btn-mgm').addClass('btn-disable-mgm');
				tipsWriting.show();	
			}	
			else{
				downBtn.removeClass('btn-disable-mgm').addClass('btn-mgm');
				tipsWriting.hide();
			}		
		});
		$('#j-icp-down a.j-down-btn').click(function(){
			var downVal=$(this).attr('href');
			if( downVal=='' || downVal=='error' ){
				return false;
			}
		});
	})();
});



/*=====================================
 * Invoice
 *=====================================*/
$(function(){	
	//索取发票发票类型选择
	(function(){
		if ($('.close')){
			$('#invoice-1, #invoice-2').click(function(){
				var invoiceInfo=$('.close');
				if ($(this).is('#invoice-1')){
					invoiceInfo.hide();
					invoiceInfo.removeClass('required');
				}
				else if ($(this).is('#invoice-2')){
					invoiceInfo.show();
					invoiceInfo.addClass('required');
				}
			});
		}
	})();
});
function changePrice(){
	var year = $('#selectprice').val();
	 var nums = $('#buynums').val();
	 $.ajax({
			url: '/member/exmails/getprice/'+year+'/'+nums,
			dataType: 'json',
			cache: false,
			success: function(callback){
				if(callback.status=='failed'){
					dialogError(callback.msg,'removeAll');
				}
				if(callback.status=='success'){
					$('#pay').text(callback.data);
				}
			}
		});
	
}

/*=================
*mediav
*====================*/
$(function(){
	$('#buy').click(function(){
		check_icp();
	});
	
	function showTag(id){
		$('#jquery_addmask').next().remove();
		var tt = $('#'+id).clone(true);  
		tt.appendTo(document.body); 
		tt.css({left:($(window).width() - tt.outerWidth())/2, top:($(window).height() - tt.outerHeight())/2 + $(document).scrollTop()});
		tt.show();
		return tt;
	}
	
	function check_icp(){
		if(!document.getElementById('jquery_addmask')){
			$.documentMask('','true');
		   obj = $('#jquery_addmask');
		   obj.css('background','black');
		}
		tag = showTag('check_icp');
		tag.find('.p_close').click(function(){
			$('#jquery_addmask').remove();
			tag.remove();
			return false;
		});
		tag.find('#no_313').click(function(){
			tag.find('#error').text('');
			tag.find('.in_p').show();
		});
		tag.find('#is_313').click(function(){
			tag.find('#error').text('');
			tag.find('.in_p').hide();
		});
		tag.find('.bottou_p').click(function(){
			tag.find('#error').text('');
			if(!tag.find('#is_313').attr('checked') && !tag.find('#no_313').attr('checked')){
				tag.find('#error').text('请选择是否在313备案。');
				return false;
			}
			if(tag.find('#no_313').attr('checked')){
				if(tag.find('.in_p').val() == ''){
					tag.find('#error').text('请填写备案的域名。');
					return false;
				}
				go_icp(tag.find('.in_p').val(),'no');
			}else{
				$.ajax({
					url: '/member/mediav/geticp',
					dataType: 'json',
					cache: false,
					success: function(callback){
						if(callback.status=='failed'){
							tag = showTag('ajax_error');
							tag.find('.simsun_m').text(callback.msg);
							tag.find('.p_close').click(function(){
								$('#jquery_addmask').remove();
								tag.remove();
								return false;
							});
							return false;
						}
						var len = callback.length;
						var str = '';
						for(var i = 0;i < len;i++){
							var domain = callback[i].Icp.domain;
							str += '<li><input name="domain" type="radio" value="'+domain+'" />'+domain+'</li>'
						}
						tag = showTag('check_domain');
						tag.find('#domain_list').html(str);
						tag.find('.p_close').click(function(){
							$('#jquery_addmask').remove();
							tag.remove();
							return false;
						});
						tag.find(':radio[name="domain"]').click(function(){
							tag.find('#error').text('');
						});
						tag.find('.bottou_p').click(function(){
							tag.find('#error').text('');
							var domain = tag.find(':radio[name="domain"]:checked').val();
							if(domain == undefined){
								tag.find('#error').text('请填选择域名。');
								return false;
							}
							go_icp(domain,'yes');
						});
					},
					error:function(){
						tag = showTag('ajax_error');
						tag.find('.simsun_m').text('系统繁忙，请稍后再试。');
						tag.appendTo(document.body);
						tag.find('.p_close').click(function(){
							$('#jquery_addmask').remove();
							tag.remove();
							return false;
						});
					}
				});
			}
		});
	}
	
	function go_icp(domain,is_313){
		$.ajax({
			type: "POST",
			url: '/member/mediav/geticp',
			data:'domain='+domain+'&is_313='+is_313,
			dataType: 'json',
			success: function(callback){
				if(callback.status == 'failed'){
					tag = showTag('ajax_error');
					tag.find('.simsun_m').text(callback.msg);
					tag.find('.p_close').click(function(){
						$('#jquery_addmask').remove();
						tag.remove();
						return false;
					});
					return false;
				}
				tag = showTag('icp_info');
				if(callback[0].Icp != undefined){
					icp = callback[0].Icp;
					tag.find('#company').val(icp.zname);
					tag.find('#home_page').val(icp.siteurl);
					tag.find('#icp').val(icp.icp);
				}
				tag.find('#email').val(callback[0].User.email);
				tag.find('#username').val(callback[0].User.username);
				tag.find('#domain').val(domain);
				tag.find('#domain_value').text(domain);
				var html = '<input type="hidden" name="doc" id="doc" value=""/><input type="hidden" name="license" id="license" value=""/><input type="hidden" name="icp_lic" id="icp_lic" value=""/>';
				tag.find('.p_bottom').html(html);
				tag.find('.p_close').click(function(){
					$('#jquery_addmask').remove();
					tag.remove();
					return false;
				});
				tag.find('.bottou_p').click(function(){
					$err = false;
					if(tag.find('#domain').val() == ''){
						tag.find('.ico_error').text('参数出错。');
						return false;
					}
					if(tag.find('#company').val() == ''){
						tag.find('.ico_error').text('请填写公司名称');
						return false;
					}
					if(tag.find('#home_page').val() == ''){
						tag.find('.ico_error').text('请填写公司主页');
						return false;
					}
					if(tag.find('#email').val() == ''){
						tag.find('.ico_error').text('请填写邮箱');
						return false;
					}
					if(tag.find('#icp').val() == ''){
						tag.find('.ico_error').text('icp备案号不能为空。');
						return false;
					}
					if(tag.find('#license').val() == ''){
						tag.find('.ico_error').text('请上传营业执照副本。');
						return false;
					}
					if(tag.find('#icp_lic').val() == ''){
						tag.find('.ico_error').text('请上传icp备案证书副本。');
						return false;
					}
					$.post("/member/mediav/icp_submit", tag.find('#icp_form').serialize(), function(data){
						data = eval("("+data+")");
						if(data.status == 'success'){
							tag = showTag('to_pay');
							tag.find('#domain').text(domain);
						}else{
							tag.find('.ico_error').text(data.msg);
							return false;
						}
						tag.find('.p_close').click(function(){
							$('#jquery_addmask').remove();
							tag.remove();
							return false;
						});
						tag.find('.bottou_p').click(function(){
							tag.find("#pay_form").attr('action','/member/mediav/do_buy/'+data.msg);
							tag.find("#pay_form").submit();
						});
				    });
				});
			},
			error:function(){
				tag = showTag('ajax_error');
				tag.find('.simsun_m').text('系统繁忙，请稍后再试。');
				tag.find('.p_close').click(function(){
					$('#jquery_addmask').remove();
					tag.remove();
					return false;
				});
			}
		});
	}
});

function do_it(obj,reason){
	id = $(obj).attr('mediav_id');
	if(!document.getElementById('jquery_addmask')){
		$.documentMask('','true');
	   obj = $('#jquery_addmask');
	   obj.css('background','black');
	}
	$.ajax({
		type: "POST",
		url: '/member/mediav/info/'+id,
		dataType: 'json',
		success: function(callback){
			if(callback != 'failed' && reason == 'no'){
				$('#icp_info').find('#company').text(callback[0].Mediav.company);
				$('#icp_info').find('#email').text(callback[0].Mediav.email);
				$('#icp_info').find('#home_page').text(callback[0].Mediav.home_page);
				$('#icp_info').find('#icp').text(callback[0].Mediav.icp);
				$('#icp_info').find('#license').attr('src',callback[0].Mediav.license);
				$('#icp_info').find('#icp_lic').attr('src',callback[0].Mediav.icp_lic);
				if(callback[0].Mediav.doc == ''){
					$('#icp_info').find('#doc_li').hide();
				}else{
					$('#icp_info').find('#doc_li').show();
					$('#icp_info').find('#doc').attr('src',callback[0].Mediav.doc);
				}
				$('#icp_info').appendTo(document.body);
				if(($(window).height() - $('#icp_info').outerHeight())/2 + $(document).scrollTop() < 0)
				{
					var top = ($(window).height() - $('#icp_info').outerHeight())/2 + $(document).scrollTop();
				}
				else
				{
					var top = ($(window).height() - $('#icp_info').outerHeight())/2 + $(document).scrollTop();
				}
				$('#icp_info').css({left:($(window).width() - $('#icp_info').outerWidth())/2, top:top});
				$('#icp_info').show();
			}else{
				var str = '获取备案数据失败。';
				if(reason == 'yes'){
					str = callback[0].Mediav.reason;
				}
				$('#ajax_error').find('.simsun_m').text(str);
				$('#ajax_error').appendTo(document.body);
				$('#ajax_error').show();
			}
			$('.p_close').click(function(){
				$('#jquery_addmask').remove();
				$('.pop').hide();
				return false;
			});
		},
		error:function(){
			$('#ajax_error').find('.simsun_m').text('系统繁忙，请稍后再试。');
			$('#ajax_error').appendTo(document.body);
			$('.p_close').click(function(){
				$('#jquery_addmask').remove();
				$('.pop').hide();
				return false;
			});
		}
	});
}
