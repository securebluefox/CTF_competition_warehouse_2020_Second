

/*=====================================
 * Preview
 *=====================================*/
 $(function(){
	(function(){
		if (!document.getElementById('j-tplpreview-filter')) return false;
		
		//初始化
		var layoutResize=function(){
			var _height=$(window).height();
			if ($('#j-tplpreview-expand').is('.close')){
				_height-=$('#tplpreview-info').height();
			}
			$('#ifr-tplpreview').height(_height);
			var _width=$(window).width();
			if (_width>1078){
				$('#j-tplpreview-handler').css('left', '970px');
			} else if (_width>970) {
				$('#j-tplpreview-handler').css('left', '916px');
			} else {
				$('#j-tplpreview-handler').css('left', (_width-60)+'px');
			}
		}
		layoutResize();
		$(window).resize(layoutResize);
		$('#ifr-tplpreview').attr('src', $('#ifr-tplpreview').attr('j_load'));
		
		$('#j-tplpreview-expand').click(function(){
			if ($(this).is('.close')){
				$('#tplpreview-top').hide();
				$(this).removeClass().addClass('open');
				$(this).parent().next().show();
			} else {
				$('#tplpreview-top').show();
				$(this).removeClass().addClass('close');
				$(this).parent().next().hide();
			}
			layoutResize();
			return false;
		});
		
		//过滤
		var tplSelect=function(){
			var tplcontainer=$(this).parent();
			if (tplcontainer.is('.current')) return false;
			if (tplcontainer.is('.more')){
				//window.open('/templates/index?ind='+$('#j-tplpreview-ind').attr('j_val')+'&price='+$('#j-tplpreview-price').attr('j_val')+'&color='+$('#j-tplpreview-color').attr('j_val'), 'tpllist');
				return true;
			}
			var tplName=$(this).attr('title');
			var tplData=$(this).attr('j_data').split('|');
			$('#j-tplpreview-showname').attr('j_id', tplData[0]).text(tplName);
			$('#j-tplpreview-showrate').html('<span class="designer">设计师:</span><a class="sp-link" href="/service/view/'+tplData[3]+'" title="查看服务商信息">'+tplData[4]+'</a><a class="tpl-link" href="/packages/buy/'+tplData[0]+'/#review" title="查看详情">(查看详情)</a></div>');
			//$('#j-tplpreview-showrate').html('<em class="star-'+tplData[4]+'">.</em> <div class="score"><span class="orange">'+tplData[3]+'</span> (<a class="hlight" href="/packages/buy/'+tplData[0]+'/#review" title="查看评价">'+tplData[5]+'</a>人评)</div>');
			//$('#j-tplpreview-showprice').text(tplData[5]);
			tplcontainer.addClass('current').siblings().removeClass('current');
			$('#ifr-tplpreview').attr('src', $(this).attr('j_load'));
			document.title=tplName;
			if (document.getElementById('j-tplpreview-package')){
				$('#j-tplpreview-package li.default').addClass('current').siblings().removeClass('current');
				$('#j-tplpreview-limit li.default').addClass('current').siblings().removeClass('current');
				$('#j-tplpreview-package p').text($('#j-tplpreview-package li.default').text());
				$('#j-tplpreview-limit p').text($('#j-tplpreview-limit li.default').text());
			}
			return false;
		}
		$('#j-tplpreview-list a').click(tplSelect);
		
		var _httpLoad=null;
		var _count=1;
		var loadTpl=function(){
			if (_httpLoad) _httpLoad.abort();
			var url='/demo/change';
			var _data='parent_ctype='+$('#j-tplpreview-ind-tab li.current').attr('j_val')+'&ctype='+$('#j-tplpreview-ind').attr('j_val')+'&price='+$('#j-tplpreview-price').attr('j_val')+'&color='+$('#j-tplpreview-color').attr('j_val')+'&count='+_count;
			_httpLoad=$.ajax({
				url: url,
				data: _data,
				dataType: 'json',
				cache: false,
				error: function(){
					_httpLoad=null;
				},
				success: function(data){
					_httpLoad=null;
					if (data && data.length>0){
						_count++;
						var _html='';
						for (var i=0;i<data.length;i++){
							_html+='<li><a href="javascript:void(0);" title="'+data[i].name+'" j_data="'+data[i].id+'|'+data[i].sales+'|'+data[i].like_it+'|'+data[i].author_id+'|'+data[i].author+'|'+data[i].price+'" j_load="'+data[i].preview+'"><span class="inner"><img src="'+data[i].directory+'" alt="" /><span class="mask">.</span><span class="info"><span class="sales">销量：<span class="orange">'+data[i].sales+'</span></span> <span class="interests">想购买：'+data[i].like_it+'</span></span></span></a></li>';
						}
						$('#j-tplpreview-list').html(_html+'<li class="more"><a href="/templates" title="查看更多" target="_blank">查看更多</a></li>').find('a').click(tplSelect);
						$('#j-tplpreview-list a').eq(0).click();
						var showresults= document.getElementById('j-tplpreview-showresults');
						showresults.scrollLeft=0;
						showresults.scrollTop=0;
					}
				}
			});
		}
		
		
		$('#j-tplpreview-filter a.choice').click(function(){
			$(this).parent().addClass('item-open');
		});
		
		$('#j-tplpreview-filter div.item').mouseleave(function(){
			$(this).removeClass('item-open');
		});
		
		
		$('#j-tplpreview-ind-tab li').click(function(){
			if ($(this).is('.current')) return false;
			if ($(this).is('.unlimited')){
				$('#j-tplpreview-ind-list li').removeClass('current');
				$('#j-tplpreview-ind').attr('j_val', '0').text('请选择行业');
				$(this).parent().parent().parent().removeClass('item-open');
				_count=0;
				loadTpl();
			} else {
				$('#j-tplpreview-ind-list ul').eq(Number($(this).attr('j_tab'))).show().siblings().hide();
				$(this).addClass('current').siblings().removeClass('current');
			}
		});
		
		$('#j-tplpreview-ind-list a').click(function(){
			var container=$(this).parent();
			var _item=container.parent().parent().parent().parent();
			if (container.is('.current')){
				_item.removeClass('item-open');
				return false;
			}
			var title=$(this).attr('title').split('|');
			var value=$(this).attr('j_val');
			$('#j-tplpreview-ind').attr('j_val', value).html('<strong>'+title[0]+'</strong> <span class="des">('+title[1]+')</span>');
			container.addClass('current').siblings().removeClass('current');
			_item.removeClass('item-open');
			_count=0;
			loadTpl();
			return false;
		});
		
		$('#j-tplpreview-price-list a').click(function(){
			var container=$(this).parent();
			var _item=container.parent().parent().parent();
			if (container.is('.current')){
				_item.removeClass('item-open');
				return false;
			}
			var price=$(this).text();
			var value=$(this).attr('j_val');
			$('#j-tplpreview-price').attr('j_val', value).html(price);
			container.addClass('current').siblings().removeClass('current');
			_item.removeClass('item-open');
			_count=0;
			loadTpl();
			return false;
		});
		
		$('#j-tplpreview-color-list li').click(function(){

			var _item=$(this).parent().parent().parent();
			if ($(this).is('.current')){
				_item.removeClass('item-open');
				return false;
			}
			var color=$(this).text();
			var value=$(this).attr('j_val');
			$('#j-tplpreview-color').attr('j_val', value).html('<span class="color '+value+'"><span>'+color+'</span></span>');
			$(this).parent().next().find('a').removeClass('current');
			$(this).addClass('current').siblings().removeClass('current');
			_item.removeClass('item-open');
			_count=0;
			loadTpl();
			return false;
		});
		
		$('#j-tplpreview-color-list a').click(function(){
			var _item=$(this).parent().parent().parent();
			if ($(this).is('.current')){
				_item.removeClass('item-open');
				return false;
			}
			$('#j-tplpreview-color').attr('j_val', 'all').html('不限颜色');
			$(this).parent().prev().find('li').removeClass('current');
			$(this).addClass('current');
			_item.removeClass('item-open');
			_count=0;
			loadTpl();
			return false;
		});
		
		//换一批
		$('#j-tplpreview-reload').click(function(){
			loadTpl();
			return false;
		});
		
		//购买
		$('#j-tplpreview-order').click(function(){
			if (document.getElementById('j-tplpreview-package')){
				window.open($(this).attr('j_url')+'?data[Template][id]='+$('#j-tplpreview-showname').attr('j_id')+'&data[Package][id]='+$('#j-tplpreview-package li.current').attr('j_val')+'&data[years]='+$('#j-tplpreview-limit li.current').attr('j_val'));
			} else {
				window.open($(this).attr('j_url')+'?data[Template][id]='+$('#j-tplpreview-showname').attr('j_id'));
			}
			return false;
		});
		$('#j-tplpreview-order2').click(function(){
			$('#j-tplpreview-order').click();
			return false;
		});
		
		/*
		if (!document.getElementById('tplpreview-info')) return false;
		$('#j-preview-stretch a').click(function(){
			if( $(this).is('.close-btn') ){
				$('#j-preview-tpl').hide();	
				$(this).removeClass().addClass('open-btn').text('展开').attr('title','点击展开');
			}
			else if( $(this).is('.open-btn') ){
				$('#j-preview-tpl').show();	
				$(this).removeClass().addClass('close-btn').text('收缩').attr('title','点击收缩');;
			}
			$(window).resize();
		});
		
		
		
		
		
		//切换模板
		$('#j-tplpreview-list a').click(function(){
			if (!tplData || tplData.length==0) return false;
			var box=$(this).parent();
			if (box.is('.current')) return false;
			var s=box.prevAll().length;
			var _item=tplData[s];
			$('#j-tplpreview-name').attr('j_id', _item.id).text(_item.name);
			$('#j-tplpreview-score').text(_item.rateScore);
			$('#j-tplpreview-rate').attr('href', _item.rateUrl).text(_item.rates);
			var price=_item.price.split('|');
			var _limit=$('#j-tplpreview-limit li.current').prevAll().length;
			$('#j-tplpreview-amount').text(price[_limit]);
			for (var i=0;i<price.length;i++){
				$('#j-tplpreview-limit li').eq(i).attr('j_price', price[i]);
			}
			$('#j-tplpreview-sales1').text(_item.salesRecent);
			$('#j-tplpreview-sales2').text(_item.salesTotal);
			$('#ifr-tplpreview').attr('src', _item.preview);
			box.addClass('current').siblings().removeClass('current');
			return false;
		});
		
		//选择年限
		$('#j-tplpreview-limit p').click(function(){
			$(this).next().show();
		});
		$('#j-tplpreview-limit').mouseleave(function(){
			$(this).find('ul').hide();
		});
		$('#j-tplpreview-limit a').click(function(){
			var _box=$(this).parent();
			var _list=_box.parent();
			if (_box.is('.current')){
				_list.hide();
				return false;
			}
			var _data=_box.attr('j_price');
			$('#j-tplpreview-amount').text(_data);
			_box.addClass('current').siblings().removeClass('current');
			_list.hide().prev().text($(this).text());
			return false;
		});
		
		//购买按钮
		$('#j-tplpreview-buy').click(function(){
			var url=$(this).attr('j_url') + '&data[Template][id]=' + $('#j-tplpreview-name').attr('j_id') + '&data[years]=' + $('#j-tplpreview-limit li.current').attr('j_val');
			location.href=url;
		});
		
		*/
	})();
	
	
	//购买选项
	(function(){
				
		$('#j-tplpreview-package p, #j-tplpreview-limit p').click(function(){
			$(this).next().show();
		});
		$('#j-tplpreview-package, #j-tplpreview-limit').mouseleave(function(){
			$(this).find('ul').hide();
		});
		
		/*
		$('#j-tplpreview-package a').click(function(){
			var _box=$(this).parent();
			var _list=_box.parent();
			var _data=_box.attr('j_data').split('|');
			for (var i=0;i<_data.length;i++){
				$('#j-tplpreview-limit li').eq(i).attr('j_data', _data[i]);
			}
			_box.addClass('current').siblings().removeClass('current');
			_list.hide().prev().text($(this).text());
			$('#j-tplpreview-limit li.current a').click();
			return false;
		});
		
		$('#j-tplpreview-limit a').click(function(){
			var _box=$(this).parent();
			var _list=_box.parent();
			var _data=_box.attr('j_data');
			$('#j-tplpreview-showprice').text(_data);
			_box.addClass('current').siblings().removeClass('current');
			_list.hide().prev().text($(this).text());
			return false;
		});
		*/
		
		var httpPrice=null;
		var loadPrice=function(){
			if (httpPrice) httpPrice.abort();
			httpPrice=$.ajax({
				url: '/ajax/getprice/'+$('#j-tplpreview-limit li.current').attr('j_val') + '/',
				dataType: 'json',
				cache: false,
				error: function(){
					httpPrice=null;
				},
				success: function(data){
					httpPrice=null;
					if (data.status=='success'){
						$('#j-tplpreview-showprice').text(data.price);
					}
				}
			});
		}
		
		$('#j-tplpreview-package a').click(function(){
			var _box=$(this).parent();
			var _list=_box.parent();
			if (!document.getElementById('j-tplpreview-msg')){
				_list.parents('div.extra').prepend('<div id="j-tplpreview-msg" class="msg"></div>');
			}
			_box.addClass('current').siblings().removeClass('current');
			_list.hide().prev().text($(this).text());
			loadPrice();
			var _msg=_box.attr('j_msg');
			var _msgUrl=_box.attr('j_link');
			if (_msg && _msg!=''){
				if (_msgUrl && _msgUrl!=''){
					$('#j-tplpreview-msg').html('<a class="orange" href="'+_msgUrl+'" title="'+_msg+'" target="_blank">'+_msg+'</a>');
				} else {
					$('#j-tplpreview-msg').html('<span class="orange">'+_msg+'</span>');
				}
			} else {
				$('#j-tplpreview-msg').empty();
			}
			return false;
		});
		
		$('#j-tplpreview-limit a').click(function(){
			var _box=$(this).parent();
			var _list=_box.parent();
			_box.addClass('current').siblings().removeClass('current');
			_list.hide().prev().text($(this).text());
			loadPrice();
			return false;
		});
	})();
});