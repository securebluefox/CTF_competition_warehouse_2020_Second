$(function(){
	$('#datalist-iask a.open').click(function(){
		var _act=$(this).text();
		var container=$(this).parent().parent().prev();
		var id=container.parent().attr('rel');
		var list=container.find('ul');
		if (_act=='收起'){
			list.eq(1).hide();
			container.find('form').remove();
			$(this).attr('title', '展开').text('展开');
			return false
		}
		if (_act=='展开'){
			if (list.length>1){
				list.eq(1).show();
				$(this).attr('title', '收起').text('收起');
			} else {
				list.eq(0).after('<ul class="clearfix iask-list loading">读取中...</ul>');
				var list2=list.eq(0).next();
				var theLink=$(this);
				$.ajax({
					url: $(this).attr('rel'),
					dataType: 'json',
					cache: false,
					error: function(){
						list2.remove();
						dialogError('iask-load-'+id, 'no', '载入失败', '连接服务器失败，请重试', 'removeSelf');
					},
					success: function(data){
						if (data.status=='notlogin'){
							window.location.href='/login';
						}
						if (data.status=='failed'){
							list2.remove();
							dialogError('iask-load-'+id, 'no', '载入失败', data.msg, 'removeSelf');
						}
						if (data.status=='success'){
							if (data.data.length<1){
								list2.removeClass('loading').addClass('blank').html('<span class="red">没有更多内容了</span>');
							} else {
								var _html='';
								for (var i=0;i<data.data.length;i++){
									_html+='<li class="'+data.data[i].type+'"><div class="clearfix inner"><div class="author">'+data.data[i].author+'</div><div class="container"><div class="content">'+data.data[i].content+'</div><div class="extra"><span class="grey">('+data.data[i].time+')</span></div></div></div></li>';
								}
								list2.removeClass('loading').html(_html);
							}
							theLink.attr('title', '收起').text('收起');
						}
					}
				});
			}
			return false
		}
	});
	$('#datalist-iask a.openform').click(function(){
		var openner=$(this);
		var container=$(this).parents('td');
		if (container.find('form').length>0){
			if ($(this).is('.btn-mgs-round')){
				container.find('form').hide();
				$(this).removeClass('btn-mgs-round').addClass('btn-mos-round');
			} else {
				container.find('form').show();
				$(this).removeClass('btn-mos-round').addClass('btn-mgs-round');
			}
			return false;
		}
		var _act=$(this).attr('title');
		var id=container.parent().attr('rel');
		var action=$(this).attr('rel');
		var _html='';
		if (_act=='补充问题'){
			_html='<form class="ask-box" action="'+action+'" method="post"><p><strong>补充问题：</strong>补充提问细节，以得到更准确答案。</p><textarea rows="10" class="text" placeholder="请输入您要提问的内容..."></textarea><input name="questid" type="hidden" value="'+id+'" /><div class="submit"><span class="btnwrap btn-mol"><span class="inner"><button type="submit" class="btn">提 交</button></span></span> <span class="btnwrap btn-mol"><span class="inner"><button type="button" class="btn cancel">取 消</button></span></span></div></form>';
		} else {
			_html='<form class="ask-box" action="'+action+'" method="post"><textarea rows="10" class="text" placeholder="请输入您要回答的内容..."></textarea><input name="questid" type="hidden" value="'+id+'" /><div class="submit"><span class="btnwrap btn-mol"><span class="inner"><button type="submit" class="btn">提 交</button></span></span> <span class="btnwrap btn-mol"><span class="inner"><button type="button" class="btn cancel">取 消</button></span></span></div></form>';
		}
		container.append(_html);
		var theForm=container.find('form');
		if (!supports_input_placeholder()){
			var _txtarea=theForm.find('textarea');
			_txtarea.addClass('grey').attr('value', _txtarea.attr('placeholder'));
			_txtarea.focus(function(){
				var _txt=$(this).attr('placeholder');
				if ($(this).val()==_txt){
					$(this).removeClass('grey').val('');
				}
			});
			_txtarea.blur(function(){
				var _txt=$(this).attr('placeholder');
				if ($(this).val()==''){
					$(this).addClass('grey').val(_txt);
				}
			});
		}
		$(this).removeClass('btn-mos-round').addClass('btn-mgs-round');
		theForm.find('button.cancel').click(function(){
			theForm.hide();
			openner.removeClass('btn-mgs-round').addClass('btn-mos-round');
		});
		theForm.submit(function(){
			var theTxtarea=$(this).find('textarea');
			var content=theTxtarea.val();
			var _id=$(this).find('input').val();
			if ($.trim(content)==''||content==theTxtarea.attr('placeholder')){
				dialogError('iask-form-'+_id, 'no', '操作失败', '请输入您要提交的内容', 'removeSelf');
				return false;
			}
			theTxtarea.attr('disabled', true);
			theBtn=$(this).find('button[type="submit"]');
			theBtn.attr('disabled', true);
			var _data = "data[iask_post][message]="+content+"&data[iask_post][iask_id]="+id;
			var theForm=$(this);
			$.ajax({
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				cache: false,
				data:_data,
				dataType: 'json',
				error: function(){
					dialogError('iask-form-'+_id, 'no', '提交失败', '连接服务器失败，请重试', 'removeSelf');
					theTxtarea.attr('disabled', false);
					theBtn.attr('disabled', false);
				},
				success: function(data){
					if (data.status=='notlogin'){
						window.location.href='/login';
					}
					if (data.status=='failed'){
						theTxtarea.attr('disabled', false);
						theBtn.attr('disabled', false);
						dialogError('iask-form-'+_id, 'no', '提交失败', data.msg, 'removeSelf');
					}
					if (data.status=='success'){
						var list=container.find('ul');
						var linkLoad=container.next().find('a.open');
						if (list.length<2){
							list.eq(0).after('<ul class="clearfix iask-list"></ul>');
						}
						var list2=list.eq(0).next();
						var _html='';
						for (var i=0;i<data.data.length;i++){
							_html+='<li class="'+data.data[i].type+'"><div class="clearfix inner"><div class="author">'+data.data[i].author+'</div><div class="container"><div class="content">'+data.data[i].content+'</div><div class="extra"><span class="grey">('+data.data[i].time+')</span></div></div></div></li>';
						}
						list2.html(_html);
						linkLoad.attr('title', '收起').text('收起');
						openner.removeClass('btn-mgs-round').addClass('btn-mos-round');
						theForm.remove();
					}
				}
			});
			return false;
		});
		return false;
	});
	$('#datalist-iask a.closequest').click(function(){
		dialogConfirm('closequest', 'no', '已解决的问题将不再被继续补充和获取新的答复，您确定要结束这个问题吗？', 400, '', '', '');
		var this1=$(this);
		$('#dialog-confirm-confirm-closequest').click(function(){
			$('#dialog-confirm-closequest').remove();
			var links=this1.parent();
			links.hide().after('<div class="links"><span class="green">感谢您的关注，正在关闭问题...</span></div>');
			var _callback=links.next();
			$.ajax({
				url: this1.attr('rel'),
				dataType: 'json',
				cache: false,
				error: function(){
					dialogError('iask-close-'+_id, 'no', '提交失败', '连接服务器失败，请重试', 'removeSelf');
					links.show();
					_callback.remove();
				},
				success: function(data){
					if (data.status=='notlogin'){
						window.location.href='/login';
					}
					if (data.status=='failed'){
						_callback.html('<span class="red">'+data.msg+'</span>');
					}
					if (data.status=='success'){
						_callback.html('<span class="green">该问题已关闭，感谢您的支持！如果仍然有疑问，请 <strong><a href="/member/iasks/ask" title="我要提问">提交新问题</a><strong></span>');
					}
				}
			});
		});
		return false;
	});
});

