//刷新登录状态
function loadHeadbar(){
	$.ajax({
		url: '/index/headbar/',
		cache: false,
		success: function(data){
			if (data!='no') $('#headbar').html(data);
			//下拉菜单
			$('#headbar-menu li.multimenu div.inner').hover(function(){
				$(this).addClass('hover');
			}, function(){
				$(this).removeClass('hover');
			});
		}
	});
}
loadHeadbar();