
var setSelect = function(nodeId, pid, type, selectVal){
    nodeId.empty();
    $.ajax({
       type     : "GET",
       url      : '/ajax-getarea-'+pid.val()+'-'+type,
       data     : '',
       dataType :'json',
       async    : false,
       success: function(data){
            nodeId.append('<option value="0">请选择</option>');
            $.each(data, function(i,item){
                selected = (item["id"] == selectVal) ? 'selected' : '';
                nodeId.append('<option value="'+item["id"]+'" '+selected+'>'+item["name"]+'</option>');
            });
       }
    });
}

  var selectArea = function(addressArr){
    setSelect($('#province'), $('#country'), 1, addressArr.province);
    setSelect($('#city'), $('#province'), 2, addressArr.city);
    setSelect($('#district'), $('#city'), 3, addressArr.district);
}


