$(function(){
	//搜索下拉
	$('#search-menu li.search-list div.inner').hover(function() {
		$(this).addClass('hover');
	}, function(){
		$(this).removeClass('hover click');
	});
	$('#search-menu li.search-list div.inner').click(function() {
		$(this).addClass('click');
	});
	$('#search-menu li.search-list a.parent').click(function() {
		$(this).next().show();
	});
	$('#search-menu li.search-list div.inner').mouseleave(function() {
		$(this).find('div.child').hide();
	});
	
	//搜索更多条件
	$('#search-menu li.search-more div.inner').click(function() {
		if ($(this).is('.click')) {
			$(this).removeClass('click');
			$('#search-box').hide();	
		}
		else {
			$(this).addClass('click');
			$('#search-box').show();
		}
	});
	
	//下拉菜单显示隐藏
	(function(){
		if (!document.getElementById('search-box')) return false;
		$('#search-box p').click(function(){
			$(this).next().show();
		});
		$('#search-box div.fakeselect').mouseleave(function(){
			$(this).find('ul').hide();
		});
		$('#search-box div.fakeselect a').click(function(){
			var _box=$(this).parent();
			var _list=_box.parent();
			if (_box.is('.current')){
				_list.hide();
				return false;
			}
			_box.addClass('current').siblings().removeClass('current');
			_list.hide().prev().text($(this).text());
			return false;			
		});
	})();
	
	
	
	//撤销维权
	$('#datatable a.complaints-revocation').click(function(){
		dialogConfirm('complaints', 'no', '是否确定撤销维权？', '', '', '', '');
		var _url=$(this).attr('href');
		$('#dialog-confirm-confirm-complaints').click(function(){
			window.location.href=_url;
			return false;
		});
		return false;
	});
	
});
