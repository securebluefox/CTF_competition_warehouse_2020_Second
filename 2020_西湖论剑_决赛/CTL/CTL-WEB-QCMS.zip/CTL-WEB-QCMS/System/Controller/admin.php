<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends Controllers{
	private $_adminObj;
	function __construct(){
		parent::__construct();
		$this->_adminObj = $this->load_model('QCMS_Admin');
	}	
	
	public function index_Action(){	
		if(!empty($_POST)){
			if(empty($_POST['username'])){
				exec_script('alert("帐号不能为空");history.back();');exit;
			}
			if(empty($_POST['password'])){
				exec_script('alert("密码不能为空");history.back();');exit;
			}
			$result = $this->adminLogin($_POST['username'], $_POST['password']);
			if($result){
				exec_script('window.location.href="'.url(array('backend', 'index')).'"');exit;
			}else{
				exec_script('alert("登录失败");history.back();');exit;
			}
		}
		$this->load_view('home/admin');
	}
	
	public function logout_Action(){
		$this->cookieObj->del(array('admin_id' => '', 'admin_level' => '', 'admin_name' => '', 'admin_secret' => ''));
		exec_script('window.location.href="'.url(array('admin', 'index')).'"');exit;
	}
	
	public function pwd_Action(){
		echo md5(md5('admin').SITE_KEY);
	}
	
}
