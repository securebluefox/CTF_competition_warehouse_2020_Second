<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Index extends ControllersAdmin{

	function __construct(){
		parent::__construct();
		
	}	
	
	public function index_Action(){
		$newsObj = $this->load_model('QCMS_News');
		$productObj = $this->load_model('QCMS_Product');
		$albumObj = $this->load_model('QCMS_Album');
		$downObj = $this->load_model('QCMS_Down');
		$userObj = $this->load_model('QCMS_User');
		$temp['news'] = $newsObj->selectOne('', 'COUNT(*) AS count');
		$temp['product'] = $productObj->selectOne('', 'COUNT(*) AS count');
		$temp['album'] = $albumObj->selectOne('', 'COUNT(*) AS count');
		$temp['down'] = $downObj->selectOne('', 'COUNT(*) AS count');
		$temp['user'] = $userObj->selectOne('', 'COUNT(*) AS count');
		$this->load_view('backend/index/index', $temp);
	}
	
	public function backend_Action(){
		echo '后台管理';
	}
	
	public function frame_Action(){
		$this->load_view('backend/index/frame');
	}
	
	
	
	public function ajaxupload_Action(){
		$result = $this->upload($_FILES['filedata']);
		$arr = array();
		if($result < 0){
			$arr['error'] = 1;
			$arr['msg'] = '上传失败';
			$arr['url'] = '';
		}else{
			$arr['error'] = 0;
			$arr['msg'] = '上传成功';
			$arr['url'] = $result;
		}
		echo json_encode($arr);
	}
	
	public function ajaxuploadediter_Action(){
		!empty($_FILES['imgFile']) || die('无任何文件上传');		
		$result = $this->upload($_FILES['imgFile']);
		$arr = array();
		if($result < 0){
			$arr['error'] = '上传失败';
			$arr['url'] = '';
		}else{
			$arr['error'] = 0;
			$arr['url'] = $result;
		}
		echo json_encode($arr);
	}
	
}
