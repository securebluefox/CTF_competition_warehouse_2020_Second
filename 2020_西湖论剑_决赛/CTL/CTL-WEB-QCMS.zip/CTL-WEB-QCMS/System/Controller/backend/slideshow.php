<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Slideshow extends ControllersAdmin{
	private $_slideshowObj;
	function __construct(){
		parent::__construct();
		$this->_slideshowObj = $this->load_model('QCMS_Slideshow');
	}	
	
	public function index_Action($page = 0){
		$count = 0;
		$this->pageNum = 6;
		$temp['module_name'] = 'guest';
		$offset = ($page <= 0) ? 0 : ($page - 1) * $this->pageNum;
		$temp['rs'] = $this->_slideshowObj->selectAll(array($offset, $this->pageNum), $count, array());
		$temp['page'] = $this->page_bar($count[0]['count'], $this->pageNum, url(array('slideshow', 'index', '{page}' )), 9, $page);
		$this->load_view('backend/slideshow/index', $temp);
	}
	
	public function add_Action(){
		if(!empty($_POST)){
			$result = $this->_slideshowObj->insert($_POST);
			if($result){
				exec_script('window.location.href="'.url(array('backend', 'slideshow')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$this->load_view('backend/slideshow/add');
	}
	
	public function edit_Action($id = 0){
		if(!empty($_POST)){
			$result = $this->_slideshowObj->update($_POST, array('id' => $id));
			if($result){
				exec_script('window.location.href="'.url(array('backend', 'slideshow')).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$temp['rs'] = $this->_slideshowObj->selectOne(array('id' => $id));
		$this->load_view('backend/slideshow/edit', $temp);
	}
	
	public function delete_Action($id = 0){
		$result = $this->_slideshowObj->delete(array('id' => $id));
		if($result){
			exec_script('window.location.href="'.url(array('backend', 'slideshow')).'"');exit;
		}else{
			exec_script('alert("删除失败");history.back();');exit;
		}
	}
	
}