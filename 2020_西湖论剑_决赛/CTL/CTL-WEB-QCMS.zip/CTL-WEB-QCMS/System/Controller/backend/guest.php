<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Guest extends ControllersAdmin{
	private $_guestObj;
	function __construct(){
		parent::__construct();
		$this->_guestObj = $this->load_model('QCMS_Guest');
	}	
	
	public function index_Action($page = 0){
		$count = 0;
		$this->pageNum = 6;
		$temp['module_name'] = 'guest';
		$offset = ($page <= 0) ? 0 : ($page - 1) * $this->pageNum;
		$temp['rs'] = $this->_guestObj->selectAll(array($offset, $this->pageNum), $count, array());
		$temp['page'] = $this->page_bar($count[0]['count'], $this->pageNum, url(array('guest', 'index', '{page}' )), 9, $page);
		$this->load_view('backend/guest/index', $temp);
	}
	
	public function edit_Action($id = 0){
		if(!empty($_POST)){
			$result = $this->_guestObj->update(array('title' => $_POST['title'], 'name' => $_POST['name'], 'email' => $_POST['email'], 'content' => $_POST['content']), array('id' => $id));
			if($result){
				exec_script('window.location.href="'.url(array('backend', 'guest')).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$temp['rs'] = $this->_guestObj->selectOne(array('id' => $id));
		$this->load_view('backend/guest/edit', $temp);
	}
	
	public function delete_Action($id = 0){
		$result = $this->_guestObj->delete(array('id' => $id));
		if($result){
			exec_script('alert("删除成功");window.location.href="'.url(array('backend', 'guest')).'"');exit;
		}else{
			exec_script('alert("删除失败");history.back();');exit;
		}
	}
	
	public function ajaxdelete_Action($id = 0){
		$idArr = explode('|', urldecode($id));
		$result = $this->_guestObj->delete(array('id' => $idArr));
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}
}
