<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Category extends ControllersAdmin{
	private $_cateObj;
	function __construct(){
		parent::__construct();
		$this->_cateObj = $this->load_model('QCMS_Category');
	}	
	
	public function index_Action(){
		$this->categoryArr();
		$this->load_view('backend/category/index');
	}
	
	public function add_Action($pid = 0){
		
		$this->categoryArr();
		$pRs = $this->_cateObj->selectOne(array('id' => $pid), 'module_id');
		$temp['module_id'] = $pRs['module_id'];
		$temp['pid'] = $pid;
		if(!empty($_POST)){
			$insertArr = $_POST;
			$insertArr['islink'] = empty($_POST['islink']) ? 0 : 1;
			$insertArr['display'] = empty($_POST['display']) ? 0 : 1;
			$result = $this->_cateObj->insert($insertArr);
			if($result){
				exec_script('alert("添加成功");window.location.href="'.url(array('backend', 'category')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$this->load_view('backend/category/add', $temp);
	}
	
	public function edit_Action($id = 0){
		$this->categoryArr();
		if(!empty($_POST)){
			$insertArr = $_POST;
			$insertArr['islink'] = empty($_POST['islink']) ? 0 : 1;
			$insertArr['display'] = empty($_POST['display']) ? 0 : 1;
			$result = $this->_cateObj->update($insertArr, array('id' => $id));
			if($result){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'category', 'edit', $id)).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$temp['rs'] = $this->_cateObj->selectOne(array('id' => $id));
		$this->load_view('backend/category/edit', $temp);
	}
	
	public function delete_Action($id = 0){
		$rs = $this->_cateObj->select(array('pid' => $id));
		if(!empty($rs)){
			exec_script('alert("分类下有子分类，请先删除子分类再删除");history.back();');exit;
		}
		$result = $this->_cateObj->delete(array('id' => $id));
		if($result){
			exec_script('alert("删除成功");window.location.href="'.url(array('backend', 'category')).'"');exit;
		}else{
			exec_script('alert("删除失败");history.back();');exit;
		}
	}
	
	public function module_Action(){
		$this->load_view('backend/category/module');
	}
	
	public function location_Action($type = 'index', $id = 0){
		$locatObj = $this->load_model('QCMS_Location');
		switch ($type){
			case 'add':
				self::_addLocation();
				break;
			case 'edit':
				self::_editLocation($id);
				break;
			case 'delete':
				self::_delLocation($id);
				break;
			default:
				$temp['rs'] = $locatObj->select();
				$this->load_view('backend/category/location', $temp);
				break;			
		}
		
	}
	
	private function _addLocation(){
		$locatObj = $this->load_model('QCMS_Location');
		if(!empty($_POST)){
			$result = $locatObj->insert($_POST);
			if($result){
				exec_script('alert("添加成功");window.location.href="'.url(array('backend', 'category', 'location')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$this->load_view('backend/category/locationadd');
	}
	
	private function _editLocation($id = 0){
		$locatObj = $this->load_model('QCMS_Location');
		if(!empty($_POST)){
			$result = $locatObj->update($_POST, array('id' => $id));
			if($result){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'category', 'location')).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$temp['rs'] = $locatObj->selectOne(array('id' => $id));
		$this->load_view('backend/category/locationedit', $temp);
	}
	
	private function _delLocation($id = 0){
		exec_script('alert("推荐位暂时不能删除");history.back();');exit;
	}
	
	public function tag_Action($type = 'index', $id = 0){
		$tagObj = $this->load_model('QCMS_Tag');
		switch ($type){
			case 'add':
				self::_addTag();
				break;
			case 'edit':
				self::_editTag($id);
				break;
			case 'delete':
				self::_delTag($id);
				break;
			default:
				$temp['rs'] = $tagObj->select();
				$this->load_view('backend/category/tag', $temp);
				break;
		}
	
	}
	
	private function _addTag(){
		$tagObj = $this->load_model('QCMS_Tag');
		if(!empty($_POST)){
			$_POST['addtime'] = time();
			$result = $tagObj->insert($_POST);
			if($result){
				exec_script('alert("添加成功");window.location.href="'.url(array('backend', 'category', 'tag')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$this->load_view('backend/category/tagadd');
	}
	
	private function _editTag($id = 0){
		$tagObj = $this->load_model('QCMS_Tag');
		if(!empty($_POST)){
			$result = $tagObj->update($_POST, array('id' => $id));
			if($result){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'category', 'tag')).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$temp['rs'] = $tagObj->selectOne(array('id' => $id));
		$this->load_view('backend/category/tagedit', $temp);
	}
	
	private function _delTag($id = 0){
		$tagObj = $this->load_model('QCMS_Tag');
		$result = $tagObj->delete(array('id' => $id));
		if($result){
			exec_script('alert("删除成功");window.location.href="'.url(array('backend', 'category', 'tag')).'"');exit;
		}else{
			exec_script('alert("删除失败");history.back();');exit;
		}
	}
}