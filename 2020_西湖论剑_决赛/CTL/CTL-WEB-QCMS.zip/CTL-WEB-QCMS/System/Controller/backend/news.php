<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class News extends ControllersAdmin{
	private $_newsObj;
	private $_cateObj;
	private $_userObj;
	private $_locatObj;
	function __construct(){
		parent::__construct();
		$this->_newsObj = $this->load_model('QCMS_News');
		$this->_cateObj = $this->load_model('QCMS_Category');
		$this->_userObj = $this->load_model('QCMS_User');
		$this->_locatObj = $this->load_model('QCMS_Location');
	}	
	
	public function index_Action($page = 0){
		$condStr = 0;
		if(isset($_GET['title']) && $_GET['title'] != ''){
			$condArr[] = " title LIKE '%".$_GET['title']."%'";
		}
		$condStr = empty($condArr) ? '' : ' WHERE '.implode(' && ', $condArr);
		$count = 0;
		$offset = ($page <= 0) ? 0 : ($page - 1) * $this->pageNum;
		$temp['rs'] = $this->_newsObj->selectAll(array($offset, $this->pageNum), $count, $condStr,  '*');
		$temp['page'] = $this->page_bar($count[0]['count'], $this->pageNum, url(array('backend', 'news', 'index', '{page}')), 9, $page);
		$temp['cateRs'] = $this->_cateObj->select('', 'id, name', 0, 'id');
		$this->load_view('backend/news/index', $temp);
	}
	
	public function add_Action($cid = 0){
		$temp['locatRs'] = $this->_locatObj->select(array('module_id' => 1));
		if(!empty($_POST)){
			if(empty($_POST['title'])){
				exec_script('alert("标题不能为空");history.back();');exit;
			}
			if(empty($_POST['content'])){
				exec_script('alert("内容不能为空");history.back();');exit;
			}
			$islink = empty($_POST['islink']) ? 0 : 1; 
			$purview = empty($_POST['purview']) ? '' : implode('|', $_POST['purview']);
			$insertArr = array(
					'cid'		=>	$_POST['cid'],
					'title'		=>	$_POST['title'],
					'source'	=>	$_POST['source'],
					'keywords'	=>	$_POST['keywords'],
					'description'=>	$_POST['description'],
					'img'		=>	$_POST['img'],
					'info'		=>	$_POST['info'],
					'content'	=>	$_POST['content'],
					'islink'	=>	$islink,
					'link'		=>	$_POST['link'],
					'allow_comments'	=>	$_POST['allow_comments'],
					'fee'		=>	$_POST['fee'],
					'purview'	=>	$purview,
					'status'	=>	$_POST['status'],
					'sort'		=>	$_POST['sort'],
					'addtime'	=>	strtotime($_POST['addtime']),
					'vote_id'	=>	$_POST['vote_id']
			);
			$resultAll = true;
			try {
				DB::$s_db_obj[DB::$s_dbname]->beginTransaction();	
				$locatPost = empty($_POST['location']) ? array() : $_POST['location'];
				$result = $this->_newsObj->insert($insertArr);
				$newsId = $this->_newsObj->get_insert_id();
				if($result !== false){
					self::locationData($newsId, $locatPost);
				}
				
				DB::$s_db_obj[DB::$s_dbname]->commit();
			}catch (Exception $e){
				DB::$s_db_obj[DB::$s_dbname]->rollBack();
				$resultAll = false;
			}
			if($resultAll){
				exec_script('alert("添加成功");window.location.href="'.url(array('backend', 'news')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$this->categoryArr(1);
		$temp['cid'] = $cid;
		$temp['userGroupRs'] = $this->_userObj->select('', '*', 1);
		$temp['locatRs'] = $this->_locatObj->select(array('module_id' => 1));
		$this->load_view('backend/news/add', $temp);
	}
	
	public function edit_Action($id = 0){
		$temp['locatRs'] = $this->_locatObj->select(array('module_id' => 1));
		if(!empty($_POST)){
			if(empty($_POST['title'])){
				exec_script('alert("标题不能为空");history.back();');exit;
			}
			if(empty($_POST['content'])){
				exec_script('alert("内容不能为空");history.back();');exit;
			}
			$islink = empty($_POST['islink']) ? 0 : 1;
			$purview = empty($_POST['purview']) ? '' : implode('|', $_POST['purview']);
			$insertArr = array(
					'cid'		=>	$_POST['cid'],
					'title'		=>	$_POST['title'],
					'source'	=>	$_POST['source'],
					'keywords'	=>	$_POST['keywords'],
					'description'=>	$_POST['description'],
					'img'		=>	$_POST['img'],
					'info'		=>	$_POST['info'],
					'content'	=>	$_POST['content'],
					'islink'	=>	$islink,
					'link'		=>	$_POST['link'],
					'allow_comments'	=>	$_POST['allow_comments'],
					'fee'		=>	$_POST['fee'],
					'purview'	=>	$purview,
					'status'	=>	$_POST['status'],
					'sort'		=>	$_POST['sort'],
					'addtime'	=>	strtotime($_POST['addtime']),
					'vote_id'	=>	$_POST['vote_id']
			);
			$resultAll = true;
			try {
				$locatPost = empty($_POST['location']) ? array() : $_POST['location'];
				DB::$s_db_obj[DB::$s_dbname]->beginTransaction();
				$result = $this->_newsObj->update($insertArr, array('id' => $id));
				$newsId = $id;
				if($result !== false){
					self::locationData($newsId, $locatPost);
				}
		
				DB::$s_db_obj[DB::$s_dbname]->commit();
			}catch (Exception $e){
				DB::$s_db_obj[DB::$s_dbname]->rollBack();
				$resultAll = false;
			}

			if($resultAll){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'news', 'edit', $id)).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$this->categoryArr(1);
		$temp['rs'] = $this->_newsObj->selectOne(array('id' => $id));
		$temp['cid'] = $temp['rs']['cid'];
		$temp['userGroupRs'] = $this->_userObj->select('', '*', 1);
		$locatData = $this->_locatObj->select(array('module_id' => 1, 'news_id' => $id), '*', 1);
		$locatArr = array();
		foreach($locatData as $k => $v){
			$locatArr[] = $v['location_id'];
		}
		$temp['locatArr'] = $locatArr;
		$this->load_view('backend/news/edit', $temp);
	}
	
	public function delete_Action($id = 0){
		$result = $this->_newsObj->delete(array('id' => $id));
		if($result){
			exec_script('alert("删除成功");window.location.href="'.url(array('backend', 'news')).'"');exit;
		}else{
			exec_script('alert("删除失败");history.back();');exit;
		}
	}
	
	public function ajaxdelete_Action($id = 0){
		$idArr = explode('|', urldecode($id));
		$result = $this->_newsObj->delete(array('id' => $idArr));
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}
}
	