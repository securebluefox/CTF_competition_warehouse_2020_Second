<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Template extends ControllersAdmin{
	private $_tempObj;
	private $_sysObj;
	function __construct(){
		parent::__construct();
		$this->_tempObj = $this->load_model('QCMS_Template');
		$this->_sysObj = $this->load_model('QCMS_Sys');
	}	
	
	public function index_Action(){
		$temp['rs'] = $this->_tempObj->select();
		$this->load_view('backend/template/index', $temp);
	}
	
	public function add_Action(){
		if(!empty($_POST)){
			$tempRs = $this->_tempObj->select(array('name' => $_POST['name']));
			if(!empty($tempRs)){
				exec_script('alert("模版已经安装");history.back();');exit;
			}
			$result = $this->_tempObj->insert(array('name' => $_POST['name'], 'addtime' => time()));
			if($result){
				exec_script('alert("添加模版成功");window.location.href="'.url(array('backend', 'template')).'"');exit;
			}else{
				exec_script('alert("添加模版失败");history.back();');exit;
			}
		}
		$tempArr = $this->_tempObj->select();
		$tempNameArr = array();
		foreach($tempArr as $val){
			$tempNameArr[] = $val['name'];
		}
		$result = @opendir(BASEPATH.'view/template/');
		$i = 0;
		while (false !== ($file = readdir($result))){
			if($file != '.' && $file != '..'){
				$viewFileName = $filename = $file;
				if(in_array($filename, $tempNameArr)) {
					$viewFileName = $file.' [已安装]';
				}
				$i += 1;
				$rs[] = array('id' => $i, 'name' => $filename, 'viewFileName' => $viewFileName);
			}
		}
		$temp['rs'] = $rs;
		$this->load_view('backend/template/add', $temp);
	}
	
	public function delete_Action($id = 0){
		$sysRs = $this->_sysObj->selectOne(array('id' => 1));
		if($sysRs['template_id'] == $id){
			exec_script('alert("当前系统正使用次模版，不能删除");history.back();');exit;
		}
		$result = $this->_tempObj->delete(array('id' => $id));
		if($result){
			exec_script('alert("卸载模版成功");window.location.href="'.url(array('backend', 'template')).'"');exit;
		}else{
			exec_script('alert("卸载模版失败");history.back();');exit;
		}
	}
	
	public function default_Action(){
		$sysObj = $this->load_model('QCMS_Sys');
		$sysRs = $sysObj->selectOne('', 'template_id');
		$templateRs = $this->_tempObj->selectOne(array('id' => $sysRs['template_id']));
		$result = @opendir(BASEPATH.'view/template/'.$templateRs['name'].'/');
		$i = 0;
		while (false !== ($file = readdir($result))){
			if($file != '.' && $file != '..'){
				$filename = $file;
				$i += 1;
				$rs[] = array('id' => $i, 'name' => $filename);
			}
		}
		$temp['path'] = $templateRs['name'];
		$temp['rs'] = $rs;
		$this->load_view('backend/template/default', $temp);
	}
	
	public function tempview_Action($tempname = ''){
		if(empty($tempname)){
			exec_script('alert("模版文件不能为空");history.back();');exit;
		}
		$sysObj = $this->load_model('QCMS_Sys');
		$sysRs = $sysObj->selectOne('', 'template_id');
		$templateRs = $this->_tempObj->selectOne(array('id' => $sysRs['template_id']));
		$tempname = base64_decode($tempname);
		$result = file_get_contents(BASEPATH.'view/template/'.$templateRs['name'].'/'.$tempname);
		$str = str_replace(array("\n"), array('<br>'), htmlspecialchars($result));
		$temp['str'] = $str;
		$this->load_view('backend/template/tempview', $temp);
	}
	
	public function code_Action(){
		$this->load_view('backend/template/code');
	}
}
