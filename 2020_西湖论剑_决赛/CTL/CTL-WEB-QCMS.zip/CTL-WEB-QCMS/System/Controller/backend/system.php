<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class System extends ControllersAdmin{
	private $_sysObj;
	function __construct(){
		parent::__construct();
		$this->_sysObj = $this->load_model('QCMS_Sys');
	}	
	
	public function index_Action(){
		if(!empty($_POST)){
			$updateArr = array(
				'webname'	=>	$_POST['webname'],
				'title'		=>	$_POST['title'],
				'keywords'	=>	$_POST['keywords'],
				'description'=>	$_POST['description'],
				'email'		=>	$_POST['email'],
				'icp'		=>	$_POST['icp'],
				'info'		=>	$_POST['info'],
				'logo'		=>	$_POST['logo'],
				'count'		=>	$_POST['count'],
				'address'	=>	$_POST['address'],
				'tel'		=>	$_POST['tel'],
				'fax'		=>	$_POST['fax'],
				'qq'		=>	$_POST['qq'],
				'template_id'=>	$_POST['template_id']
			);
			$result = $this->_sysObj->update($updateArr, array('id' => 1));
			if($result){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'system')).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$tempObj = $this->load_model('QCMS_Template');
		$temp['tempRs'] = $tempObj->select();
		$temp['rs'] = $this->_sysObj->selectOne(array('id' => 1));

		$this->load_view('backend/system/index', $temp);
	}
	
	public function mail_Action(){
		$mailObj = $this->load_model('QCMS_Mail');
		if(!empty($_POST)){
			$result = $mailObj->update(array('smtp' => $_POST['smtp'], 'account' => $_POST['account'], 'password' => $_POST['password'], 'send' => $_POST['send'], 'username' => $_POST['username']), array('id' => 1));
			if($result){
				exec_script('alert("设置成功");window.location.href="'.url(array('backend', 'system', 'mail')).'"');exit;
			}else{
				exec_script('alert("设置失败");history.back();');exit;
			}
		}
		$temp['rs'] = $mailObj->selectOne(array('id' => 1));
		$this->load_view('backend/system/mail', $temp);
	}
	
	public function test_Action(){
		$result = $this->s_send('qesy@163.com', '钱哥哥', '钱钱哥哥你好啊', '测试邮件发送成功');
		echo ($result) ? 1 : 0;
	}
}