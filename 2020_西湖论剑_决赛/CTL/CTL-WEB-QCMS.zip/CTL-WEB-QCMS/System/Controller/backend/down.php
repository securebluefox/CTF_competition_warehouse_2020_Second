<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Down extends ControllersAdmin{
	private $_downObj;
	private $_cateObj;
	private $_userObj;
	private $_locatObj;
	function __construct(){
		parent::__construct();
		$this->_downObj = $this->load_model('QCMS_Down');
		$this->_cateObj = $this->load_model('QCMS_Category');
		$this->_userObj = $this->load_model('QCMS_User');
		$this->_locatObj = $this->load_model('QCMS_Location');
	}	
	
	public function index_Action($page = 0){
		$condStr = 0;
		if(isset($_GET['title']) && $_GET['title'] != ''){
			$condArr[] = " title LIKE '%".$_GET['title']."%'";
		}
		$condStr = empty($condArr) ? '' : ' WHERE '.implode(' && ', $condArr);
		$count = 0;
		$offset = ($page <= 0) ? 0 : ($page - 1) * $this->pageNum;
		$temp['rs'] = $this->_downObj->selectAll(array($offset, $this->pageNum), $count, $condStr,  '*');
		$temp['page'] = $this->page_bar($count[0]['count'], $this->pageNum, url(array('backend', 'news', 'index', '{page}')), 9, $page);
		$temp['cateRs'] = $this->_cateObj->select('', 'id, name', 0, 'id');
		$this->load_view('backend/down/index', $temp);
	}
	
	public function add_Action($cid = 0){
		$temp['locatRs'] = $this->_locatObj->select(array('module_id' => 2));
		
		if(!empty($_POST)){
			if(empty($_POST['title'])){
				exec_script('alert("标题不能为空");history.back();');exit;
			}
			if(empty($_POST['content'])){
				exec_script('alert("内容不能为空");history.back();');exit;
			}
			$islink = empty($_POST['islink']) ? 0 : 1;
			$purview = empty($_POST['purview']) ? '' : implode('|', $_POST['purview']);
			$downfiles = json_encode($_POST['downfiles']);
			$insertArr = array(
					'cid'		=>	$_POST['cid'],
					'title'		=>	$_POST['title'],
					'source'	=>	$_POST['source'],
					'keywords'	=>	$_POST['keywords'],
					'description'=>	$_POST['description'],
					'img'		=>	$_POST['img'],
					'info'		=>	$_POST['info'],
					'content'	=>	$_POST['content'],
					'islink'	=>	$islink,
					'link'		=>	$_POST['link'],
					'allow_comments'	=>	$_POST['allow_comments'],
					'fee'		=>	$_POST['fee'],
					'purview'	=>	$purview,
					'status'	=>	$_POST['status'],
					'sort'		=>	$_POST['sort'],
					'addtime'	=>	strtotime($_POST['addtime']),
					'vote_id'	=>	$_POST['vote_id'],
					'size'		=>	$_POST['size'],
					'license'	=>	$_POST['license'],
					'language'	=>	$_POST['language'],
					'platform'	=>	$_POST['platform'],
					'type'		=>	$_POST['type'],
					'score'		=>	$_POST['score'],
					'downfiles'	=>	$downfiles
			);
			$resultAll = true;
			try {
				DB::$s_db_obj[DB::$s_dbname]->beginTransaction();
				$locatPost = empty($_POST['location']) ? array() : $_POST['location'];
				$result = $this->_downObj->insert($insertArr);
				$newsId = $this->_downObj->get_insert_id();
				if($result !== false){
					self::locationData($newsId, $locatPost, 2);
				}
		
				DB::$s_db_obj[DB::$s_dbname]->commit();
			}catch (Exception $e){
				DB::$s_db_obj[DB::$s_dbname]->rollBack();
				$resultAll = false;
			}
			if($resultAll){
				exec_script('alert("添加成功");window.location.href="'.url(array('backend', 'down')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$this->categoryArr(2);
		$temp['cid'] = $cid;
		$temp['userGroupRs'] = $this->_userObj->select('', '*', 1);
		$temp['locatRs'] = $this->_locatObj->select(array('module_id' => 2));
		$this->load_view('backend/down/add', $temp);
	}
	
	public function edit_Action($id = 0){
		$temp['locatRs'] = $this->_locatObj->select(array('module_id' => 2));
		
		if(!empty($_POST)){
			if(empty($_POST['title'])){
				exec_script('alert("标题不能为空");history.back();');exit;
			}
			if(empty($_POST['content'])){
				exec_script('alert("内容不能为空");history.back();');exit;
			}
			$islink = empty($_POST['islink']) ? 0 : 1;
			$purview = empty($_POST['purview']) ? '' : implode('|', $_POST['purview']);
			$downfiles = !empty($_POST['downfiles']) ? json_encode($_POST['downfiles']) : json_encode(array());
			$insertArr = array(
					'cid'		=>	$_POST['cid'],
					'title'		=>	$_POST['title'],
					'source'	=>	$_POST['source'],
					'keywords'	=>	$_POST['keywords'],
					'description'=>	$_POST['description'],
					'img'		=>	$_POST['img'],
					'info'		=>	$_POST['info'],
					'content'	=>	$_POST['content'],
					'islink'	=>	$islink,
					'link'		=>	$_POST['link'],
					'allow_comments'	=>	$_POST['allow_comments'],
					'fee'		=>	$_POST['fee'],
					'purview'	=>	$purview,
					'status'	=>	$_POST['status'],
					'sort'		=>	$_POST['sort'],
					'addtime'	=>	strtotime($_POST['addtime']),
					'vote_id'	=>	$_POST['vote_id'],
					'size'		=>	$_POST['size'],
					'license'	=>	$_POST['license'],
					'language'	=>	$_POST['language'],
					'platform'	=>	$_POST['platform'],
					'type'		=>	$_POST['type'],
					'score'		=>	$_POST['score'],
					'downfiles'	=>	$downfiles
			);
			$resultAll = true;
			try {
				DB::$s_db_obj[DB::$s_dbname]->beginTransaction();
				$locatPost = empty($_POST['location']) ? array() : $_POST['location'];
				$result = $this->_downObj->update($insertArr, array('id' => $id));
				$newsId = $id;
				if($result !== false){
					self::locationData($newsId, $locatPost, 2);
				}
		
				DB::$s_db_obj[DB::$s_dbname]->commit();
			}catch (Exception $e){
				DB::$s_db_obj[DB::$s_dbname]->rollBack();
				$resultAll = false;
			}
			if($resultAll){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'down', 'edit', $id)).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		
		$this->categoryArr(2);
		$temp['rs'] = $rs = $this->_downObj->selectOne(array('id' => $id));
		$temp['cid'] = $rs['cid'];
		$temp['userGroupRs'] = $this->_userObj->select('', '*', 1);
		$locatData = $this->_locatObj->select(array('module_id' => 1, 'news_id' => $id), '*', 1);
		$locatArr = array();
		foreach($locatData as $k => $v){
			$locatArr[] = $v['location_id'];
		}
		$temp['locatArr'] = $locatArr;
		$this->load_view('backend/down/edit', $temp);
	}
	
	public function delete_Action($id = 0){
		$result = $this->_downObj->delete(array('id' => $id));
		if($result){
			exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'down')).'"');exit;
		}else{
			exec_script('alert("修改失败");history.back();');exit;
		}
	}
	
	public function ajaxdelete_Action($id = 0){
		$idArr = explode('|', urldecode($id));
		$result = $this->_newsObj->delete(array('id' => $idArr));
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}
	
	public function server_Action($type = 'index', $id = 0){
		switch ($type){
			case 'add':
				self::_serverAdd();
				break;
			case 'edit':
				self::_serverEdit($id);
				break;
			case 'delete':
				self::_serverDelete($id);
				break;
			default:
				$temp['rs'] = $this->_downObj->select('', '*', 2, '', '', array('sort' => 'ASC'));
				$this->load_view('backend/down/server', $temp);
				break;			
		}
	}
	
	private function _serverAdd(){
		if(!empty($_POST)){
			$result = $this->_downObj->insert(array('name' => $_POST['name'], 'address' => $_POST['address'], 'sort' => $_POST['sort']), 2);
			if($result){
				exec_script('alert("添加成功");window.location.href="'.url(array('backend', 'down', 'server')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$this->load_view('backend/down/server_add');
	}
	
	private function _serverEdit($id = 0){
		if(!empty($_POST)){
			$result = $this->_downObj->update(array('name' => $_POST['name'], 'address' => $_POST['address'], 'sort' => $_POST['sort']), array('id' => $id), 2);
			if($result){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'down', 'server', 'edit', $id)).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$temp['rs'] = $this->_downObj->selectOne(array('id' => $id), '*', 2);
		$this->load_view('backend/down/server_edit', $temp);
	}
	
	private function _serverDelete($id = 0){
		$result = $this->_downObj->delete(array('id' => $id), 2);
		if($result){
			exec_script('alert("删除成功");window.location.href="'.url(array('backend', 'down', 'server')).'"');exit;
		}else{
			exec_script('alert("删除失败");history.back();');exit;
		}
	}
}