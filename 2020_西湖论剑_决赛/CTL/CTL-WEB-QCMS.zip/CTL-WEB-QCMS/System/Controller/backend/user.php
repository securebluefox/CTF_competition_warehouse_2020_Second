<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class User extends ControllersAdmin{
	private $_userObj;
	private $_adminObj;
	function __construct(){
		parent::__construct();
		$this->_userObj = $this->load_model('QCMS_User');
		$this->_adminObj = $this->load_model('QCMS_Admin');
	}	
	
	public function index_Action($page = 0){
		$condArr = array();
		$condStr = '';
		if(isset($_GET['group_id']) && $_GET['group_id'] != ''){
			$condArr[] = " group_id = ".$_GET['group_id']." ";
		}
		if(isset($_GET['status']) && $_GET['status'] != ''){
			$condArr[] = " status = ".$_GET['status']." ";
		}
		if(isset($_GET['username']) && $_GET['username'] != ''){
			$condArr[] = " username LIKE '%".$_GET['username']."%'";
		}
		$condStr = empty($condArr) ? '' : ' WHERE '.implode(' && ', $condArr);
		$count = 0;
		$offset = ($page <= 0) ? 0 : ($page - 1) * $this->pageNum;
		$temp['rs'] = $this->_userObj->selectAll(array($offset, $this->pageNum), $count, $condStr,  'id, username, mobile, email, type, verimail, verimobile, addtime, status, group_id');
		$temp['page'] = $this->page_bar($count[0]['count'], $this->pageNum, url(array('backend', 'user', 'index', '{page}')), 9, $page);
		$temp['groupRs'] = $this->_userObj->select('', '*', 1, 'id');
		$this->load_view('backend/user/index', $temp);
	}
	
	public function add_Action(){
		if(!empty($_POST)){
			if(empty($_POST['username'])) {
				exec_script('alert("用户名不能为空");history.back();');exit;
			}
			if(empty($_POST['password'])) {
				exec_script('alert("密码不能为空");history.back();');exit;
			}
			$verimail = empty($_POST['verimail']) ? 0 : 1;
			$verimobile = empty($_POST['verimobile']) ? 0 : 1;
			$city = empty($_POST['city']) ? 0 : $_POST['city'];
			$money = empty($_POST['money']) ? 0 : $_POST['money'];
			$zip = empty($_POST['zip']) ? 0 : $_POST['zip'];
			$district = empty($_POST['district']) ? 0 : $_POST['district'];
			$result = $this->_userObj->insert(array(
					'username' 	=> 	$_POST['username'],
					'password' 	=> 	md5(md5($_POST['password']).SITE_KEY),
					'mobile'	=>	$_POST['mobile'],
					'email'		=>	$_POST['email'],
					'info'		=>	$_POST['info'],
					'addtime'	=> 	time(),
					'group_id'	=>	$_POST['group_id'],
					'money'		=> 	$money,
					'realname'	=> 	$_POST['realname'],
					'company'	=>	$_POST['compay'],
					'province'	=>	$_POST['province'],
					'city'		=>	$city,
					'district'	=>	$district,
					'address'	=>	$_POST['address'],
					'zip'		=>	$zip,
					'tel'		=>	$_POST['tel'],
					'fax'		=>	$_POST['fax'],
					'verimail'	=>	$verimail,
					'verimobile'=>	$verimobile
			));
			if($result){
				exec_script('alert("添加成功");window.location.href="'.url(array('backend', 'user')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$temp['groupRs'] = $this->_userObj->select('', '*', 1, 'id');
		$this->load_view('backend/user/add', $temp);
	}
	
	public function edit_Action($id = 0){
		if(!empty($_POST)){
			$verimail = empty($_POST['verimail']) ? 0 : 1;
			$verimobile = empty($_POST['verimobile']) ? 0 : 1;
			$city = empty($_POST['city']) ? 0 : $_POST['city'];
			$money = empty($_POST['money']) ? 0 : $_POST['money'];
			$zip = empty($_POST['zip']) ? 0 : $_POST['zip'];
			$district = empty($_POST['district']) ? 0 : $_POST['district'];
			$updateArr = array(
					'mobile'	=>	$_POST['mobile'],
					'email'		=>	$_POST['email'],
					'info'		=>	$_POST['info'],
					'money'		=> 	$money,
					'realname'	=> 	$_POST['realname'],
					'company'	=>	$_POST['compay'],
					'province'	=>	$_POST['province'],
					'city'		=>	$city,
					'group_id'	=>	$_POST['group_id'],
					'district'	=>	$district,
					'address'	=>	$_POST['address'],
					'zip'		=>	$zip,
					'tel'		=>	$_POST['tel'],
					'fax'		=>	$_POST['fax'],
					'verimail'	=>	$verimail,
					'verimobile'=>	$verimobile
			);
			if(!empty($_POST['password'])){
				$updateArr['password'] = md5(md5($_POST['password']).SITE_KEY);
			}
			$result = $this->_userObj->update($updateArr, array('id' => $id));
			if($result){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'user', 'edit', $id)).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$areaObj = $this->load_model('QCMS_Area');
		$temp['rs'] = $this->_userObj->selectOne(array('id' => $id));
		$temp['provinceRs'] = $areaObj->select(array('pid' => 1));
		$temp['cityRs'] = $areaObj->select(array('pid' => $temp['rs']['province']));
		$temp['districtRs'] = $areaObj->select(array('pid' => $temp['rs']['city']));
		$temp['groupRs'] = $this->_userObj->select('', '*', 1, 'id');
		$this->load_view('backend/user/edit', $temp);
	}
	
	public function delete_Action($id = 0){
		$result = $this->_userObj->delete(array('id' => $id));
		if($result){
			exec_script('alert("删除成功");window.location.href="'.url(array('backend', 'user')).'"');exit;
		}else{
			exec_script('alert("删除失败");history.back();');exit;
		}
	}
	
	public function group_Action($action = 'index', $id = 0){
		switch($action){
			case 'add':
				self::_addGroup();
				break;
			case 'edit':
				self::_editGroup($id);
				break;
			case 'delete':
				self::_delGroup($id);
				break;
			default:
				$temp['rs'] = $this->_userObj->select('', '*', 1, '', '', array('sort' => 'ASC', 'id' => 'ASC'));
				$this->load_view('backend/user/group', $temp);
				break;		
		}
	}
	
	
	private function _addGroup(){
		if(!empty($_POST)){
			if(empty($_POST['name'])){
				exec_script('alert("组名不能为空");history.back();');exit;
			}
			$allowpost = !empty($_POST['allowpost']) ? 1 : 0;
			$allowpostverify = !empty($_POST['allowpostverify']) ? 1 : 0;
			$allowupgrade = !empty($_POST['allowupgrade']) ? 1 : 0;
			$allowsendmessage = !empty($_POST['allowsendmessage']) ? 1 : 0;
			$allowattachment = !empty($_POST['allowattachment']) ? 1 : 0;
			$result = $this->_userObj->insert(array(
				'name' 		=>	$_POST['name'],
				'allowpost'	=>	$allowpost,
				'allowpostverify'	=>	$allowpostverify,
				'allowupgrade'	=>	$allowupgrade,
				'allowsendmessage'	=>	$allowsendmessage,
				'allowattachment'	=>	$allowattachment,
				'price_d'		=>	$_POST['price_d'],
				'price_m'		=>	$_POST['price_m'],
				'price_y'		=>	$_POST['price_y'],
				'allowmessage'	=>	$_POST['allowmessage'],
				'allowpostnum'	=>	$_POST['allowpostnum'],
				'description'	=>	$_POST['description'],
				'sort'			=>	$_POST['sort']
			), 1);
			if($result){
				exec_script('alert("添加成功");window.location.href="'.url(array('backend', 'user', 'group')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$this->load_view('backend/user/groupadd');
	}
	
	private function _editGroup($id = 0){
		if(!empty($_POST)){
			if(empty($_POST['name'])){
				exec_script('alert("组名不能为空");history.back();');exit;
			}
			$allowpost = !empty($_POST['allowpost']) ? 1 : 0;
			$allowpostverify = !empty($_POST['allowpostverify']) ? 1 : 0;
			$allowupgrade = !empty($_POST['allowupgrade']) ? 1 : 0;
			$allowsendmessage = !empty($_POST['allowsendmessage']) ? 1 : 0;
			$allowattachment = !empty($_POST['allowattachment']) ? 1 : 0;
			$result = $this->_userObj->update(array(
					'name' 		=>	$_POST['name'],
					'allowpost'	=>	$allowpost,
					'allowpostverify'	=>	$allowpostverify,
					'allowupgrade'	=>	$allowupgrade,
					'allowsendmessage'	=>	$allowsendmessage,
					'allowattachment'	=>	$allowattachment,
					'price_d'		=>	$_POST['price_d'],
					'price_m'		=>	$_POST['price_m'],
					'price_y'		=>	$_POST['price_y'],
					'allowmessage'	=>	$_POST['allowmessage'],
					'allowpostnum'	=>	$_POST['allowpostnum'],
					'description'	=>	$_POST['description'],
					'sort'			=>	$_POST['sort']
			), array('id' => $id), 1);
			if($result){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'user', 'group')).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$temp['rs'] = $this->_userObj->selectOne(array('id' => $id), '*', 1);
		$this->load_view('backend/user/groupedit', $temp);
	}
	
	private function _delGroup($id = 0){
		$result = $this->_userObj->delete(array('id' => $id), 1);
		if($result){
			exec_script('alert("删除成功");window.location.href="'.url(array('backend', 'user', 'group')).'"');exit;
		}else{
			exec_script('alert("删除失败");history.back();');exit;
		}
	}
	
	public function admin_Action($type = 'index', $id =0){
		switch ($type){
			case 'add':
				self::_adminAdd();
				break;
			case 'edit':
				self::_adminEdit($id);break;
			case 'delete':
				self::_adminDel($id);break;
			default:					
				$temp['rs'] = $this->_adminObj->select();
				$this->load_view('backend/user/admin', $temp);break;	
		}
	}
	
	private function _adminAdd(){
		if(!empty($_POST)){
			if(empty($_POST['admin'])){
				exec_script('alert("帐号不能为空");history.back();');exit;
			}
			if(empty($_POST['password'])){
				exec_script('alert("密码不能为空");history.back();');exit;
			}
			$insertArr = array('admin' => $_POST['admin'], 'addtime' => time(), 'pwd' => md5(md5($_POST['password']).SITE_KEY));
			$result = $this->_adminObj->insert($insertArr);
			if($result){
				exec_script('alert("添加成功");window.location.href="'.url(array('backend', 'user', 'admin')).'"');exit;
			}else{
				exec_script('alert("添加失败");history.back();');exit;
			}
		}
		$this->load_view('backend/user/adminadd');
	}
	
	private function _adminEdit($id = 0){
		if(!empty($_POST)){
			if(empty($_POST['password'])){
				exec_script('alert("密码不能为空");history.back();');exit;
			}
			$insertArr = array('pwd' => md5(md5($_POST['password']).SITE_KEY));
			$result = $this->_adminObj->update($insertArr, array('id' => $id));
			if($result){
				exec_script('alert("修改成功");window.location.href="'.url(array('backend', 'user', 'admin')).'"');exit;
			}else{
				exec_script('alert("修改失败");history.back();');exit;
			}
		}
		$temp['rs'] = $this->_adminObj->selectOne(array('id' => $id));
		$this->load_view('backend/user/adminedit', $temp);
	}
	
	private function _adminDel($id = 0){
		$result = $this->_adminObj->delete(array('id' => $id));
		if($result){
			exec_script('alert("删除成功");window.location.href="'.url(array('backend', 'user', 'admin')).'"');exit;
		}else{
			exec_script('alert("删除失败");history.back();');exit;
		}
	}
	
	public function ajaxdelete_Action($id = 0){
		$idArr = explode('|', urldecode($id));
		$result = $this->_userObj->delete(array('id' => $idArr));
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}

	public function ajaxverimail_Action($id = 0, $type = 0){
		$idArr = explode('|', urldecode($id));
		$result = $this->_userObj->update(array('verimail' =>$type), array('id' => $idArr));
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}

	public function ajaxverimobile_Action($id = 0, $type = 0){
		$idArr = explode('|', urldecode($id));
		$result = $this->_userObj->update(array('verimobile' =>$type), array('id' => $idArr));
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}
	
	public function ajaxstatus_Action($id = 0, $type = 0){
		$idArr = explode('|', urldecode($id));
		$result = $this->_userObj->update(array('status' =>$type), array('id' => $idArr));
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}
}