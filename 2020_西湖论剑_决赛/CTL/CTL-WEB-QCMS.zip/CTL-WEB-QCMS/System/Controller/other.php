<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Other extends Controllers{

	private $_guestObj;
	function __construct(){
		parent::__construct();
		$this->_guestObj = $this->load_model('QCMS_Guest');
	}	
	
	public function index_Action($cid = 0){
		$temp['rs'] = $this->getCateInfo($cid, 1);
		$temp['cid'] = $cid;
		$this->load_view('template/'.$this->web['tempname'].'/'.$temp['rs']['cate_temp'], $temp);
	}
}