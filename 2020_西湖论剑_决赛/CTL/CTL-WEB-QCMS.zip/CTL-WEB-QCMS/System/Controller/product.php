<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Product extends Controllers{
	public $module_id = 4;
	public $url;
	private $_newObj;
	
	function __construct(){
		parent::__construct();
		$this->_newObj = $this->load_model('QCMS_Product');
		$this->url = 'http://'.WEB_DOMAIN.$_SERVER['REQUEST_URI'];
	}	
	
	public function index_Action($cid = 0, $page = 0)	{	
		$temp['rs'] = $this->getCateInfo($cid, $this->module_id);
		$temp['cid'] = $cid;
		$temp['page'] = $page;
		$temp['module_id'] = $this->module_id;
		$this->load_view('template/'.$this->web['tempname'].'/'.$temp['rs']['cate_temp'], $temp);
	}
	
	public function detail_Action($id = 0){
		$temp['rs'] = $this->_newObj->selectOne(array('id' => $id));
		$this->_newObj->update(array('count' => ($temp['rs']['count']+1)), array('id' => $id));
		$temp['cid'] = $temp['rs']['cid'];
		$temp['cateRs'] = $this->getCateInfo($temp['rs']['cid']);
		$this->load_view('template/'.$this->web['tempname'].'/'.$temp['cateRs']['detail_temp'], $temp);
	}
}
