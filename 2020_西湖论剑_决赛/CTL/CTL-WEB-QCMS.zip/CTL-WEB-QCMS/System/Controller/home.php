<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Home extends Controllers{

	function __construct(){
		parent::__construct();
		
	}	
	
	public function _error404(){
		header('HTTP/1.1 404 Not Found'); 
		header("status: 404 Not Found");
		$this->load_view('home/err');
	}
	
	public function err_Action(){ //-- imagemagick缩略图 --
		$url = $_SERVER['REQUEST_URI'];
		$ext = substr($url, -4);
		$url_arr = explode('_', substr($url, 1, -4));
		if(count($url_arr) <2){
			header("HTTP/1.0 404 Not Found");
			self::_error404();
			exit;
		}
		$width = substr($url_arr[1], 1);
		$height = substr($url_arr[2], 1);
		$noWaterMark = empty($url_arr[3]) ? '' : $url_arr[3];
		$thumb = '';
		if(empty($noWaterMark)){
			$thumb = $url_arr[0].'_w'.$width.'_h'.$height.''.$ext;
		}elseif($noWaterMark == 'nowatermark'){
			$thumb = $url_arr[0].'_w'.$width.'_h'.$height.'_nowatermark'.$ext;
		}
		//$thumb = empty($noWaterMark) ? $url_arr[0].'_w'.$width.'_h'.$height.''.$ext : $url_arr[0].'_w'.$width.'_h'.$height.'_nowatermark'.$ext;
		$path = dirname($thumb);
		if(!is_dir($path)){
			mkdir($path, 0777);
		}
		if(empty($url_arr)){
			header("HTTP/1.0 404 Not Found");
			self::_error404();
			exit;
		}
		$filename = str_replace('thumb', 'source', $url_arr[0].$ext);	
		if(!is_file($filename)){
			header("HTTP/1.0 404 Not Found");
			self::_error404();
			exit;
		}	
		$img_width = $width;//生成图片的宽
		$imt_height = $height;//生成图片的高
		$size_arr = array('160|160', '180|180', '150|150', '50|50','78|78','540|540', '800|800', '1000|1000', '53|53', '270|270', '109|109', '145|145', '230|230', '146|146', '80|80', '160|160', '300|300', '64|64', '136|136', '102|102');
		$size = $width.'|'.$height;//获取缩略图的长和宽
		if(!in_array($size, $size_arr)){
			header("HTTP/1.0 404 Not Found");
			self::_error404();
			exit;
		}
		exec('convert -resize "'.$width.'x'.$height.'>" '.$filename.' '.$thumb.'');
		//-- 添加水印 --
		/*if(($width >= 400 && $height >= 400) && empty($noWaterMark)){
			exec('convert '.$thumb.' static/images/watermark.png -gravity southeast -gravity center -composite '.$thumb.'');
		}*/
		@header("Content-Type:image/jpeg");
		readfile($thumb);
	}
	
	public function test_Action($pwd = 0){
		!empty($pwd) || die(phpinfo());
		echo md5(md5($pwd).SITE_KEY);
	}
	
	public function server_Action(){
		var_dump($_SERVER);
	}
	
	public function alipay_Action(){
		$this->load_view('home/alipay');
	}
}