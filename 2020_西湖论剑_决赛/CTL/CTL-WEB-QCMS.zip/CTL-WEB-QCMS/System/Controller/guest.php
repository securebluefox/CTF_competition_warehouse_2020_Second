<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Guest extends Controllers{

	private $_guestObj;
	function __construct(){
		parent::__construct();
		$this->_guestObj = $this->load_model('QCMS_Guest');
	}	
	
	public function index_Action($page = 0){
		if(!empty($_POST)){
			foreach($_POST as $k => $v){
				$_POST[$k] = trim($v);
			}
			if(empty($_POST['title'])){
				exec_script('alert("标题不能为空");history.back();');exit;
			}
			if(empty($_POST['name'])){
				exec_script('alert("姓名不能为空");history.back();');exit;
			}
			if(empty($_POST['email'])){
				exec_script('alert("邮箱不能为空");history.back();');exit;
			}
			if(empty($_POST['content'])){
				exec_script('alert("留言内容不能为空");history.back();');exit;
			}
			$result = $this->_guestObj->insert(array('title' => $_POST['title'], 'name' => $_POST['name'], 'email' => $_POST['email'], 'content' => $_POST['content'], 'addtime' => time()));
			if($result){
				exec_script('window.location.href="'.url(array('guest', 'index')).'"');exit;
			}else{
				exec_script('alert("留言失败");history.back();');exit;
			}
		}
		$temp['rs'] = array('name' => '客户留言');
		$count = 0;
		$this->pageNum = 6;
		$temp['module_name'] = 'guest';
		$offset = ($page <= 0) ? 0 : ($page - 1) * $this->pageNum;
		$temp['guestRs'] = $this->_guestObj->selectAll(array($offset, $this->pageNum), $count, array());
		$temp['page'] = $this->page_bar($count[0]['count'], $this->pageNum, url(array('guest', 'index', '{page}' )), 9, $page);
		$this->load_view('template/'.$this->web['tempname'].'/guest', $temp);
	}
}