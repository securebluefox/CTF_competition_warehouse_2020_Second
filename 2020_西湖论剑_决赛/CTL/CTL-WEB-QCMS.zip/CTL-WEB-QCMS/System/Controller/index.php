<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Index extends Controllers{

	function __construct(){
		parent::__construct();
		
	}	
	
	public function index_Action()	{	
		$this->load_view('template/'.$this->web['tempname'].'/index');
	}
	
	public function area_Action($pid = 0){
		$areaObj = $this->load_model('QCMS_Area');
		$rs = $areaObj->select(array('pid' => $pid));
		echo json_encode($rs);
	}
	
}
