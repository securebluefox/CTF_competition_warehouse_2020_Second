<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?php
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?php
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?php
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a></div>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
    <div class="quick-actions_homepage">
    <h5 style="text-align:left">系统功能</h5>
      <ul class="quick-actions">
        <li class="bg_lb"> <a href="<?=url(array('backend', 'system'))?>"> <i class="icon-cog"></i>  系统设置 </a> </li>
        <li class="bg_lg span3"> <a href="<?=url(array('backend', 'category'))?>"> <i class="icon-th-list"></i> 分类管理</a> </li>
        <li class="bg_ly"> <a href="<?=url(array('backend', 'system', 'mail'))?>"> <i class="icon-inbox"></i> 邮件管理 </a> </li>
        <li class="bg_lg"> <a href="<?=url(array('backend', 'category', 'tag'))?>"> <i class="icon-calendar"></i> 标签管理</a> </li>
        <li class="bg_lr"> <a href="<?=url(array('backend', 'template', 'default'))?>"> <i class="icon-flag"></i> 模版管理</a> </li>
        <li class="bg_lo"> <a href="<?=url(array('backend', 'news'))?>"> <i class="icon-list-alt"></i> <span class="label bg_lb"><?=$news['count']?></span>新闻管理</a> </li>
        <li class="bg_ls"> <a href="<?=url(array('backend', 'product'))?>"> <i class="icon-hdd"></i> <span class="label bg_lr"><?=$product['count']?></span>产品管理</a> </li>
        <li class="bg_lo"> <a href="<?=url(array('backend', 'album'))?>"> <i class="icon-picture"></i> <span class="label bg_lh"><?=$album['count']?></span>相册管理</a> </li>
        <li class="bg_ls"> <a href="<?=url(array('backend', 'down'))?>"> <i class="icon-arrow-down"></i> <span class="label label-success"><?=$down['count']?></span>下载管理</a> </li>
        <li class="bg_lb span3"> <a href="<?=url(array('backend', 'user'))?>"> <i class="icon-user"></i><span class="label label-error"><?=$user['count']?></span>用户管理</a> </li>


      </ul>
      
    </div>
    <div class="quick-actions_homepage wxCloudMenu" style="display:none">
      <h5 style="text-align:left">微信云平台</h5>
      <ul class="quick-actions" id="wxIndexCloud"></ul>

    </div>
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
  <?php
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>

</body>
</html>
