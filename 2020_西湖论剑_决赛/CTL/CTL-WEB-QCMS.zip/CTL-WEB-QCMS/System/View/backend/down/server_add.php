<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?php
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?php
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?php
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a>
    <a href="<?=url(array('backend', Router::$s_controller))?>" class="current">服务器管理</a>
    <a href="#" class="current">服务器添加</a></div>
    <h1>服务器添加</h1>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
<hr>
<div class="row-fluid">
    <div >
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>服务器信息</h5>
        </div>
        <div class="widget-content nopadding">
          <form method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">服务器名称 :</label>
              <div class="controls">
                <input type="text" name="name" class="span6" placeholder="Server name">
              </div>
            </div>

            <div class="control-group">
              <label class="control-label">服务器地址 :</label>
              <div class="controls">
                <input type="text" name="address" class="span6" placeholder="Server address">
                </div>
            </div>
            <div class="control-group">
              <label class="control-label">排序 :</label>
              <div class="controls">
                <input type="text" name="sort" class="span2" value="99">
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-success">添加服务器</button>
            </div>
          </form>
        </div>
      </div>


    </div>

  </div>
    
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?php
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>

<!--end-Footer-part-->

</body>
</html>
