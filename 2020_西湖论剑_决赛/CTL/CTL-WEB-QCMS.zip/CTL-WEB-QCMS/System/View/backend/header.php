<div id="header">
  <h1><a href="dashboard.html"><?=$this->web['webname']?>后台管理</a></h1>
</div>
<!--close-Header-part--> 


<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li id="profile-messages" ><a title="" href="#" ><i class="icon icon-user"></i>  <span class="text">欢迎 <?=$this->name?> 回来 ！</span><b class="caret"></b></a></li>
    <li class=""><a title="" href="<?=url(array('index'))?>" target="_blank"><i class="icon icon-share-alt"></i> <span class="text">前台地址</span></a></li>
    <li class=""><a title="" href="<?=url(array('backend', 'system'))?>"><i class="icon icon-cog"></i> <span class="text">系统设置</span></a></li>
    <li class=""><a title="" href="<?=url(array('admin', 'logout', 2))?>"><i class="icon icon-off"></i> <span class="text">安全退出</span></a></li>
    
  </ul>
</div>
<!--close-top-Header-menu-->
<!--start-top-serch-->
<div id="search" style="display:none">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch-->