<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> 后台首页</a>
  <ul>
    <li class="<?=(Router::$s_controller == 'index') ? 'active' : ''?>"><a href="<?=url(array('backend', 'index'))?>"><i class="icon icon-home"></i> <span>后台首页</span></a> </li>
    
    <li class="<?=(Router::$s_controller == 'system') ? 'active' : ''?>"> <a href="<?=url(array('backend', 'system'))?>"><i class="icon icon-cog"></i> <span>系统设置</span> </a></li>
   
    <li class="<?=(Router::$s_controller == 'category') ? 'active' : ''?>"><a href="<?=url(array('backend', 'category'))?>"><i class="icon icon-th-list"></i> <span>分类管理</span> </a></li>        
    <li class="<?=(Router::$s_controller == 'news') ? 'active' : ''?>"><a href="<?=url(array('backend', 'news'))?>"><i class="icon icon-list-alt"></i> <span>新闻列表</span> </a></li>
    <li class="<?=(Router::$s_controller == 'product') ? 'active' : ''?>"><a href="<?=url(array('backend', 'product'))?>"><i class="icon icon-hdd"></i> <span>产品列表</span> </a></li>
    <li class="<?=(Router::$s_controller == 'album') ? 'active' : ''?>"><a href="<?=url(array('backend', 'album'))?>"><i class="icon icon-picture"></i> <span>相册列表</span> </a></li>
    <li class="<?=(Router::$s_controller == 'down') ? 'active' : ''?>"><a href="<?=url(array('backend', 'down'))?>"><i class="icon icon-arrow-down"></i> <span>下载管理</span> </a></li>
    <li class="<?=(Router::$s_controller == 'guest') ? 'active' : ''?>"> <a href="<?=url(array('backend', 'guest'))?>"><i class="icon icon-comment"></i> <span>留言管理</span> </span> </a>
    <li class="submenu <?=(Router::$s_controller == 'user') ? 'open' : ''?>"> <a href="#"><i class="icon icon-user"></i> <span>用户管理</span> </a>
      <ul>
        <li><a href="<?=url(array('backend', 'user'))?>">用户列表</a></li>
        <li><a href="<?=url(array('backend', 'user', 'group'))?>">用户组设置</a></li>
        <li><a href="<?=url(array('backend', 'user', 'admin'))?>">管理员设置</a></li>
      </ul>
    </li>
    <li class="submenu"> <a href="#"><i class="icon icon-fire"></i> <span>扩展管理</span> </a>
      <ul>
        <li><a href="<?=url(array('backend', 'slideshow'))?>">轮播管理</a></li>
        <li><a href="<?=url(array('backend', 'system', 'mail'))?>">邮件设置</a></li>
        <li><a href="<?=url(array('backend', 'category', 'module'))?>">模型管理</a></li>
        <li><a href="<?=url(array('backend', 'category', 'location'))?>">位置管理</a></li>
        <li><a href="<?=url(array('backend', 'category', 'tag'))?>">标签管理</a></li>
        <li><a href="<?=url(array('backend', 'down', 'server'))?>">服务器管理</a></li>
        <li><a href="<?=url(array('backend', 'template'))?>">模版列表</a></li>
        <li><a href="<?=url(array('backend', 'template', 'default'))?>">默认模版管理</a></li>
        <li><a href="<?=url(array('backend', 'template', 'code'))?>">模版标记参考</a></li>
      </ul>
    </li>
    <li class="submenu wxCloudMenu" style="display:none"> <a href="#"><i class="icon icon-globe"></i> <span>微信云平台</span> </a>
      <ul id="wxCloud">
      </ul>
    </li>
    <li><a href="<?=url(array('admin', 'logout', 2))?>"><i class="icon icon-off"></i> <span>安全退出</span> </a></li>


  </ul>
</div>