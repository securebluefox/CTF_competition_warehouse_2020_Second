<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a>
    <a href="<?=url(array('backend', Router::$s_controller))?>" class="current">模版管理</a>
    <a href="#" class="current">模版安装</a></div>
    <h1>模版安装</h1>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
<hr>
<div class="row-fluid">
    <div >
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>模版信息</h5>
        </div>
        <div class="widget-content nopadding">
          <form method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">模版选择 :</label>
              <div class="controls">
                <select name="name">
                  <?
                  foreach($rs as $k => $v){
                    echo '<option value="'.$v['name'].'">'.$v['viewFileName'].'</option>';
                  }
                  ?>
                </select>
              </div>
            </div>

            <div class="form-actions">
              <button type="submit" class="btn btn-success">安装模版</button>
            </div>
          </form>
        </div>
      </div>


    </div>

  </div>
    
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>

<!--end-Footer-part-->
<script type="text/javascript">
var pid = 1;
var areaType = 'province';
$(function(){
  getArea();
  $('#province').change(function(){
    pid = $(this).val();
    areaType = 'city';
    getArea();
  })
  $('#city').change(function(){
    pid = $(this).val();
    areaType = 'district';
    getArea();
  })
})
var getArea = function(){
  if(areaType == 'city') $('#district').html('');
  $('#'+areaType).html('');
  $.ajax({
    url : '/index/area/'+pid,
    cache : false,
    dataType : 'json',
    success: function(json){
      $('#'+areaType).append('<option value="0">请选择</option>')
      $.each(json, function(k, v){
        $('#'+areaType).append('<option value="'+v['id']+'">'+v['name']+'</option>')
      })
    }
  })
}
</script>
</body>
</html>
