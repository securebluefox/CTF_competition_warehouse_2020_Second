<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?php
$this->load_view('backend/meta');
$this->load_css('uploadify');
?>
</head>
<body>

<!--Header-part-->
<?php
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?php
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a>
    <a href="<?=url(array('backend', Router::$s_controller))?>" class="current">分类管理</a>
    <a href="#" class="current">相册添加</a></div>
    <h1>相册添加</h1>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
<hr>
<div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-picture"></i> </span>
            <h5><a href="<?=url(array('backend', 'album', 'edit', $id))?>">相册信息</a> <a href="<?=url(array('backend', 'album', 'pic', $id))?>">相册管理</a>
            
            </h5>
          </div>
          <div class="widget-content">
            <ul class="thumbnails">
            <?php
            foreach($rs as $k => $v){
              echo '<li class="span2"> <a> <img src="'.$v['path'].'" alt=""> </a>
                <div class="actions"> <a title="" class="removePic" href="javascript:void(0);" data="'.$v['id'].'"><i class="icon-remove"></i></a> <a class="lightbox_trigger" href="'.$v['path'].'"><i class="icon-search"></i></a> </div>
              </li>';
            }
            ?>
              
            
              
            </ul>

          </div><span class="label label-info" id="file_upload_1">上传图片</span>
        </div>
      </div>
    </div>
    
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?php
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
<?php
$this->load_js('jquery.uploadify.min');
?>
<script type="text/javascript">
$(function() {
  $("#file_upload_1").uploadify({
    height        : 30,
    'buttonText' : '上传',
    swf           : '/static/images/uploadify.swf',
    uploader      : '/backend/album/ajaxupload/<?=$id?>',
    width         : 120,
    'fileObjName' : 'filedata',
    'onUploadSuccess' : function(file, data, response) {
      data =  $.parseJSON(data);
      console.log(data)
        //location.reload();
        $('.thumbnails').append('<li class="span2" id=""> <a> <img src="'+ data.url +'" alt=""> </a><div class="actions"> <a title="" class="removePic" href="javascript:void(0);" data="'+ data.picId +'"><i class="icon-remove"></i></a> <a class="lightbox_trigger" href="'+ data.url +'"><i class="icon-search"></i></a> </div></li>');
    }
  });
  $('.removePic').live('click', function(){
    data = $(this).attr('data');
    $.post('<?=url(array('backend', 'album', 'picdel'))?>', {'id' : data}, function(data){
        if(data == 1){
          location.reload();
        }else{
          alert('删除失败');
        }
    })
  })
});
</script>
<!--end-Footer-part-->
</body>
</html>
