<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?php
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?php
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?php
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a><a href="#" class="current">相册管理</a>
	
    </div><h1>相册管理</h1>
  </div>

  <div class="container-fluid">
  <div class="row-fluid">
      <div class="span12 search">
        <input type="text" name="title" id="title" class="span3" placeholder="Title">
        <button type="button" class="btn btn-primary" id="searchBut">搜索</button>
      </div>
  </div>
    <hr>
    <div class="row-fluid">
      <div class="span12">
        
        <div class="widget-box">
          <div class="widget-title"> <span class="icon">
            <input type="checkbox" name="checkbox" id="selectAll" />
            </span>
            <h5>相册列表</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th><i class="icon-resize-vertical"></i></th>
                  <th>#</th>
                  <th>分类</th>
                  <th>标题</th>                  
                  <th>时间</th>
                  <th>点击量</th>              
                  <th>照片</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
              <?php
              $userTypeIcons = array();
              foreach($rs as $k => $v){
                echo '<tr>
                <td><input type="checkbox" name="id" value="'.$v['id'].'" class="selectCheckbox" /></td>
                <td>'.$v['id'].'</td>
                <td>['.$cateRs[$v['cid']]['name'].']</td>
                <td>'.$v['title'].'</td>
                
                <td>'.date('Y-m-d', $v['addtime']).'</td>
                <td>'.$v['count'].'</td>
                <td><a href="'.url(array('backend', 'album', 'pic', $v['id'])).'" class="btn btn-info btn-mini">添加照片</a></td>
                <td><a href="'.url(array('backend', 'album', 'edit', $v['id'])).'" class="btn btn-primary btn-mini">修改</a> <a href="'.url(array('backend', 'album', 'delete', $v['id'])).'" onclick="return confirm(\'是否删除?\')" class="btn btn-danger btn-mini">删除</a></td>
                </tr>';
              }
              if(!empty($page)){
                echo '<tr><td colspan="9" align="center">'.$page.'</td></tr>';
              }
              ?>
              <tr><td colspan="9">
              <a class="btn btn-primary btn-mini" href="<?=url(array('backend', 'album', 'add'))?>">添加相册</a> 
              <a class="btn btn-primary btn-mini deleteAll">批量删除</a>
              </td></tr>
              </tbody>
            </table>
          </div>
        </div>

        
      </div>
    </div>
  </div>
<!--End-breadcrumbs-->

</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?php
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
<script>
  var selectStr = '';
  $(function(){
    $('#selectAll').click(function(){
      if($('#selectAll').attr('checked') == 'checked'){
        $('.selectCheckbox').attr('checked', 'checked');
      }else{
        $('.selectCheckbox').removeAttr('checked');
        selectStr = '';
      }
    })
    $('.deleteAll').click(function(){
      selectStr = '';
      $(".selectCheckbox[type=checkbox]").each(function(){ 
        if($(this).attr('checked') == 'checked'){
          selectStr += $(this).val()+'|';
        }
      }); 
      if(selectStr == ''){
        alert('没有选中任何新闻');
        return
      }
      $.get('/backend/album/ajaxdelete/'+selectStr, {}, function(data){
          if(data == '1'){
            window.location.reload();
          }else{
            alert('删除失败');
            return
          }
      })
    })
    $('#searchBut').click(function(){
      window.location.href="/backend/album.html?title="+$('#title').val();
    })
  })
</script>
</body>
</html>
