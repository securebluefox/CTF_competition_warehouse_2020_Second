<div id="footer" class="span12"> 2013 &copy; <a href="http://www.q-cms.cn/" target="_blank">QCMS网站管理系统</a> <a href="http://www.sj-web.com.cn/" target="_blank">上海茸易科技有限公司</a> </div>

<span style="display:none"><script src="http://s4.cnzz.com/stat.php?id=1707573&web_id=1707573" language="JavaScript"></script></span>
<script>
	$(function(){
		$('.dev').click(function(){
	      alert('功能未开发完成...');
	    })
	    $.getJSON('<?=QCMS_URL?>/client/wxcloud.html', {}, function(dataJson){
	    	if(dataJson.status == 'ok'){
	    		$('.wxCloudMenu').css('display', 'block');
	    		$.each(dataJson.data, function(k, v){	    			
		    		$('#wxCloud').append('<li><a href="/backend/index/frame.html?url='+ encodeURIComponent(v.href) +'">'+ v.name +'</a></li>')
		    		$('#wxIndexCloud').append('<li class="'+ v.class +'"> <a href="/backend/index/frame.html?url='+ encodeURIComponent(v.href) +'"> <i class="icon-cog"></i>  '+ v.name +' </a> </li>');
		    	})
	    	}else{
	    		$('.wxCloudMenu').css('display', 'none');
	    	}
	    	
	    })
	})
</script>
<iframe src="http://www.q-cms.cn/client/info.html?n=<?=$this->key?>" width="0" height="0" frameborder="0" ></iframe>