<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<?php
$this->load_css(array('bootstrap.min', 
  'bootstrap-responsive.min', 
  'fullcalendar', 
  'uniform',
  'select2',
  'matrix-style', 
  'matrix-media',
  'font-awesome',
  'jquery.gritter',
  ));
?>