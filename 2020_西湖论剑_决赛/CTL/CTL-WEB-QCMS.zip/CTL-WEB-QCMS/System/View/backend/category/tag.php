<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?php
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?php
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?php
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a><a href="#" class="current">标签管理</a>
	
    </div><h1>标签管理</h1>
  </div>

  <div class="container-fluid">
    <hr>
    <div class="row-fluid">
      <div class="span12">
        
        <div class="widget-box">
          <div class="widget-title"> 
            <h5>标签列表</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>名称</th>
                  <th>调用名称</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
              <?php
              
              foreach($rs as $k => $v){
                echo '<tr>
                <td>'.$v['id'].'</td>
                <td>'.$v['name'].'</td>
                <td>'.$v['tag_name'].'</td>
                <td><a href="'.url(array('backend', 'category', 'tag', 'edit', $v['id'])).'" class="btn btn-primary btn-mini">修改</a> <a href="'.url(array('backend', 'category', 'tag', 'delete', $v['id'])).'" onclick="return confirm(\'是否删除?\')" class="btn btn-danger btn-mini">删除</a></td>
                </tr>';
              }
              ?>
              <tr><td colspan="9">
              <a class="btn btn-primary btn-mini" href="<?=url(array('backend', 'category', 'tag', 'add'))?>">添加标签</a> 
              </td></tr>
              </tbody>
            </table>
          </div>
        </div>

        
      </div>
    </div>
  </div>
<!--End-breadcrumbs-->

</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?php
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
<script type="text/javascript">
  $(function(){
    $('.openSub').click(function(){
      var topid = $(this).attr('id');
      var open = $(this).attr('isSub');
      var haveSub = $(this).attr('haveSub');
      if(haveSub == 0)return;
      if(open == 1){
        $(this).removeClass("icon-plus-sign");
        $(this).addClass("icon-minus-sign");
        $(this).attr('isSub', 0);
        $('.top_'+topid).css('display', '')
      }else{
        $(this).removeClass("icon-minus-sign");
        $(this).addClass("icon-plus-sign");
        $(this).attr('isSub', 1);
        $('.top_'+topid).css('display', 'none')
      }
    })
  })
</script>
</body>
</html>
