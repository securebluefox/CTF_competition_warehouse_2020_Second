<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?php
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?php
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?php
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a>
    <a href="<?=url(array('backend', Router::$s_controller))?>" class="current">推荐位管理</a>
    <a href="#" class="current">推荐位添加</a></div>
    <h1>推荐位添加</h1>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
<hr>
<div class="row-fluid">
    <div >
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>推荐位信息</h5>
        </div>
        <div class="widget-content nopadding">
          <form method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">模型选择 :</label>
              <div class="controls">
                <select name="module_id">
                  <?php
                  foreach($this->moduleArr as $k => $v){
                    $selected = ($module_id == $k) ? 'selected' : '';
                    echo '<option value="'.$k.'" '.$selected.'>'.$v.'</option>';
                  }
                  ?>
                </select>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">推荐位名称 :</label>
              <div class="controls">
                <input type="text" name="name" class="span6" value="">
              </div>
            </div>
            
            <div class="form-actions">
              <button type="submit" class="btn btn-success">添加推荐位</button>
            </div>
          </form>
        </div>
      </div>


    </div>

  </div>
    
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?php
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
<script type="text/javascript">
  $(function(){
    $('.islink').click(function(){
      if($(this).attr("checked") == 'checked'){
        $('.onlink').css('display', 'none');
        $('.islinkV').css('display', '');
      }else{
        $('.onlink').css('display', '');
        $('.islinkV').css('display', 'none');
      }      
    })
    var editor;
    KindEditor.ready(function(K) {
      editor = K.create('textarea[name="info"]', {
        allowFileManager : true,
        themeType : 'simple',
        urlType : 'absolute',
        uploadJson : '<?=url(array('backend', 'index', 'ajaxuploadediter'))?>',
        items : [
              'source','code','fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline',
              'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright', 'insertorderedlist',
              'insertunorderedlist', '|', 'image', 'flash', 'media','insertfile','link','unlink','|','table','fullscreen']

      })
    })
  })
</script>
<!--end-Footer-part-->
</body>
</html>