<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a>
    <a href="<?=url(array('backend', Router::$s_controller))?>" class="current">系统设置</a></div>
    <h1>系统设置</h1>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
<hr>
<div class="row-fluid">
    <div >
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>系统设置</h5>
        </div>
        <div class="widget-content nopadding">
          <form method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">网站名称 :</label>
              <div class="controls">
                <input type="text" name="webname" class="span6" placeholder="Web name" value="<?=$rs['webname']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">网站标题 :</label>
              <div class="controls">
                <input type="text" name="title" class="span6" placeholder="Title" value="<?=$rs['title']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">网站关键字 :</label>
              <div class="controls">
                <input type="text" name="keywords" class="span6" placeholder="Keywords" value="<?=$rs['keywords']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">网站描述 :</label>
              <div class="controls">
                <input type="text" name="description" class="span6" placeholder="Description" value="<?=$rs['description']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">电子邮箱 :</label>
              <div class="controls">
                <input type="text" name="email" class="span6" placeholder="Email" value="<?=$rs['email']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">备案号 :</label>
              <div class="controls">
                <input type="text" name="icp" class="span6" placeholder="Icp" value="<?=$rs['icp']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">简介 :</label>
              <div class="controls">
                <input type="text" name="info" class="span6" placeholder="Info" value="<?=htmlspecialchars($rs['info'])?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">网站LOGO :</label>
              <div class="controls">
                <input type="text" name="logo" id="logo" class="span6" placeholder="Logo" value="<?=$rs['logo']?>">
                <button type="button" id="uploadImg">上传</button>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">统计代码 :</label>
              <div class="controls">
                <input type="text" name="count" class="span6" placeholder="Count" value="<?=$rs['count']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">联系地址 :</label>
              <div class="controls">
                <input type="text" name="address" class="span6" placeholder="Address" value="<?=$rs['address']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">联系电话 :</label>
              <div class="controls">
                <input type="text" name="tel" class="span6" placeholder="Tel" value="<?=$rs['tel']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">传真号码 :</label>
              <div class="controls">
                <input type="text" name="fax" class="span6" placeholder="Fax" value="<?=$rs['fax']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">联系QQ :</label>
              <div class="controls">
                <input type="text" name="qq" class="span6" placeholder="Qq" value="<?=$rs['qq']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">当前模版 :</label>
              <div class="controls">
              <select name="template_id">
                <?
                foreach($tempRs as $k => $v){
                  $selected = ($v['id'] == $rs['template_id']) ? 'selected' : '';
                  echo '<option value="'.$v['id'].'" '.$selected.'>'.$v['name'].'</option>';
                }
                ?>
              </select>
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-success">修改设置</button>
            </div>
          </form>
        </div>
      </div>


    </div>

  </div>
    
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
<script type="text/javascript">
  $(function(){
    var button = $('#uploadImg'), interval;      
      new AjaxUpload(button, {
        action: '<?=url(array('backend', 'index', 'ajaxupload'))?>', 
        name: 'filedata',
        onSubmit : function(file, ext){
          this.disable();     
        },      
        onComplete: function(file, response){ 
          var json_str = eval("(" + response + ")");
          if(json_str.error != 0){
            this.enable();
            alert(json_str.msg);return;
          }
          window.clearInterval(interval);
          this.enable();      
          $('#logo').val(json_str.url);
        }
    });
  })
</script>
</body>
</html>
