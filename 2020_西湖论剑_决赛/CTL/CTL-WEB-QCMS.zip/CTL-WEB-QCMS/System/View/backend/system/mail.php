<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a>
    <a href="<?=url(array('backend', Router::$s_controller))?>" class="current">邮件设置</a></div>
    <h1>邮件设置</h1>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
<hr>
<div class="row-fluid">
    <div >
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>邮件设置</h5>
        </div>
        <div class="widget-content nopadding">
          <form method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">SMTP服务器 :</label>
              <div class="controls">
                <input type="text" name="smtp" class="span6" placeholder="Smtp server" value="<?=$rs['smtp']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">邮箱帐号 :</label>
              <div class="controls">
                <input type="text" name="account" class="span6" placeholder="Account" value="<?=$rs['account']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">邮箱密码 :</label>
              <div class="controls">
                <input type="password" name="password" class="span6" placeholder="Password" value="<?=$rs['password']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">发件人地址 :</label>
              <div class="controls">
                <input type="text" name="send" class="span6" placeholder="Send mail" value="<?=$rs['send']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">发件人 :</label>
              <div class="controls">
                <input type="text" name="username" class="span6" placeholder="User name" value="<?=$rs['username']?>">
              </div>
            </div>
            
            <div class="form-actions">
              <button type="submit" class="btn btn-success">修改设置</button> 
              <button type="button" class="btn btn-inverse sendTest">发送测试</button>
            </div>
          </form>
        </div>
      </div>


    </div>

  </div>
    
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
<script type="text/javascript">
  $(function(){
    $('.sendTest').click(function(){
      $.get('<?=url(array('backend', 'system', 'test'))?>', {}, function(data){
        if(data == 1){
          alert('发送成功，请查收');
        }else{
          alert('发送失败，请检查配置');
        }
      })
    })
  })
</script>
</body>
</html>
