<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a><a href="#" class="current">用户组设置</a>
	
    </div><h1>用户组设置</h1>
  </div>

  <div class="container-fluid">
    <hr>
    <div class="row-fluid">
      <div class="span12">
        
        <div class="widget-box">
          <div class="widget-title"> 
            <h5>用户组列表</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>名称</th>
                  <th>允许投稿</th>
                  <th>投稿不需审核</th>                  
                  <th>允许自助升级</th>
                  <th>允许发短消息</th>
                  <th>允许上传附件</th>
                  <th>升级价格(日/月/年)</th>
                  <th>短信数量</th>
                  <th>投稿数量</th>
                  <th>排序</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
              <?
              
              foreach($rs as $k => $v){
              $allowpost = empty($v['allowpost']) ? '<i class="icon-remove"></i>' : '<i class="icon-ok"></i>';
              $allowpostverify = empty($v['allowpostverify']) ? '<i class="icon-remove"></i>' : '<i class="icon-ok"></i>';
              $allowupgrade = empty($v['allowupgrade']) ? '<i class="icon-remove"></i>' : '<i class="icon-ok"></i>';
              $allowsendmessage = empty($v['allowsendmessage']) ? '<i class="icon-remove"></i>' : '<i class="icon-ok"></i>';
              $allowattachment = empty($v['allowattachment']) ? '<i class="icon-remove"></i>' : '<i class="icon-ok"></i>';
                echo '<tr>
                <td>'.$v['id'].'</td>
                <td>'.$v['name'].'</td>
                <td>'.$allowpost.'</td>
                <td>'.$allowpostverify.'</td>
                <td>'.$allowupgrade.'</td>
                <td>'.$allowsendmessage.'</td>
                <td>'.$allowattachment.'</td>
                <td>'.$v['price_d'].'/'.$v['price_m'].'/'.$v['price_y'].'</td>
                <td>'.$v['allowmessage'].'</td>
                <td>'.$v['allowpostnum'].'</td>
                <td>'.$v['sort'].'</td>
                <td><a href="'.url(array('backend', 'user', 'group', 'edit', $v['id'])).'" class="btn btn-primary btn-mini">修改</a> <a href="'.url(array('backend', 'user', 'group', 'delete', $v['id'])).'" onclick="return confirm(\'是否删除?\')" class="btn btn-danger btn-mini">删除</a></td>
                </tr>';
              }
              ?>
              <tr><td colspan="12">
              <a class="btn btn-primary btn-mini" href="<?=url(array('backend', 'user', 'group', 'add'))?>">添加用户组</a> 
              </td></tr>
              </tbody>
            </table>
          </div>
        </div>

        
      </div>
    </div>
  </div>
<!--End-breadcrumbs-->

</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
</body>
</html>
