<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a>
    <a href="<?=url(array('backend', Router::$s_controller))?>" class="current">用户管理</a>
    <a href="#" class="current">用户组添加</a></div>
    <h1>用户组添加</h1>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
<hr>
<div class="row-fluid">
    <div >
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>用户组信息</h5>
        </div>
        <div class="widget-content nopadding">
          <form method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">用户组名 :</label>
              <div class="controls">
                <input type="text" name="name" class="span6" placeholder="Group name">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">权限 :</label>
              <div class="controls">
                <input type="checkbox" name="allowpost" value="1">&nbsp;允许投稿&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" name="allowpostverify" value="1">&nbsp;投稿不需审核&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" name="allowupgrade" value="1">&nbsp;允许自助升级&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" name="allowsendmessage" value="1">&nbsp;允许发短消息&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" name="allowattachment" value="1">&nbsp;允许上传附件
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">升级价格 :</label>
              <div class="controls">
                包日：<input type="text" name="price_d" class="span2" value="0.00">&nbsp;&nbsp;&nbsp;&nbsp;
                包月：<input type="text" name="price_m" class="span2" value="0.00">&nbsp;&nbsp;&nbsp;&nbsp;
                包年：<input type="text" name="price_y" class="span2" value="0.00">&nbsp;&nbsp;&nbsp;&nbsp;
                
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">最大短消息数 :</label>
              <div class="controls">
                <input type="text" name="allowmessage" class="span2" value="0">&nbsp;
                0为不限制
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">最大投稿数 :</label>
              <div class="controls">
                <input type="text" name="allowpostnum" class="span2" value="0">&nbsp;
                0为不限制
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">说明 :</label>
              <div class="controls">
                <input type="text" name="description" class="span11">
                </div>
            </div>
            <div class="control-group">
              <label class="control-label">排序 :</label>
              <div class="controls">
                <input type="text" name="sort" class="span2" value="0">
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-success">添加用户组</button>
            </div>
          </form>
        </div>
      </div>


    </div>

  </div>
    
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>

<!--end-Footer-part-->
<script type="text/javascript">
var pid = 1;
var areaType = 'province';
$(function(){
  getArea();
  $('#province').change(function(){
    pid = $(this).val();
    areaType = 'city';
    getArea();
  })
  $('#city').change(function(){
    pid = $(this).val();
    areaType = 'district';
    getArea();
  })
})
var getArea = function(){
  if(areaType == 'city') $('#district').html('');
  $('#'+areaType).html('');
  $.ajax({
    url : '/index/area/'+pid,
    cache : false,
    dataType : 'json',
    success: function(json){
      $('#'+areaType).append('<option value="0">请选择</option>')
      $.each(json, function(k, v){
        $('#'+areaType).append('<option value="'+v['id']+'">'+v['name']+'</option>')
      })
    }
  })
}
</script>
</body>
</html>
