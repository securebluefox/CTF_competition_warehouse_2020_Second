<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a>
    <a href="<?=url(array('backend', Router::$s_controller))?>" class="current">用户管理</a>
    <a href="#" class="current">管理员修改</a></div>
    <h1>管理员修改</h1>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
<hr>
<div class="row-fluid">
    <div >
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>管理员信息</h5>
        </div>
        <div class="widget-content nopadding">
          <form method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">帐号 :</label>
              <div class="controls">
                <input type="text" name="admin" readonly="readonly" class="span4" value="<?=$rs['admin']?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">密码 :</label>
              <div class="controls">
                <input type="text" name="password" class="span4" placeholder="Password">
              </div>
            </div>
            
            <div class="form-actions">
              <button type="submit" class="btn btn-success">修改管理员</button>
            </div>
          </form>
        </div>
      </div>


    </div>

  </div>
    
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>

<!--end-Footer-part-->
<script type="text/javascript">
var pid = 1;
var areaType = 'province';
$(function(){
  getArea();
  $('#province').change(function(){
    pid = $(this).val();
    areaType = 'city';
    getArea();
  })
  $('#city').change(function(){
    pid = $(this).val();
    areaType = 'district';
    getArea();
  })
})
var getArea = function(){
  if(areaType == 'city') $('#district').html('');
  $('#'+areaType).html('');
  $.ajax({
    url : '/index/area/'+pid,
    cache : false,
    dataType : 'json',
    success: function(json){
      $('#'+areaType).append('<option value="0">请选择</option>')
      $.each(json, function(k, v){
        $('#'+areaType).append('<option value="'+v['id']+'">'+v['name']+'</option>')
      })
    }
  })
}
</script>
</body>
</html>
