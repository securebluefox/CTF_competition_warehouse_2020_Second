<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a><a href="#" class="current">管理员管理</a>
	
    </div><h1>管理员管理</h1>
  </div>

  <div class="container-fluid">
    <hr>
    <div class="row-fluid">
      <div class="span12">
        
        <div class="widget-box">
          <div class="widget-title"> 
            <h5>管理员列表</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>帐号</th>
                  <th>状态</th>                  
                  <th>添加时间</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
              <?
              
              foreach($rs as $k => $v){
              $sysadmin = empty($v['sysadmin']) ? '<i class="icon-remove"></i>' : '<i class="icon-ok"></i>';
              $status = empty($v['sysadmin']) ? '<span class="label label-success">正常</span>' : '<span class="label label-warning">禁用</span>';
              
                echo '<tr>
                <td>'.$v['id'].'</td>
                <td>'.$v['admin'].'</td>
                <td>'.$status.'</td>
                <td>'.date('Y-m-d H:i:s', $v['addtime']).'</td>
                <td><a href="'.url(array('backend', 'user', 'admin', 'edit', $v['id'])).'" class="btn btn-primary btn-mini">修改</a> <a href="'.url(array('backend', 'user', 'admin', 'delete', $v['id'])).'" onclick="return confirm(\'是否删除?\')" class="btn btn-danger btn-mini">删除</a></td>
                </tr>';
              }
              ?>
              <tr><td colspan="9">
              <a class="btn btn-primary btn-mini" href="<?=url(array('backend', 'user', 'admin', 'add'))?>">添加管理员</a> 
              </td></tr>
              </tbody>
            </table>
          </div>
        </div>

        
      </div>
    </div>
  </div>
<!--End-breadcrumbs-->

</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
</body>
</html>
