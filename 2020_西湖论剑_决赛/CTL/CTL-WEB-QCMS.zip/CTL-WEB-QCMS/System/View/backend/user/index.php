<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a><a href="#" class="current">用户管理</a>
	
    </div><h1>用户管理</h1>
  </div>

  <div class="container-fluid">
  <div class="row-fluid">
      <div class="span12">
        会员名：<input type="text" name="username" id="username" class="span3" placeholder="User name">
        用户组：
        <select id="selectGroup"><option value="">不限</option>
          <?
          foreach ($groupRs as $k => $v){
            echo '<option value="'.$v['id'].'">'.$v['name'].'</option>';
          }
          ?>
        </select>
        状态：<select id="selectStatus">
        <option value="">不限</option>
          <?
          $userStatusArr = array('0' => '正常', '-1' => '禁用');
          foreach ($userStatusArr as $k => $v){
            echo '<option value="'.$k.'">'.$v.'</option>';
          }
          ?>
        </select> <button type="button" class="btn btn-primary" id="searchBut">搜索</button>
      </div>
  </div>
    <hr>
    <div class="row-fluid">
      <div class="span12">
        
        <div class="widget-box">
          <div class="widget-title"> <span class="icon">
            <input type="checkbox" name="checkbox" id="selectAll" />
            </span>
            <h5>用户列表</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th><i class="icon-resize-vertical"></i></th>
                  <th>#</th>
                  <th>用户名</th>
                  <th>用户组</th>
                  <th>手机</th>
                  <th>邮箱</th>                  
                  <th>邮箱验证</th>
                  <th>手机验证</th>
                  <th>状态</th>
                  <th>注册时间</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
              <?
              $userTypeIcons = array();
              foreach($rs as $k => $v){
                echo '<tr>
                <td><input type="checkbox" name="id" value="'.$v['id'].'" class="selectCheckbox" /></td>
                <td>'.$v['id'].'</td>
                <td>'.$v['username'].'</td>
                <td>'.$groupRs[$v['group_id']]['name'].'</td>
                <td>'.$v['mobile'].'</td>
                <td>'.$v['email'].'</td>
                <td>'.(($v['verimail'] == 1) ? '<span class="label label-success">已验证</span>' : '<span class="label label-warning">未验证</span>').'</td>
                <td>'.(($v['verimobile'] == 1) ? '<span class="label label-success">已验证</span>' : '<span class="label label-warning">未验证</span>').'</td>
                <td>'.(($v['status'] == 0) ? '<span class="label label-success">正常</span>' : '<span class="label label-warning">禁用</span>').'</td>
                <td>'.date('Y-m-d', $v['addtime']).'</td>
                <td><a href="'.url(array('backend', 'user', 'edit', $v['id'])).'" class="btn btn-primary btn-mini">修改</a> <a href="'.url(array('backend', 'user', 'delete', $v['id'])).'" onclick="return confirm(\'是否删除?\')" class="btn btn-danger btn-mini">删除</a></td>
                </tr>';
              }
              if(!empty($page)){
                echo '<tr><td colspan="9" align="center">'.$page.'</td></tr>';
              }
              ?>
              <tr><td colspan="9">
              <a class="btn btn-primary btn-mini" href="<?=url(array('backend', 'user', 'add'))?>">添加用户</a> 
              <a class="btn btn-primary btn-mini deleteAll">批量删除</a>
              <a class="btn btn-primary btn-mini veriMailAll">批量验证邮箱</a>
              <a class="btn btn-primary btn-mini veriMailAllCancel">取消验证邮箱</a>
              <a class="btn btn-primary btn-mini veriMobileAll">批量验证手机</a>
              <a class="btn btn-primary btn-mini veriMobileAllCancel">取消验证手机</a>
              <a class="btn btn-primary btn-mini veriStatusAll">批量禁用用户</a>
              <a class="btn btn-primary btn-mini veriStatusAllCancel">取消禁用用户</a>
              </td></tr>
              </tbody>
            </table>
          </div>
        </div>

        
      </div>
    </div>
  </div>
<!--End-breadcrumbs-->

</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
<script>
  var selectStr = '';
  $(function(){
    $('#selectAll').click(function(){
      if($('#selectAll').attr('checked') == 'checked'){
        $('.selectCheckbox').attr('checked', 'checked');
      }else{
        $('.selectCheckbox').removeAttr('checked');
        selectStr = '';
      }
      $("input[type=checkbox][checked]").each(function(){ 
        selectStr += $(this).val()+'|';
      }); 
      console.log(selectStr); 
    })
    $('.deleteAll').click(function(){
      selectStr = '';
      $(".selectCheckbox[type=checkbox]").each(function(){ 
        if($(this).attr('checked') == 'checked'){
          selectStr += $(this).val()+'|';
        }
      }); 
      if(selectStr == ''){
        alert('没有选中任何用户');
        return
      }
      $.get('/backend/user/ajaxdelete/'+selectStr, {}, function(data){
          if(data == '1'){
            window.location.reload();
          }else{
            alert('删除失败');
            return
          }
      })
    })
    $('.veriMailAll').click(function(){
      if(selectStr == ''){
        alert('没有选中任何用户');
        return
      }
      $.get('/backend/user/ajaxverimail/'+selectStr+'/1', {}, function(data){
          if(data == '1'){
            window.location.reload();
          }else{
            alert('设置失败');
            return
          }
      })
    })
    $('.veriMailAllCancel').click(function(){
      if(selectStr == ''){
        alert('没有选中任何用户');
        return
      }
      $.get('/backend/user/ajaxverimail/'+selectStr+'/0', {}, function(data){
          if(data == '1'){
            window.location.reload();
          }else{
            alert('设置失败');
            return
          }
      })
    })
    $('.veriMobileAll').click(function(){
      if(selectStr == ''){
        alert('没有选中任何用户');
        return
      }
      $.get('/backend/user/ajaxverimobile/'+selectStr+'/1', {}, function(data){
          if(data == '1'){
            window.location.reload();
          }else{
            alert('设置失败');
            return
          }
      })
    })
    $('.veriMobileAllCancel').click(function(){
      if(selectStr == ''){
        alert('没有选中任何用户');
        return
      }
      $.get('/backend/user/ajaxverimobile/'+selectStr+'/0', {}, function(data){
          if(data == '1'){
            window.location.reload();
          }else{
            alert('设置失败');
            return
          }
      })
    })
    $('.veriStatusAll').click(function(){
      if(selectStr == ''){
        alert('没有选中任何用户');
        return
      }
      $.get('/backend/user/ajaxstatus/'+selectStr+'/-1', {}, function(data){
          if(data == '1'){
            window.location.reload();
          }else{
            alert('设置失败');
            return
          }
      })
    })
    $('.veriStatusAllCancel').click(function(){
      if(selectStr == ''){
        alert('没有选中任何用户');
        return
      }
      $.get('/backend/user/ajaxstatus/'+selectStr+'/0', {}, function(data){
          if(data == '1'){
            window.location.reload();
          }else{
            alert('设置失败');
            return
          }
      })
    })
    $('#searchBut').click(function(){
      window.location.href="/backend/user.html?username="+$('#username').val()+"&group_id="+$('#selectGroup').val()+"&status="+$('#selectStatus').val();
    })
  })
</script>
</body>
</html>
