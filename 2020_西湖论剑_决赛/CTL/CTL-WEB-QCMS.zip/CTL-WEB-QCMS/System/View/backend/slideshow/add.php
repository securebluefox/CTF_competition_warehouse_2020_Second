<!DOCTYPE html>
<html lang="zh">
<head>
<title><?=$this->web['webname']?> - 后台管理</title>
<?
$this->load_view('backend/meta');
?>
</head>
<body>

<!--Header-part-->
<?
$this->load_view('backend/header');
?>
<!--sidebar-menu-->
<?
$this->load_view('backend/lefter');
?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=url(array('backend', 'index'))?>" title="返回后台首页" class="tip-bottom"><i class="icon-home"></i> 后台首页</a>
    <a href="<?=url(array('backend', Router::$s_controller))?>" class="current">轮播管理</a>
    <a href="#" class="current">轮播添加</a></div>
    <h1>轮播添加</h1>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
<hr>
<div class="row-fluid">
    <div >
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>轮播信息</h5>
        </div>
        <div class="widget-content nopadding">
          <form method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">标题 :</label>
              <div class="controls">
                <input type="text" name="title" class="span6" value="">
              </div>
            </div>
            <div class="control-group onlink">
              <label class="control-label">连接 :</label>
              <div class="controls">
                <input type="text" name="href" class="span6" value="">
              </div>
            </div>
            <div class="control-group onlink">
              <label class="control-label">地址 :</label>
              <div class="controls">
                <input type="text" name="path" class="span6" id="path" value="">
                <button type="button" id="uploadImg">上传</button>
              </div>
            </div>
            <div class="control-group onlink">
              <label class="control-label">排序 :</label>
              <div class="controls">
                <input type="text" name="sort" class="span1" value="0">
              </div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-success">添加</button>
            </div>
          </form>
        </div>
      </div>


    </div>

  </div>
    
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
<?
  $this->load_view('backend/js');
  $this->load_view('backend/footer');
  ?>
</div>
<script type="text/javascript">
  $(function(){
    var button = $('#uploadImg'), interval;      
      new AjaxUpload(button, {
        action: '<?=url(array('backend', 'index', 'ajaxupload'))?>', 
        name: 'filedata',
        onSubmit : function(file, ext){
          this.disable();     
        },      
        onComplete: function(file, response){ 
          var json_str = eval("(" + response + ")");
          if(json_str.error != 0){
            this.enable();
            alert(json_str.msg);return;
          }
          window.clearInterval(interval);
          this.enable();      
          $('#path').val(json_str.url);
        }
    });


    })

</script>
<!--end-Footer-part-->
</body>
</html>
