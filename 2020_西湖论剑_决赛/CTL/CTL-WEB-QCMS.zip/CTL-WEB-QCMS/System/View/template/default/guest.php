<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$rs['name']?> - <?=$this->web['webname']?></title>
    <meta name="keywords" content="<?=$rs['keywords']?>" />
    <meta name="description" content="<?=$rs['description']?>" />
    <!-- Bootstrap -->
    <link href="<?=BOOT_PATH?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=$this->web['tempUrl']?>styles/default.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body> 
    <?=$this->view('header')?>


    <div class="container newslist" style="padding-top:20px">
    
    <div class="row">

      <div class="col-md-9 col-xs-12 min-height">
      <div class="bs-docs-section">
      <?php
      foreach($guestRs as $k => $v){
      ?>
      <blockquote>
  <p><?=$v['title']?></p>
  <footer><?=$v['content']?><br><br><?=$v['name']?> <cite ><?=date('Y-m-d H:i:s', $v['addtime'])?></cite></footer>
</blockquote>
<?php
}
?>
<ul class="pagination pull-center">
  <?=$page?>
</ul>
</div>

<div class="btn-group dropup col-xs-12" style="margin-bottom:20px">
  <form role="form" method="post">
    <fieldset>
      <div id="legend" class="">
        <legend class=""><?=$rs['name']?></legend>
      </div>
    <div class="control-group">

          <!-- Text input-->
          <label class="control-label" for="input01">标题</label>
          <div class="controls">
            <input type="text" placeholder="Title" name="title" class="form-control">
            <p class="help-block"></p>
          </div>
        </div>

    <div class="control-group">

          <!-- Text input-->
          <label class="control-label" for="input01">姓名</label>
          <div class="controls">
            <input type="text" placeholder="Name" name="name" class="form-control">
            <p class="help-block"></p>
          </div>
        </div>

    <div class="control-group">

          <!-- Text input-->
          <label class="control-label" for="input01">邮箱</label>
          <div class="controls">
            <input type="text" placeholder="Email" name="email" class="form-control">
            <p class="help-block"></p>
          </div>
        </div>

    <div class="control-group">

          <!-- Textarea -->
          <label class="control-label">内容</label>
          <div class="controls">
            <div class="textarea">
                  <textarea type="" name="content" class="form-control" style="height:150px"> </textarea>
            </div>
          </div>
        </div>

    <div class="control-group">
          <label class="control-label"></label>

          <!-- Button -->
          <div class="controls">
            <button type="submit" class="btn btn-success">提交留言</button>
          </div>
        </div>

    </fieldset>
  </form></div>

      </div>
      <?=$this->view('sidebar')?>

      



    </div>
    </div>

    <?=$this->view('footer')?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?=BOOT_PATH?>js/bootstrap.min.js"></script>
  </body>
</html>