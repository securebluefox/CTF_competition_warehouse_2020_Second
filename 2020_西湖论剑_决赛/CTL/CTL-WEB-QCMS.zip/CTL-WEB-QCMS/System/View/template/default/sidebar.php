<div class="col-md-3 col-xs-12"><h3>新闻列表</h3>
<ul>
      <?php
      foreach($this->getNews(1, 6) as $k => $v){
     echo '<li><a href="'.url(array('news', 'detail', $v['id'])).'"><i class="icons-dian"></i>'.utf8Substr($v['title'], 0, 20).'</a></li>';
}
?></ul>
      </div>