<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$rs['name']?> - <?=$this->web['webname']?></title>
    <meta name="keywords" content="<?=$rs['keywords']?>" />
    <meta name="description" content="<?=$rs['description']?>" />
    <!-- Bootstrap -->
    <link href="<?=BOOT_PATH?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=$this->web['tempUrl']?>styles/default.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body> 
    <?=$this->view('header')?>


        <div class="container albums" style="padding-top:20px">
    <h3 style="padding-bottom:10px;"><?=$rs['name']?></h3>
    <div class="row min-height">
<?php
      $pageHtml = '';
      foreach($this->getNews($cid, 16, 3, $page, url(array('album', 'index', $cid, '{page}')), $pageHtml) as $k => $v){
      ?>
      <div class="col-md-3 col-xs-6""><a href="<?=url(array('album', 'detail', $v['id']))?>" class="thumbnail"><img src="<?=$v['img']?>" class="img-rounded"><?=utf8Substr($v['title'], 0, 16)?></a>
        </div>

        <?php
}
?>
    </div><ul class="pagination pull-center">
  <?=$pageHtml?>

</ul>
    </div>

    <?=$this->view('footer')?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?=BOOT_PATH?>js/bootstrap.min.js"></script>
  </body>
</html>