<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$rs['name']?> - <?=$this->web['webname']?></title>
    <meta name="keywords" content="<?=$rs['keywords']?>" />
    <meta name="description" content="<?=$rs['description']?>" />
    <!-- Bootstrap -->
    <link href="<?=BOOT_PATH?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=$this->web['tempUrl']?>styles/default.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body> 
    <?=$this->view('header')?>


    <div class="container newslist" style="padding-top:20px">
    
    <div class="row">

      <div class="col-md-9 min-height"><h3><?=$rs['name']?></h3>
      <ul>
      <?php
      $pageHtml = '';
      foreach($this->getNews($cid, 15, 2, 1, url(array('news', 'index', $cid, $page)), $pageHtml) as $k => $v){
        $downListArr = json_decode($v['downfiles'], true);
      ?>
      <li style="padding-top:10px;padding-bottom:10px;line-height:20px;"><a href="<?=$downListArr[0]?>" target="_blank" class="btn btn-success pull-right btn-xs"><span class="whiteColor">下载</span></a>
      <span style="height:60px;float:left;"><img src="<?=$v['img']?>" style="padding-right:20px"></span>
      <a href="<?=url(array('download', 'detail', $v['id']))?>" style="font-weight:bolder; color:#000"><?=$v['title']?></a>
      <br>星级：<?=$v['score']?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;下载次数：<?=$v['count']?><br>软件大小：<?=$v['size']?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;发布日期：<?=date('Y-m-d', $v['addtime'])?>
      </li>
<?php
}
?></ul>
<ul class="pagination pull-center">
  <?=$pageHtml?>
</ul>
      </div>
      <?=$this->view('sidebar')?>

      



    </div>
    </div>

    <?=$this->view('footer')?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?=BOOT_PATH?>js/bootstrap.min.js"></script>
  </body>
</html>