<div class="container-fluid menuBg navbar-inverse ">
      <div class="header container">
      <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a href="/" class="navbar-brand logo"><?=$this->web['webname']?></a>
        </div>


        
        <div class="menu collapse navbar-collapse" id="navbar"><ul class="nav navbar-nav">
        <?php
        foreach($this->getMenu('asc') as $k => $v){
          if(Router::$s_controller == 'index'){ //-- 首页第一个选中 --
            $selected = empty($v['sort']) ? 'class="act"' : '';
          }elseif(Router::$s_controller == 'guest' && strpos($v['link'],'guest')){ //-- 留言选中 --
            $selected = 'class="act"';
          }else{
            if(!empty($cid) && $cid == $v['id']){
              $selected = 'class="act"';
            }else{
              $selected = '';
            }
          }
          
          $menuUrl = ($v['islink'] == 1) ? $v['link'] : url(array($this->moduleArrUrl[$v['module_id']], 'index', $v['id']));
          echo '<a '.$selected.' href="'.$menuUrl.'">'.$v['name'].'</a>';
        }
        ?></ul>
        </div>
      </div>
    </div>