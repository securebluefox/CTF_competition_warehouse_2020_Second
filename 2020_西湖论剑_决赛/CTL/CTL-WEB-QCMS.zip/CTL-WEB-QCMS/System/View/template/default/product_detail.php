<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$rs['title']?> - <?=$this->web['webname']?></title>
    <meta name="keywords" content="<?=$rs['keywords']?>" />
    <meta name="description" content="<?=$rs['description']?>" />

    <!-- Bootstrap -->
    <link href="<?=BOOT_PATH?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=$this->web['tempUrl']?>styles/default.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body> 
    <?php
    require('header.php');
    ?>


    <div class="container newslist" style="padding-top:20px">
    
    <div class="row">

      <div class="col-md-9"><h1 style="margin-bottom:20px;"><?=$rs['title']?></h1>
      <div class="new-detail min-height">
      <div class="row" style="margin-top:20px;margin-bottom:20px;">
        <div class="col-md-4 thumbnail"><img src="<?=$rs['img']?>"></div>
        <div class="col-md-8" style="line-height: 40px;"><ul>
        <li>产品描述 ：<?=$rs['info']?></li>
        <li>产品编号 ：<?=$rs['sn']?></li>
        <li>市 场 价 ：<?=$rs['market_price']?></li>
        <li>销售价格 ：<?=$rs['price']?></li>
        <li><a class="btn btn-success" href="<?=url(array('other', 'index', 14))?>"><span class="whiteColor">我要购买</span></a>&nbsp;&nbsp;<a class="btn btn-info" href="<?=url(array('guest', 'index'))?>"><span class="whiteColor">我要咨询</span></a></li>
        </ul></div>
      </div>
        <?=$rs['content']?>
      </div>

      </div>
      <?=$this->view('sidebar')?>
    </div>
    </div>

    <?php
    require("footer.php");
    ?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?=BOOT_PATH?>js/bootstrap.min.js"></script>
  </body>
</html>