<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$rs['title']?> - <?=$this->web['webname']?></title>
    <meta name="keywords" content="<?=$rs['keywords']?>" />
    <meta name="description" content="<?=$rs['description']?>" />
    <!-- Bootstrap -->
    <link href="<?=BOOT_PATH?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=$this->web['tempUrl']?>styles/default.css" rel="stylesheet">
    <link rel="stylesheet" href="<?=JS_PATH?>fancybox/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body> 
    <?=$this->view('header')?>


        <div class="container albums" style="padding-top:20px">
    <h1><?=$rs['title']?></h1>
    <p style="line-height:60px;color:#666">日期 ：<?=date('Y-m-d H:i', $rs['addtime'])?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;来自 ：<?=$this->web['webname']?></p>
    <div class="row min-height">
<?php
      $pageHtml = '';
      foreach($album as $k => $v){
      ?>
      <div class="col-md-3 col-xs-6 "><a href="<?=$v['path']?>" class="fancybox thumbnail" rel="group"><img src="<?=$v['path']?>" width="200px" height="150px" class="img-rounded"><?=utf8Substr($v['filename'], 0, 16)?></a>
        </div>

        <?php
}
?>
    </div><ul class="pagination pull-center">
  <?=$pageHtml?>
</ul>
    </div>

    <?=$this->view('footer')?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="<?=JS_PATH?>fancybox/jquery.fancybox.pack.js?v=2.1.5"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?=BOOT_PATH?>js/bootstrap.min.js"></script>
    <script type="text/javascript">
    $(function(){
      $(".fancybox").fancybox();
    })
    </script>
  </body>
</html>