<div class="container-fluid footer" style="padding-top:20px">
      关于 <a href="http://www.q-cms.cn" target="_blank">QCMS网站管理系统 <?=$this->web['version']?></a> 服务条款 隐私权保护 <br>
Copyright © 2008 - 2014 QCMS Inc. All Rights Reserved<br>
<a href="http://www.sj-web.com.cn" target="_blank">茸易科技</a> 版权所有
    </div>