<!DOCTYPE html>
<html lang="zh-CN">
<head>
<title>404错误 - <?= $this->web['webname'] ?></title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<?php
$this->load_css(array('bootstrap.min', 
  'bootstrap-responsive.min', 
  'fullcalendar', 
  'uniform',
  'select2',
  'matrix-style', 
  'matrix-media',
  'font-awesome',
  'jquery.gritter',

  ));
?>
<style type="text/css">
  #content_err {
background: none repeat scroll 0 0 #eeeeee;
margin-left: 0px;
margin-right: 0;
padding-bottom: 25px;
position: relative;
min-height: 100%;
width: auto;
}
</style>
</head>
<body>

<div id="content_err">
  <div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Sample pages</a> <a href="#" class="current">Error</a> </div>
    <h1>Error 404</h1>
  </div>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
            <h5>404 错误页面</h5>
          </div>
          <div class="widget-content">
            <div class="error_ex">
              <h1>404</h1>
              <h3>你访问了一个不存在的页面</h3>
              <p>这个页面已经不存在，可能已经被删除，错误过期,这种事情在本站通常很少发生...</p>
              <a class="btn btn-warning btn-big"  href="<?=url()?>">返回首页</a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
