<?php

return array(
    'payment_code' => 'offline',
    'payment_name' => '货到付款',
    'payment_desc' => '货到付款',
    'payment_is_online' => '1',
    'payment_platform' => 'pc', #支付平台 pc h5 app
    'payment_author' => '长沙德尚',
    'payment_website' => 'http://www.alipay.com',
    'payment_version' => '1.0',
    'payment_config' => array(
    ),
);
?>
