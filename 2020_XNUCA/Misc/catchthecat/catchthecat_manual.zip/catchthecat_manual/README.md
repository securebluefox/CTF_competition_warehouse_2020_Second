Explore the maze and catch the cat.
The cat may flash several times.
Enjoy.
