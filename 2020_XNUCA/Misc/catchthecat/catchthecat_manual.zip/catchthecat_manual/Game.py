#!/usr/bin/python -u
import json
import pickle
import random
import time
import sys
from GenerateMap import *
import copy

"""
NOTHING = 0
WALL = 1
BOMB = 2
CAT = 3
PERSON = 4
"""
with open("config.json") as f:
    configs = json.load(f)

DEBUG = configs['DEBUG']
FLAGPATH = configs['FLAGPATH']

directions = ['u', 'd', 'l', 'r']

def randint(start, end):
    m = end - start + 1
    return random.getrandbits(16) % m + start
    
    

class Game:
    def __init__(self, pathtomap = './map'):
        with open(pathtomap) as f:
            self.map = pickle.load(f)
        self.n = len(self.map)
        seed = int(time.time())
        random.seed(seed)
        self.x = 1
        self.y = 1
        self.cx = 0
        self.cy = 0
        self.count = 0
        self.placeCat(firsttime = True)
        self.time = 0

    def printmap(self):
        tmpmap = copy.deepcopy(self.map)
        tmpmap[self.x][self.y] = PERSON
        tmpmap[self.cx][self.cy] = CAT
        printm(tmpmap)
        
    def placeCat(self, firsttime = False):
        tmpmap = copy.deepcopy(self.map)
        tmpmap[self.x][self.y] = PERSON
        tmpmap[self.cx][self.cy] = CAT
        if firsttime:
            i = self.n - 2
            j = self.n - 2
            while tmpmap[i][j] != NOTHING:
                i -= 1
                j -= 1
            self.cx = i
            self.cy = j
    
        else:
            i = randint(1, self.n - 2)
            j = randint(1, self.n - 2)
            while tmpmap[i][j] != NOTHING:
                i = randint(1, self.n - 2)
                j = randint(1, self.n - 2)
            self.cx = i
            self.cy = j

    def move(self, c, p):
        self.time += 1
        if self.time > 4000:
            print "DARKFLAMEMASTER"
            sys.exit(-1)
        tmpmap = copy.deepcopy(self.map)
        tmpmap[self.x][self.y] = PERSON
        tmpmap[self.cx][self.cy] = CAT

        if p == PERSON:
            x = self.x
            y = self.y
        elif p == CAT:
            x = self.cx
            y = self.cy
        else:
            pass

        if c == 'u':
            y -= 1
        elif c == 'd':
            y += 1
        elif c == 'l':
            x -= 1
        elif c == 'r':
            x += 1
        else:
            pass
        
        if p == PERSON:
            if tmpmap[x][y] == WALL:
                print "WALL."
                return False
            elif tmpmap[x][y] == BOMB:
                print "BOMB."
                sys.exit(-1)
            elif tmpmap[x][y] == CAT:
                self.count += 1
                if self.count == 10:
                    with open(FLAGPATH) as f:
                        res = f.read()
                    print res
                    sys.exit(-1)
                self.x = x
                self.y = y
                self.placeCat()
                print "Caught!"
                return True
            else:
                self.x = x
                self.y = y
                print "OK."
                return True
                
        elif p == CAT:
            if tmpmap[x][y] == NOTHING:
                self.cx = x
                self.cy = y
                return True
            else:
                return False

        else:
            pass
    
    def start(self):
        while True:
            for _ in range(3):
                direction = raw_input()
                if direction not in directions:
                    sys.exit(-1)
                self.move(direction, PERSON)
                if DEBUG:
                    self.printmap()
            if DEBUG:
                print 'MOV END.'
            for _ in range(2):
                choice = randint(0, 3)
                direction = directions[choice]
                randcount = 0
                while self.move(direction, CAT) == False:
                    choice = randint(0, 3)
                    direction = directions[choice]
                    randcount += 1
                    if randcount == 10:
                        break
                if DEBUG:
                    self.printmap()

def main():
    game = Game()
    game.start()

if __name__ == "__main__":
    main()
