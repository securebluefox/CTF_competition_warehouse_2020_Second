# README

- ParseC is a simple C interpreter
- `example` is a sample for this ParseC
- You will give your source code file in base64 to remote server