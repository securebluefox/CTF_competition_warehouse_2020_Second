#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <seccomp.h>
#include <linux/seccomp.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdint.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/prctl.h>
#include <signal.h>

#define MULTI

// #define DEBUG
#define mfence() __asm__ __volatile__("mfence" \
                                      :        \
                                      :        \
                                      : "memory")
#define KEYLENGTH 128

void *shared;
int randfd;

int pipefd[2];

#ifdef MULTI
int cpus;
#endif

void prepare()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stderr, 0, 2, 0);
    prctl(PR_SET_PDEATHSIG, SIGKILL);
    pipe(pipefd);
    randfd = open("/dev/urandom", O_RDONLY);
    if (randfd < 0)
    {
#ifdef DEBUG
        printf("RandErr.\n");
#endif
        exit(0);
    }
#ifdef MULTI
    cpus = sysconf(_SC_NPROCESSORS_CONF);
    printf("cpus: %d\n", cpus);
    if(cpus < 2){
        printf("Need 2 or more cores.\n");
        exit(0);
    }
#endif
    alarm(60);
}

#ifdef MULTI
void usecpu(int idx){
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(idx, &mask);
    if (sched_setaffinity(0, sizeof(mask), &mask) == -1){
        printf("Set CPU affinity failure, ERROR: %s\n", strerror(errno));
        exit(0);
    }
}
#endif

void do_seccomp()
{
    scmp_filter_ctx ctx;
    ctx = seccomp_init(SCMP_ACT_KILL);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(close), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0);
    if(seccomp_load(ctx) < 0){
        printf("seccompErr.\n");
        exit(0);
    }
}

uint64_t urand()
{
    uint64_t result;
    int l = read(randfd, &result, 8);
    if (l < 0)
    {
#ifdef DEBUG
        printf("RandErr.\n");
#endif
        exit(0);
    }
    return result;
}

void flag(){
    char flagpath[200];
    int tmpl = readlink("/proc/self/exe", flagpath, 200);
    if(tmpl < 0 || tmpl == 200){
        printf("readlinkErr.\n");
        exit(-1);
    }
    for(int __i = tmpl - 1; __i >= 0; __i --){
        if(flagpath[__i] == '/'){
            flagpath[__i] = '\0';
            break;
        }
    }
    flagpath[tmpl] = '\0';
    if(strlen(flagpath) > 200 - 6){
        printf("pathlenErr.\n");
        exit(-1);
    }
    strcat(flagpath, "/flag");
    int flagfd = open(flagpath, O_RDONLY);
    char tmpbuf[100];
    memset(tmpbuf, 0, 100);
    read(flagfd, tmpbuf, 99);
    close(flagfd);
    printf("%s\n", tmpbuf);
}

void readn(int fd, uint8_t *mem, uint64_t length){
    int64_t tmp = 0;
    uint64_t i = 0;
    while(i < length){
        tmp = read(fd, mem + i, length - i);
        if(tmp <= 0){
            printf("readErr.\n");
            exit(-1);
        }
        i += tmp;
    }
}

int main()
{
    prepare();

    shared = mmap(NULL, 4096, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

    pid_t pid = fork();
    if (pid < 0)
    {
#ifdef DEBUG
        printf("ForkErr.\n");
#endif
        exit(0);
    }
    else if (pid == 0)
    {
        // This process is hacker's space
        prctl(PR_SET_PDEATHSIG, SIGKILL);
        readn(0, shared, 4094);
        int i = 0;
        pid_t execpid;
        close(pipefd[0]);
        while (1)
        {
#ifdef DEBUG
            printf("Fork!%d\n", i);
#endif
            execpid = fork();
            if (execpid == -1)
            {
#ifdef DEBUG
                printf("ForkErr.\n");
#endif
                exit(0);
            }
            else if (execpid == 0)
            {
                prctl(PR_SET_PDEATHSIG, SIGKILL);
#ifdef MULTI
                usecpu(cpus - 1);
#endif
                do_seccomp();
                uint64_t targetaddr = (uint64_t)shared + (i % 2) * ((4096 - 2) / 2);
                __asm__(
                    "mov $0xdeadbeefdeadbeef, %%rax\n\t"
                    "mov $0xdeadbeefdeadbeef, %%rbx\n\t"
                    "mov $0xdeadbeefdeadbeef, %%rcx\n\t"
                    "mov $0xdeadbeefdeadbeef, %%rdi\n\t"
                    "mov $0xdeadbeefdeadbeef, %%rsi\n\t"
                    "mov $0xdeadbeefdeadbeef, %%r8\n\t"
                    "mov $0xdeadbeefdeadbeef, %%r9\n\t"
                    "mov $0xdeadbeefdeadbeef, %%r10\n\t"
                    "mov $0xdeadbeefdeadbeef, %%r11\n\t"
                    "mov $0xdeadbeefdeadbeef, %%r12\n\t"
                    "mov $0xdeadbeefdeadbeef, %%r13\n\t"
                    "mov $0xdeadbeefdeadbeef, %%r14\n\t"
                    "mov $0xdeadbeefdeadbeef, %%r15\n\t"
                    "jmp *%%rdx\n\t"
                    :
                    :"d"(targetaddr)
                    :
                );
                exit(0);
            }
            else
            {
                waitpid(execpid, NULL, 0);
            }
            i++;
        }
    }
    else
    {
        // This process is handler.
        char key[KEYLENGTH];
        int i = 0;
        uint64_t offset;
        read(randfd, key, KEYLENGTH);
        close(pipefd[1]);
#ifdef MULTI
        usecpu(0);
#endif
        for (i = 0; i < KEYLENGTH; i++)
        {
            printf("Round:\t%d\n", i);
            offset = urand() % (4096 - 2 - 8);
            offset &= 0xfffffffffffffff8;

#ifdef DEBUG
            printf("Key:\t%hu\n", (uint8_t)key[i]);
            printf("Change:\t%d\n", offset);
            uint64_t *saved = (uint64_t *)((char *)shared + offset);
            mfence();
            printf("Before:\t%llx\n", *saved);
            mfence();
            printf("------------\n");
#endif
            *((uint8_t *)shared + 4094) = 0;
            while (1)
            {
                if (*((char *)shared + 4095) == key[i])
                {
                    mfence();
                    *(uint64_t *)((char *)shared + offset) = 0xcccccccccccccccc;
                    break;
                }
            }
            mfence();
            while (*((uint8_t *)shared + 4094) != 1)
                ;
            mfence();
#ifdef DEBUG
            printf("After:\t%llx\n", *saved);
            printf("------------\n\n\n");
#endif
            mfence();
        }
        
        char answer[KEYLENGTH];
        memset(answer, 0, KEYLENGTH);
        read(pipefd[0], answer, KEYLENGTH);
        if (memcmp(key, answer, KEYLENGTH) == 0)
        {
            printf("SUCCEED\n");
            flag();
        }
        else
        {
            printf("FAIL\n");
        }
        exit(0);
    }

    return 0;
}
