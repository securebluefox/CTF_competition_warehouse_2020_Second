#!/usr/bin/python3 -u
import os
import sys
import signal
import subprocess
import timeout_decorator

from verify_client import verify

def assertnonexist():
    tmpres = os.popen('ps -ef | grep defile | grep -v grep | grep -v socat | grep -v python | grep -v /bin/sh').read()
    if 'defile' in tmpres:
        print("PROCESS ALREADY EXISTS.")
        sys.exit(-1)


@timeout_decorator.timeout(100)
def main():
    binarypath = os.path.join(os.path.split(os.path.realpath(__file__))[0], 'defile')
    assertnonexist()
    p = subprocess.Popen([binarypath], stderr=subprocess.PIPE)
    p.wait()

@timeout_decorator.timeout(5)
def inputtoken():
    token=sys.stdin.read(32)
    return token

if __name__ == '__main__':
    assertnonexist()
    print("INPUT YOUR TOKEN:")
    try:
        token = inputtoken()
    except timeout_decorator.timeout_decorator.TimeoutError:
        print('INPUTTIMEOUT.')
        sys.exit(-1)
    tokenok = False
    try:
        tokenok = verify(token)
    except Exception:
        print("CONTACT ME.")
        sys.exit(-1)
    if tokenok:
        try:
            main()
        except timeout_decorator.timeout_decorator.TimeoutError:
            print('MAIN TIMEOUT.')
            sys.exit(-1)
    else:
        print("Too frequent connections or token not in team list.")
