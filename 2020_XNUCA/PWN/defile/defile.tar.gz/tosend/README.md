What a shame that such beautiful shellcode is defiled by stupid patches!
Try to write some robust code.
Enjoy.
