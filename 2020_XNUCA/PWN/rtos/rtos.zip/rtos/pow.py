#!/usr/bin/env python
# coding: utf-8
from __future__ import print_function
import sys, random, string, struct
from hashlib import sha256
import shutil
import datetime
import subprocess
import time
import select
import socket
import os

def proof_of_work_okay(chall, solution, hardness):
    h = sha256(chall.encode('ASCII') + struct.pack('<Q', solution)).hexdigest()
    return int(h, 16) < 2**256 / hardness

def random_string(length = 10):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def solve_proof_of_work(task):
    hardness, task = task.split('_')
    hardness = int(hardness)

    ''' You can use this to solve the proof of work. '''
    print('Creating proof of work for {} (hardness {})'.format(task, hardness))
    i = 0
    while True:
        if i % 1000000 == 0: print('Progress: %d' % i)
        if proof_of_work_okay(task, i, hardness):
            return i
        i += 1


def launch_binary():
    print("loading binary")
    rand_str = datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S") + random_string(0x18)
    sd_bin = os.path.join("bins", sha256(rand_str.encode('ASCII')).hexdigest() + ".bin")
    shutil.copyfile("sd.bin", sd_bin)
    print("copy binary to {}".format(sd_bin))
    cmdline = ["qemu-system-arm", "-M", "vexpress-a9", "-smp", "cpus=2", "-kernel", "binary.bin", "-nographic", "-sd", sd_bin, "-net", "nic", "-serial", "mon:stdio", "-monitor", "/dev/null"]
    proc = subprocess.Popen(cmdline, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    print(' '.join(cmdline))
    proc = subprocess.Popen(cmdline, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(2)
    try:
        for i in range(5):
            print(proc.stdout.readline().decode("utf-8").strip())
        content = input()
        content += '\n'
        content = content.encode('utf-8')
        print("writing {}".format(content))
        proc.stdout.flush()
        proc.stdin.write(content.encode('utf-8'))
        proc.stdin.flush()
        time.sleep(2)
        #print(proc.stdout.readline().decode("utf-8").strip())
        print(proc.stdout.read())
    except Exception as e:
        print("over")
    proc.kill()

    time.sleep(2)
    # clean file
    if os.path.exists(sd_bin):
        os.remove(sd_bin)


def launch_service(hardness):
    challenge = random_string()
    print(' You may run the following to solve:')
    print()
    print('    ./pow.py {}_{}'.format(hardness, challenge))
    print(' ======================================')
    print()

    print('Proof of work challenge: {}_{}'.format(hardness, challenge))
    sys.stdout.write('Your response? ')
    sys.stdout.flush()
    sol = int(input())
    if not proof_of_work_okay(challenge, sol, hardness):
        print('Wrong :(')
        exit(1)
    else:
        launch_binary()


if __name__ == '__main__':
    if sys.version[0] == '2':
        input = raw_input
    # for test
    #launch_binary()

    if len(sys.argv) > 1 and sys.argv[1] == 'ask':
        hardness = int(sys.argv[2])
        launch_service(hardness)
    """
    else:
        if len(sys.argv) > 1:
            challenge = sys.argv[1]
        else:
            sys.stdout.write('Challenge? ')
            sys.stdout.flush()
            challenge = input()
        print('Solution: {}'.format(solve_proof_of_work(challenge)))
    """
