
qemu-system-arm -M vexpress-a9 -smp cpus=2 \
	-kernel binary.bin \
	-nographic -sd sd.bin -net nic \
	-serial mon:stdio \
	-monitor /dev/null

#	-serial mon:stdio
#	-serial /dev/null
