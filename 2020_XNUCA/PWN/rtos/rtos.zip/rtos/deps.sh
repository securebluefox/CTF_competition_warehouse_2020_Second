
# test on ubuntu 20

# install
sudo update
sudo apt install qemu-system-arm socat

