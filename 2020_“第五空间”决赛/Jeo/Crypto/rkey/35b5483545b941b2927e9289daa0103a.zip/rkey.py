flag=open("flag","r").read()
import os
import random
import hashlib
from Crypto.Util.number import bytes_to_long,long_to_bytes
from Crypto.Cipher import AES

def init(r):
    sl=[]
    for _ in range(624):
        x=os.urandom(4)
        sl.append(bytes_to_long(x))
    st = (3, tuple(sl + [0]), None)
    r.setstate(st)
    
def gsu(r):
    return r.getstate()[1][-1] % 624

def ss(r,sl,u):
    s = (3, tuple(sl + [u]), None)
    r.setstate(s)

def gsl(r):
    return r.getstate()[1][:-1]

def renc(r,rkey):
    sl=gsl(r)
    su=gsu(r)
    nsl=[]
    for i in sl:
        nsl.append(i^rkey)
    ss(r,nsl,su)


if __name__ == "__main__":
    init(random)
    for _ in range(624):
        print(random.getrandbits(32),end=",")
        renc(random,_%256)
    key=long_to_bytes(random.getrandbits(128))
    h=AES.new(key,AES.MODE_ECB)
    print(h.encrypt(flag.encode().zfill(48)).hex())