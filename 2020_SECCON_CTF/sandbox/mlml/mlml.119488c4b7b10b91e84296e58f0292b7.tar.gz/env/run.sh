#!/bin/sh

cd /home/user/env
python3.7 -u run.py
