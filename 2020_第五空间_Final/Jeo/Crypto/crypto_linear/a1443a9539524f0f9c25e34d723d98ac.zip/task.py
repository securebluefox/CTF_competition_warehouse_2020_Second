import random
from secret import flag
from Crypto.Util.number import getPrime
from hashlib import sha256

N = 128
assert flag.startswith(b"flag{")
assert flag.endswith(b"}")
assert sha256(flag.encode()).hexdigest() == '8caec5369a599ff47c3d6c5eae18213fb154a6f301351dd18658cfde91e5b4f8'


def lfsr(R, mask):
    feedback = R & mask
    feed_bit = bin(feedback)[2:].count("1") & 1
    output_bit = R & 1
    state = (R >> 1) | (feed_bit << (N - 1))
    return state, output_bit

def gen_lcg(bit_length):
    m = getPrime(bit_length)
    a = random.randint(1, m)
    b = random.randint(1, m)
    return (a, b, m)

def next(state, a, b, m):
    return (a * state + b) % m

def leak(seed, a, b, m):
    state = seed
    for i in range(32):
        state = next(state, a, b, m)
        print(str(state>>128))

def main():
    outputs = ''
    state = getPrime(N)
    print(state)
    mask = int(flag[5:-1], 16)
    assert mask.bit_length() == N
    for _ in range(237):
        state, output_bit = lfsr(state, mask)
        outputs += str(output_bit)
    seed = int(outputs, 2)
    a, b, m = gen_lcg(2*N)
    print(a)
    print(b)
    print(m)
    seed = next(seed, a, b, m)
    leak(seed, a, b, m)

main()

