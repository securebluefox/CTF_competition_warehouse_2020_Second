./qemu-mipsel-static -L ./ ./pwn3
