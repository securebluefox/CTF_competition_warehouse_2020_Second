安装说明

1. 在越狱手机上安装AppSync Unified插件禁用签名验证。（cydia源:https//cydia.akemi.ai）
2. 然后在mac上安装ideviceinstaller或pp助手之类安装到手机即可。