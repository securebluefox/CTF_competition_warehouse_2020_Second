#!/usr/bin/python3

import curses
import random, math, time, json
import game
import socket

SERVER_IP = "127.0.0.1"
SERVER_PORT = 9999

seed_time = math.floor(time.time())

def main(screen):
    screen.timeout(0)
    screen.nodelay(False)

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((SERVER_IP, SERVER_PORT))

    answer = []

    while True:
        my_game.render(screen)
        screen.refresh()
        ch = screen.getch()
        if ch == curses.KEY_LEFT or ch == curses.KEY_RIGHT or ch == curses.KEY_UP or ch == curses.KEY_DOWN:
            my_game.submit(ch)
            answer.append(ch)

        if my_game.is_win():
            my_game.render(screen)
            s.send(json.dumps({"time":seed_time, "answer":answer}).encode('ascii'))
            return s.recv(1024).decode('ascii')

        if my_game.is_over():
            s.close()
            return "Game over. Try again?"

    my_game.render(screen)
    screen.getch()

if __name__ == '__main__':
    local_random = random.Random(seed_time)

    my_game = game.Game(local_random)
    print(curses.wrapper(main))