from subgame import snake, tetris

class Game():
    snake = None
    tetris = None

    def __init__(self, local_random):
        self.snake = snake.Snake(local_random)
        self.tetris = tetris.Tetris(local_random)

    def submit(self, ch):
        self.snake.submit(ch)
        self.tetris.submit(ch)

    def render(self, screen):
        screen.clear()

        screen.addstr(0, 0, "X"*70)
        for i in range(1, 16):
            screen.addstr(i, 0, "X")
            screen.addstr(i, 69, "X")
            screen.addstr(i, 47, "X")
        screen.addstr(16, 0, "X"*70)

        snake_buf = self.snake.render()
        for i in range(len(snake_buf)):
            screen.addstr(i+1, 1, snake_buf[i])

        tetris_buf = self.tetris.render()
        for i in range(len(tetris_buf)):
            screen.addstr(i + 1, 48, tetris_buf[i])

        screen.addstr(18, 0, "Welcome to Double Game!")
        screen.addstr(19, 0, "Control: Up, Down, Left, Right")
        screen.addstr(20, 0, "To win, get 200 points in Snake and 1000 in Tetris in 30 seconds")

        if self.is_over():
            screen.addstr(21, 0, "GAME OVER!")
        else:
            screen.addstr(21, 0, "Snake score: %d, Tetris score: %d" % (self.snake.score, self.tetris.score()))

        if self.is_win():
            screen.addstr(22, 0, "Congratuations, you win! Retriving flag from server...")

    def null_render(self):
        self.snake.render()
        self.tetris.render()

    def is_win(self):
        return self.snake.score >= 200 and self.tetris.score() >= 1000

    def is_over(self):
        return self.snake.score == -1 or self.tetris.is_game_over()