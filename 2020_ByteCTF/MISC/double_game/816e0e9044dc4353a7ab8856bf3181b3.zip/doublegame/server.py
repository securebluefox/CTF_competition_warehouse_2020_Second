#!/usr/bin/python3

import socketserver
import random, math, time, json
import game

SERVER_IP = "0.0.0.0"
SERVER_PORT = 9999

FLAG = "ByteCTF{thisisatestflag}"

class GameServer(socketserver.BaseRequestHandler):
    def sendmsg(self, s):
        print(time.strftime("[%x %X]"), "[%s:%d]" % (self.client_address[0], self.client_address[1]), "Msg: ", s)
        self.request.sendall(s.encode("ascii"))

    def handle(self):
        print(time.strftime("[%x %X]"), "[%s:%d]" % (self.client_address[0], self.client_address[1]), "Connected")

        self.data = self.request.recv(20480)

        try:
            print(time.strftime("[%x %X]"), "[%s:%d]" % (self.client_address[0], self.client_address[1]), self.data.decode('utf-8') if self.data else "Disconnected")
            ans = json.loads(self.data)
            if 0 < math.floor(time.time()) - ans["time"] < 30:
                local_random = random.Random(ans["time"])
                my_game = game.Game(local_random)
                for ch in ans["answer"]:
                    try:
                        my_game.submit(ch)
                        my_game.null_render()
                    except Exception as e:
                        print(time.strftime("[%x %X]"), "[%s:%d]" % (self.client_address[0], self.client_address[1]),
                              "Exception:", e)
                        raise RuntimeError

                    if my_game.is_win():
                        self.sendmsg("You made it! The flag is: %s\n" % FLAG)
                        return

                    if my_game.is_over():
                        raise ValueError

                raise ValueError
            else:
                raise TimeoutError
        except ValueError:
            self.sendmsg("Game over. Try again?\n")
        except TimeoutError:
            self.sendmsg("You must beat the game in 30 seconds!\n")
        except (RuntimeError, TypeError, KeyError, json.decoder.JSONDecodeError):
            self.sendmsg("You made the server crashed! Bad guy!\n")
        except Exception as e:
            print(e)
            self.sendmsg("Unhandled exception.\n")

if __name__ == "__main__":
    with socketserver.ThreadingTCPServer((SERVER_IP, SERVER_PORT), GameServer) as s:
        s.serve_forever()
